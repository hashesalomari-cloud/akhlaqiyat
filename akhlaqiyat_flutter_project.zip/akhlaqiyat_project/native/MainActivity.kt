package __PKG__

import android.app.AlarmManager
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "akhlaqiyat/native")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "policyAccess" -> {
                            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                            result.success(Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted)
                        }
                        "openPolicySettings" -> {
                            val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(i)
                            result.success(true)
                        }
                        "scheduleSilence" -> {
                            val times = (call.argument<List<*>>("times") ?: emptyList<Any>())
                                .map { (it as Number).toLong() }
                            val minutes = (call.argument<Number>("minutes") ?: 15).toInt()
                            scheduleSilence(times, minutes)
                            result.success(true)
                        }
                        "cancelSilence" -> {
                            cancelSilence()
                            result.success(true)
                        }
                        "saveWidgetData" -> {
                            val prefs = getSharedPreferences("widget", Context.MODE_PRIVATE)
                            prefs.edit()
                                .putString("prayers", call.argument<String>("prayers") ?: "[]")
                                .putString("lines", call.argument<String>("lines") ?: "[]")
                                .apply()
                            AkhlaqWidgetProvider.updateAll(this)
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("native_error", e.toString(), null)
                }
            }
    }

    private fun cancelSilence() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val prefs = getSharedPreferences("silent", Context.MODE_PRIVATE)
        val old = (prefs.getString("ids", "") ?: "").split(",").filter { it.isNotEmpty() }
        for (id in old) {
            am.cancel(SilentReceiver.pending(this, id.toInt(), SilentReceiver.ACTION_SILENCE, 0))
        }
        prefs.edit().putString("ids", "").apply()
    }

    private fun scheduleSilence(times: List<Long>, minutes: Int) {
        cancelSilence()
        val prefs = getSharedPreferences("silent", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val ids = ArrayList<String>()
        var i = 0
        for (t in times) {
            if (t <= now) continue
            val id = 7000 + i
            SilentReceiver.setAlarm(this, t, SilentReceiver.pending(this, id, SilentReceiver.ACTION_SILENCE, minutes))
            ids.add(id.toString())
            i++
            if (i >= 40) break
        }
        prefs.edit().putString("ids", ids.joinToString(",")).apply()
    }
}
