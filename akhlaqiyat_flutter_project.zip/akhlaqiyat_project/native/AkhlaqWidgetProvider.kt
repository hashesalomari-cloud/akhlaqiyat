package __PKG__

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** ودجت الشاشة الرئيسية: الصلاة القادمة + ذكر/آية تتغير كل ساعة. */
class AkhlaqWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) update(context, manager, id)
        scheduleNext(context)
    }

    override fun onEnabled(context: Context) {
        scheduleNext(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            updateAll(context)
            scheduleNext(context)
        }
    }

    companion object {
        const val ACTION_REFRESH = "__PKG__.WIDGET_REFRESH"

        fun updateAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, AkhlaqWidgetProvider::class.java))
            for (id in ids) update(context, mgr, id)
        }

        fun scheduleNext(context: Context) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val i = Intent(context, AkhlaqWidgetProvider::class.java)
            i.action = ACTION_REFRESH
            val pi = PendingIntent.getBroadcast(
                context, 8001, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 15 * 60_000L, pi)
        }

        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.akhlaq_widget)
            val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
            val now = System.currentTimeMillis()

            var title = "افتح التطبيق لتحديث المواقيت"
            var remaining = ""
            try {
                val arr = JSONArray(prefs.getString("prayers", "[]"))
                for (k in 0 until arr.length()) {
                    val o = arr.getJSONObject(k)
                    val t = o.getLong("t")
                    if (t > now) {
                        val fmt = SimpleDateFormat("hh:mm a", Locale("ar"))
                        title = o.getString("n") + "  " + fmt.format(Date(t))
                        val mins = ((t - now) / 60_000L).toInt()
                        val h = mins / 60
                        val m = mins % 60
                        remaining = if (h > 0) "بعد $h س و$m د" else "بعد $m د"
                        break
                    }
                }
            } catch (e: Exception) {
            }

            var line = "ألا بذكر الله تطمئن القلوب"
            try {
                val lines = JSONArray(prefs.getString("lines", "[]"))
                if (lines.length() > 0) {
                    val cal = Calendar.getInstance()
                    val idx = (cal.get(Calendar.DAY_OF_YEAR) * 24 + cal.get(Calendar.HOUR_OF_DAY)) % lines.length()
                    line = lines.getString(idx)
                }
            } catch (e: Exception) {
            }

            views.setTextViewText(R.id.w_title, title)
            views.setTextViewText(R.id.w_remaining, remaining)
            views.setTextViewText(R.id.w_line, line)

            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launch != null) {
                val pi = PendingIntent.getActivity(
                    context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.w_root, pi)
            }
            manager.updateAppWidget(id, views)
        }
    }
}
