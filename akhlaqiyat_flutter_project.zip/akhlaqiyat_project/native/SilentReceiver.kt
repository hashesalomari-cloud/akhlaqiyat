package __PKG__

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build

/** يكتم الهاتف عند وقت الصلاة ثم يعيد الوضع السابق بعد المدة المحددة. */
class SilentReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val prefs = ctx.getSharedPreferences("silent", Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_SILENCE -> {
                val minutes = intent.getIntExtra("dur", 15)
                if (!prefs.getBoolean("active", false)) {
                    prefs.edit().putInt("prev", audio.ringerMode).putBoolean("active", true).apply()
                }
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val canSilent = Build.VERSION.SDK_INT < 23 || nm.isNotificationPolicyAccessGranted
                try {
                    audio.ringerMode =
                        if (canSilent) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_VIBRATE
                } catch (e: SecurityException) {
                    try {
                        audio.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    } catch (e2: Exception) {
                    }
                }
                setAlarm(
                    ctx,
                    System.currentTimeMillis() + minutes * 60_000L,
                    pending(ctx, 7999, ACTION_RESTORE, minutes)
                )
            }
            ACTION_RESTORE -> {
                if (prefs.getBoolean("active", false)) {
                    val prev = prefs.getInt("prev", AudioManager.RINGER_MODE_NORMAL)
                    try {
                        audio.ringerMode = prev
                    } catch (e: SecurityException) {
                    }
                    prefs.edit().putBoolean("active", false).apply()
                }
            }
        }
    }

    companion object {
        const val ACTION_SILENCE = "__PKG__.SILENCE"
        const val ACTION_RESTORE = "__PKG__.RESTORE"

        fun pending(ctx: Context, id: Int, action: String, minutes: Int): PendingIntent {
            val i = Intent(ctx, SilentReceiver::class.java)
            i.action = action
            i.putExtra("dur", minutes)
            return PendingIntent.getBroadcast(
                ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun setAlarm(ctx: Context, whenMs: Long, pi: PendingIntent) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                } else if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, whenMs, pi)
                }
            } catch (e: SecurityException) {
                am.set(AlarmManager.RTC_WAKEUP, whenMs, pi)
            }
        }
    }
}
