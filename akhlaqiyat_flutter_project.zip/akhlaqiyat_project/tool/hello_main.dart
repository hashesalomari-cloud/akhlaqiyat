import 'package:flutter/material.dart';

// نسخة تشخيص: تطبيق فارغ تمامًا بلا أي مكتبات أو بيانات.
void main() {
  runApp(const Directionality(
    textDirection: TextDirection.rtl,
    child: ColoredBox(
      color: Color(0xFF2E7D32),
      child: Center(
        child: Text(
          'اشتغل التشخيص ✔\nأخلاقيات - اختبار المحرك',
          textAlign: TextAlign.center,
          style: TextStyle(
              color: Color(0xFFFFFFFF), fontSize: 24, decoration: TextDecoration.none),
        ),
      ),
    ),
  ));
}
