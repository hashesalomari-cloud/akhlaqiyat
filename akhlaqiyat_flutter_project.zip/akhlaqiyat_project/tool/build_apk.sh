#!/usr/bin/env bash
set -euo pipefail
flutter pub get
# R8 shrinking breaks flutter_local_notifications (Gson 'Missing type parameter')
flutter build apk --release --no-shrink || flutter build apk --release
