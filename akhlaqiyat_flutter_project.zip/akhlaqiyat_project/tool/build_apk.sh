#!/usr/bin/env bash
set -euo pipefail
flutter pub get
# R8 shrinking breaks flutter_local_notifications (Gson 'Missing type parameter')
set -a; source tool/config.env 2>/dev/null || true; set +a
if [ "${LEGACY_ANDROID:-0}" = "1" ]; then
  flutter build apk --release
else
  flutter build apk --release --no-shrink || flutter build apk --release
fi
