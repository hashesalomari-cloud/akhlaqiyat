#!/usr/bin/env bash
set -euo pipefail

# --- Pin the Flutter SDK -------------------------------------------------------
# CI otherwise uses whatever "stable" is today; a newer release can change behavior
# on some devices (black screen on launch). tool/config.env sets the version.
set -a; source tool/config.env 2>/dev/null || true; set +a
if [ -n "${FLUTTER_PIN:-}" ]; then
  echo "Pinning Flutter $FLUTTER_PIN"
  if curl -fsSL -o /tmp/flutter_pin.tar.xz "https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${FLUTTER_PIN}-stable.tar.xz" \
     && mkdir -p /tmp/flutter_pin && tar -xf /tmp/flutter_pin.tar.xz -C /tmp/flutter_pin; then
    export PATH="/tmp/flutter_pin/flutter/bin:$PATH"
    [ -n "${GITHUB_PATH:-}" ] && echo "/tmp/flutter_pin/flutter/bin" >> "$GITHUB_PATH"
    git config --global --add safe.directory /tmp/flutter_pin/flutter || true
  else
    echo "WARNING: could not download pinned Flutter; using the default one"
  fi
fi
flutter --version

cp -r lib /tmp/lib_bak
cp pubspec.yaml /tmp/pubspec_bak.yaml
cp -r assets /tmp/assets_bak
flutter create --platforms=android --org com.akhlaqiyat --project-name akhlaqiyat .
rm -rf lib test
cp -r /tmp/lib_bak lib
cp /tmp/pubspec_bak.yaml pubspec.yaml
rm -rf assets && cp -r /tmp/assets_bak assets
if [ "${DIAG_HELLO:-0}" = "1" ]; then
  echo "DIAG_HELLO=1: replacing main.dart with an empty diagnostic app"
  cp tool/hello_main.dart lib/main.dart
fi
python3 - <<'PY'
import re, os
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf8").read()
perms = (
    '\n    <uses-permission android:name="android.permission.INTERNET"/>'
    '\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>'
    '\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>'
    '\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>'
    '\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>'
    '\n    <uses-permission android:name="android.permission.VIBRATE"/>\n'
)
if os.environ.get("LEGACY_ANDROID", "0") != "1":
    perms = perms.rstrip("\n") + (
        '\n    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>'
        '\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>'
        '\n    <uses-permission android:name="android.permission.WAKE_LOCK"/>'
        '\n    <uses-permission android:name="android.permission.ACCESS_NOTIFICATION_POLICY"/>\n'
    )
# Anchor on <manifest ...> (always exactly one, always the root element)
# instead of <application>, so this can never silently miss.
s2 = re.sub(r'(<manifest\b[^>]*>)', r'\1' + perms, s, count=1)
if s2 == s:
    raise SystemExit("FATAL: could not find <manifest> tag to insert permissions into")
label = "اختبار-فاضي" if os.environ.get("DIAG_HELLO", "0") == "1" else "أخلاقيات"
s = re.sub(r'android:label="[^"]*"', 'android:label="' + label + '"', s2, count=1)
# Receivers required for scheduled notifications (prayer alerts) to
# fire at all, and to be restored after a reboot.
receivers = (
    '\n        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />'
    '\n        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">'
    '\n            <intent-filter>'
    '\n                <action android:name="android.intent.action.BOOT_COMPLETED"/>'
    '\n                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>'
    '\n                <action android:name="android.intent.action.QUICKBOOT_POWERON" />'
    '\n                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>'
    '\n            </intent-filter>'
    '\n        </receiver>\n    '
)
if os.environ.get("LEGACY_ANDROID", "0") != "1":
    s3 = s.replace('</application>', receivers + '</application>', 1)
    assert s3 != s, "FATAL: could not find </application> closing tag"
    s = s3
open(p, "w", encoding="utf8").write(s)
assert "android.permission.INTERNET" in open(p, encoding="utf8").read()
print("Permissions inserted successfully. Manifest now contains:")
PY
grep -n "uses-permission\|<manifest\|<application" android/app/src/main/AndroidManifest.xml

python3 - <<'PY'
import re, os
# flutter_local_notifications requires "core library desugaring" to be
# enabled in the app-level Gradle file, or the release build fails with:
# "Dependency ':flutter_local_notifications' requires core library
# desugaring to be enabled for :app." This handles both the older
# Groovy (build.gradle) and newer Kotlin DSL (build.gradle.kts) templates.
kts_path = "android/app/build.gradle.kts"
groovy_path = "android/app/build.gradle"
is_kts = os.path.exists(kts_path)
path = kts_path if is_kts else groovy_path
s = open(path, encoding="utf8").read()

if is_kts:
    desugar_line = "\n        isCoreLibraryDesugaringEnabled = true"
    dep_line = '\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n'
else:
    desugar_line = "\n        coreLibraryDesugaringEnabled true"
    dep_line = "\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n"

if "compileOptions" in s and "compileOptions {" in s:
    s = s.replace("compileOptions {", "compileOptions {" + desugar_line, 1)
else:
    s2 = re.sub(r'(android\s*\{)', r'\1\n    compileOptions {' + desugar_line + '\n    }\n', s, count=1)
    assert s2 != s, "FATAL: could not find android {} block"
    s = s2

if "dependencies {" in s:
    idx = s.rfind("dependencies {")
    insert_at = idx + len("dependencies {")
    s = s[:insert_at] + dep_line + s[insert_at:]
else:
    s += "\n\ndependencies {" + dep_line + "}\n"

open(path, "w", encoding="utf8").write(s)
print(f"Patched {path} for core library desugaring ({'Kotlin DSL' if is_kts else 'Groovy'})")
PY
grep -n "desugar\|coreLibraryDesugaring" android/app/build.gradle.kts android/app/build.gradle 2>/dev/null || true

source tool/config.env 2>/dev/null || true
if [ "${NATIVE_PIECES:-1}" = "1" ]; then
python3 - <<'PY'
# Native Android pieces: auto-silent during prayer + home-screen widget,
# plus the launcher icon. Package name is read from the generated MainActivity.
import glob, os, re, shutil
mains = glob.glob("android/app/src/main/**/MainActivity.kt", recursive=True)
assert mains, "FATAL: MainActivity.kt not found"
kdir = os.path.dirname(mains[0])
pkg = re.search(r'^package\s+([\w.]+)', open(mains[0], encoding="utf8").read(), re.M).group(1)
for f in ["MainActivity.kt", "SilentReceiver.kt", "AkhlaqWidgetProvider.kt"]:
    src = open("native/" + f, encoding="utf8").read().replace("__PKG__", pkg)
    open(os.path.join(kdir, f), "w", encoding="utf8").write(src)
shutil.copytree("native/res", "android/app/src/main/res", dirs_exist_ok=True)
shutil.copytree("android_res", "android/app/src/main/res", dirs_exist_ok=True)
mp = "android/app/src/main/AndroidManifest.xml"
m = open(mp, encoding="utf8").read()
recv = (
    '\n        <receiver android:exported="false" android:name="' + pkg + '.SilentReceiver" />'
    '\n        <receiver android:exported="true" android:name="' + pkg + '.AkhlaqWidgetProvider">'
    '\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter>'
    '\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/akhlaq_widget_info"/>'
    '\n        </receiver>\n    '
)
m2 = m.replace('</application>', recv + '</application>', 1)
assert m2 != m, "FATAL: no </application>"
open(mp, "w", encoding="utf8").write(m2)
print("Native pieces installed for package", pkg)
PY
else
  echo "Native pieces skipped (NATIVE_PIECES=0); installing launcher icon only"
  cp -r android_res/. android/app/src/main/res/
fi

python3 - <<'PY'
# Disable R8/resource shrinking in the Gradle file itself (not only via the CLI flag):
# R8 strips Gson generic signatures that flutter_local_notifications needs
# ("Missing type parameter"), which broke prayer scheduling in release builds.
import os, re
if os.environ.get("LEGACY_ANDROID", "0") == "1":
    print("LEGACY_ANDROID=1: leaving minify settings untouched")
    raise SystemExit(0)
kts = "android/app/build.gradle.kts"
path = kts if os.path.exists(kts) else "android/app/build.gradle"
s = open(path, encoding="utf8").read()
if path.endswith(".kts"):
    add = "\n            isMinifyEnabled = false\n            isShrinkResources = false"
else:
    add = "\n            minifyEnabled false\n            shrinkResources false"
m = re.search(r'buildTypes\s*\{\s*(?:getByName\("release"\)|release)\s*\{', s)
assert m, "FATAL: release buildType not found in " + path
s = s[:m.end()] + add + s[m.end():]
open(path, "w", encoding="utf8").write(s)
print("Disabled minify/shrink in", path)
PY
grep -n "isMinifyEnabled\|minifyEnabled" android/app/build.gradle.kts android/app/build.gradle 2>/dev/null || true
