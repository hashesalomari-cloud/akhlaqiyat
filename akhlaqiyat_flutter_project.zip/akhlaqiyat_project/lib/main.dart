import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'core/router/app_router.dart';
import 'core/services/notification_service.dart';
import 'core/theme/app_theme.dart';

// نقطة الدخول — تُفعّل Riverpod على مستوى التطبيق كامل (ProviderScope)
// حتى تقدر لاحقًا تسحب StreakService و QuranApiService وغيرها كـ
// providers في أي شاشة، بدل الـ Mock المحلي المستخدم حاليًا في كل ملف.

void main() {
  runApp(const ProviderScope(child: AkhlaqiyatApp()));
  // جدولة تذكير الشعلة اليومي (8 مساءً) — لا تمنع بدء التطبيق، تعمل
  // بالخلفية. تطلب إذن الإشعارات أولًا (مطلوب من أندرويد 13 فأعلى).
  NotificationService.requestPermission().then((_) {
    NotificationService.scheduleDailyReminder();
  });
}

class AkhlaqiyatApp extends StatelessWidget {
  const AkhlaqiyatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'أخلاقيات',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      routerConfig: appRouter,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
