import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/router/app_router.dart';
import 'core/services/notification_service.dart';
import 'core/settings/app_settings.dart';
import 'core/theme/app_theme.dart';

final List<String> _bootErrors = [];

final ValueNotifier<String> _routerState = ValueNotifier<String>('router: waiting');

Future<void> main() async {
  await runZonedGuarded<Future<void>>(() async {
    WidgetsFlutterBinding.ensureInitialized();
    // تشخيص: نعرض شاشة ملوّنة فورًا (قبل أي تحميل) ثم نعرض أي خطأ بدل الشاشة السوداء.
    FlutterError.onError = (d) => _bootErrors.add('FlutterError: ${d.exceptionAsString()}');
    ui.PlatformDispatcher.instance.onError = (e, st) {
      _bootErrors.add('Platform: $e\n$st');
      return true;
    };
    runApp(const _Boot());
  }, (e, st) => _bootErrors.add('Zone: $e\n$st'));
}

class _Boot extends StatefulWidget {
  const _Boot();
  @override
  State<_Boot> createState() => _BootState();
}

class _BootState extends State<_Boot> {
  bool _ready = false;
  String _step = 'بدء التشغيل';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      setState(() => _step = 'تحميل الإعدادات');
      await AppSettings.I.load();
      setState(() => _step = 'تجهيز الواجهة');
      await Future<void>.delayed(const Duration(milliseconds: 50));
      if (!mounted) return;
      setState(() => _ready = true);
      // الإشعارات في الخلفية دون تعطيل بدء التطبيق.
      NotificationService.requestPermission().then((_) async {
        final prefs = await SharedPreferences.getInstance();
        if (prefs.getBool('daily_reminder_enabled') ?? true) {
          await NotificationService.scheduleDailyReminder();
        }
        await NotificationService.refreshPrayerSchedule();
        await NotificationService.refreshSmartReminders();
      }).catchError((_) {});
    } catch (e, st) {
      _bootErrors.add('init: $e\n$st');
      if (mounted) setState(() => _step = 'خطأ');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) {
      return ProviderScope(
        child: _GuardedApp(errors: _bootErrors),
      );
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ColoredBox(
        color: const Color(0xFFE8B94A),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'أخلاقيات\n$_step\n${_bootErrors.join("\n")}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: Color(0xFF000000), fontSize: 18, decoration: TextDecoration.none),
            ),
          ),
        ),
      ),
    );
  }
}

/// يعرض التطبيق، وإن حدث خطأ في الإطارات الأولى يظهر نصه على الشاشة.
class _GuardedApp extends StatefulWidget {
  final List<String> errors;
  const _GuardedApp({required this.errors});
  @override
  State<_GuardedApp> createState() => _GuardedAppState();
}

class _GuardedAppState extends State<_GuardedApp> {
  bool _showErr = false;
  bool _showBanner = true;
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _showErr = widget.errors.isNotEmpty && t.tick >= 3;
        if (t.tick >= 12) {
          _showBanner = false;
          t.cancel();
        }
      });
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      textDirection: TextDirection.ltr,
      children: [
        const AkhlaqiyatApp(),
        if (_showBanner)
          Positioned(
            top: 30,
            left: 8,
            right: 8,
            child: IgnorePointer(
              child: ValueListenableBuilder<String>(
                valueListenable: _routerState,
                builder: (_, v, __) => Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text('$v | errors=${widget.errors.length}',
                      style: const TextStyle(
                          color: Color(0xFFFFFF00),
                          backgroundColor: Color(0xFF000000),
                          fontSize: 12,
                          decoration: TextDecoration.none)),
                ),
              ),
            ),
          ),
        if (_showErr)
          Positioned.fill(
            child: ColoredBox(
              color: const Color(0xF0FFFFFF),
              child: SafeArea(
                child: SingleChildScrollView(
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(widget.errors.join('\n\n'),
                        style: const TextStyle(
                            color: Color(0xFFB00020),
                            fontSize: 11,
                            decoration: TextDecoration.none)),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class AkhlaqiyatApp extends StatefulWidget {
  const AkhlaqiyatApp({super.key});

  @override
  State<AkhlaqiyatApp> createState() => _AkhlaqiyatAppState();
}

class _AkhlaqiyatAppState extends State<AkhlaqiyatApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppSettings.I.addListener(_onSettings);
  }

  @override
  void dispose() {
    AppSettings.I.removeListener(_onSettings);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (AppSettings.I.themeMode == 0) _onSettings();
  }

  void _onSettings() {
    if (!mounted) return;
    setState(() {});
    // الألوان تُقرأ مباشرة من AppColors في كل الشاشات، فنُجبر الشجرة كلها
    // على إعادة البناء (مع الحفاظ على الحالة) عند تغيير الثيم أو الخط.
    SchedulerBinding.instance.addPostFrameCallback((_) {
      void rebuild(Element e) {
        e.markNeedsBuild();
        e.visitChildren(rebuild);
      }

      WidgetsBinding.instance.rootElement?.visitChildren(rebuild);
    });
  }

  void _applyPalette() {
    final s = AppSettings.I;
    final platformDark =
        WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
    final dark = s.themeMode == 2 || s.themeMode == 3 || (s.themeMode == 0 && platformDark);
    final oled = s.themeMode == 3;
    final ink = s.inkIndex == 0
        ? null
        : (dark ? inkChoices[s.inkIndex].dark : inkChoices[s.inkIndex].light);
    AppColors.configure(dark: dark, oled: oled, ink: ink);
  }

  @override
  Widget build(BuildContext context) {
    _applyPalette();
    return MaterialApp.router(
      title: 'أخلاقيات',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(),
      routerConfig: appRouter,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        final st = child == null ? 'router: NO PAGE' : 'router: page ok';
        WidgetsBinding.instance.addPostFrameCallback((_) => _routerState.value = st);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(AppSettings.I.textScale)),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
