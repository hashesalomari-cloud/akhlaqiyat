import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/router/app_router.dart';
import 'core/services/notification_service.dart';
import 'core/settings/app_settings.dart';
import 'core/theme/app_theme.dart';

/// آخر خطأ التقطه التطبيق (يُعرض بدل الشاشة السوداء لنعرف السبب).
String? _startupError;

Future<void> main() async {
  runZonedGuarded(_boot, (e, st) {
    _startupError = '$e\n$st';
  });
}

Future<void> _boot() async {
  WidgetsFlutterBinding.ensureInitialized();
  // أي خطأ في بناء واجهة يظهر نصه على الشاشة بدل رمادي/أسود صامت.
  ErrorWidget.builder = (details) => Material(
        color: const Color(0xFF1B1B1B),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: SelectableText(
              'خطأ: ${details.exceptionAsString()}\n\n${details.stack.toString().split("\n").take(8).join("\n")}',
              style: const TextStyle(color: Colors.orangeAccent, fontSize: 12),
            ),
          ),
        ),
      );
  FlutterError.onError = (d) {
    _startupError = d.exceptionAsString();
    FlutterError.presentError(d);
  };
  try {
    await AppSettings.I.load();
  } catch (e) {
    _startupError = 'AppSettings.load: $e';
  }
  runApp(const ProviderScope(child: AkhlaqiyatApp()));
  // الإشعارات في الخلفية دون تعطيل بدء التطبيق: تذكير الشعلة اليومي +
  // إعادة جدولة تنبيهات الصلاة بمواقيت اليوم (تعمل دون فتح شاشة الصلاة).
  NotificationService.requestPermission().then((_) async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('daily_reminder_enabled') ?? true) {
      await NotificationService.scheduleDailyReminder();
    }
    await NotificationService.refreshPrayerSchedule();
    await NotificationService.refreshSmartReminders();
  });
}

class AkhlaqiyatApp extends StatefulWidget {
  const AkhlaqiyatApp({super.key});

  @override
  State<AkhlaqiyatApp> createState() => _AkhlaqiyatAppState();
}

class _AkhlaqiyatAppState extends State<AkhlaqiyatApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AppSettings.I.addListener(_onSettings);
  }

  @override
  void dispose() {
    AppSettings.I.removeListener(_onSettings);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (AppSettings.I.themeMode == 0) _onSettings();
  }

  void _onSettings() {
    if (!mounted) return;
    setState(() {});
    // الألوان تُقرأ مباشرة من AppColors في كل الشاشات، فنُجبر الشجرة كلها
    // على إعادة البناء (مع الحفاظ على الحالة) عند تغيير الثيم أو الخط.
    SchedulerBinding.instance.addPostFrameCallback((_) {
      void rebuild(Element e) {
        e.markNeedsBuild();
        e.visitChildren(rebuild);
      }

      WidgetsBinding.instance.rootElement?.visitChildren(rebuild);
    });
  }

  void _applyPalette() {
    final s = AppSettings.I;
    final platformDark =
        WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
    final dark = s.themeMode == 2 || s.themeMode == 3 || (s.themeMode == 0 && platformDark);
    final oled = s.themeMode == 3;
    final ink = s.inkIndex == 0
        ? null
        : (dark ? inkChoices[s.inkIndex].dark : inkChoices[s.inkIndex].light);
    AppColors.configure(dark: dark, oled: oled, ink: ink);
  }

  @override
  Widget build(BuildContext context) {
    _applyPalette();
    return MaterialApp.router(
      title: 'أخلاقيات',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(),
      routerConfig: appRouter,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(AppSettings.I.textScale)),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}
