import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/theme/app_theme.dart';

/// شاشة ترحيب تظهر مرة واحدة فقط عند أول فتح للتطبيق، توضح هدفه.
class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  static const _kSeenKey = 'has_seen_onboarding';

  static Future<bool> hasSeen() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kSeenKey) ?? false;
  }

  static Future<void> markSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kSeenKey, true);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.night1, AppColors.night2, AppColors.emeraldDeep],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.local_fire_department, size: 56, color: AppColors.goldBright),
                  const SizedBox(height: 16),
                  Text('أخلاقيات',
                      style: GoogleFonts.tajawal(
                          fontSize: 32, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
                  const SizedBox(height: 14),
                  Text('اعرف دينك',
                      style: GoogleFonts.tajawal(
                          fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.paper)),
                  const SizedBox(height: 10),
                  Text(
                    'تطبيق يومي يرافقك لتتعلم القرآن والحديث والأذكار، وتطبّق الأخلاق عمليًا — بدل تمضية الوقت فيما لا يفيد.',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.tajawal(fontSize: 14.5, color: AppColors.paper.withOpacity(0.85), height: 1.9),
                  ),
                  const SizedBox(height: 36),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.gold.withOpacity(0.35)),
                    ),
                    child: Column(
                      children: [
                        Text(
                          'إِنَّ اللَّهَ لَا يُغَيِّرُ مَا بِقَوْمٍ حَتَّىٰ يُغَيِّرُوا مَا بِأَنفُسِهِمْ',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.amiri(fontSize: 20, height: 1.9, color: AppColors.paper),
                        ),
                        const SizedBox(height: 8),
                        Text('سورة الرعد، آية 11',
                            style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.goldBright)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        await markSeen();
                        if (context.mounted) context.go('/home');
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.ember2,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text('ابدأ رحلتك',
                          style: GoogleFonts.tajawal(
                              fontSize: 16, fontWeight: FontWeight.w900, color: const Color(0xFF3A1E00))),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
