import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../hadith/models/hadith_model.dart';

// نسخة "جسم الشاشة فقط" من الصفحة الرئيسية — بدون Scaffold أو
// BottomNavigationBar خاصين بها، لأن AppShell يوفرهما الآن لكل
// التبويبات. هذا الملف يحل محل home_screen.dart القديم كواجهة
// فعلية للتبويب الأول ضمن نظام التنقل الموحّد.

class HomeTabScreen extends StatefulWidget {
  const HomeTabScreen({super.key});
  @override
  State<HomeTabScreen> createState() => _HomeTabScreenState();
}

class _HomeTabScreenState extends State<HomeTabScreen> {
  // Mock — استبدلها بـ ref.watch(streakProvider) عبر Riverpod
  int _streakCount = 7;
  bool _doneToday = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: AppColors.night2,
            expandedHeight: 90,
            pinned: true,
            automaticallyImplyLeading: false,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [AppColors.night1, AppColors.night2, AppColors.emeraldDeep],
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                alignment: Alignment.bottomRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('أخلاقيات',
                        style: GoogleFonts.tajawal(
                            fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
                    const SizedBox(height: 4),
                    Text('خطوة كل يوم أقرب إلى ربك',
                        style: GoogleFonts.tajawal(fontSize: 13, color: AppColors.paper.withOpacity(0.8))),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _buildStreakCard(),
                const SizedBox(height: 20),
                _buildCheckinButton(),
                const SizedBox(height: 24),
                const _DailyContent(),
                const SizedBox(height: 24),
                _sectionHeader('الوصول السريع'),
                const SizedBox(height: 10),
                _buildQuickAccessGrid(context),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStreakCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.emerald, AppColors.emeraldDeep],
        ),
        boxShadow: [BoxShadow(color: AppColors.emeraldDeep.withOpacity(0.3), blurRadius: 22, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [AppColors.ember2, AppColors.ember1],
            ).createShader(bounds),
            child: const Icon(Icons.local_fire_department, size: 54, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$_streakCount',
                  style: GoogleFonts.tajawal(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.paper, height: 1)),
              Text('يوم متواصل من الشعلة',
                  style: GoogleFonts.tajawal(fontSize: 13, color: const Color(0xFFEAD9A6))),
              const SizedBox(height: 6),
              Text(
                _doneToday ? 'شعلتك مشتعلة، عد غدًا لتحافظ عليها' : 'أنجز وردك اليوم قبل منتصف الليل',
                style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.paper.withOpacity(0.9)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCheckinButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _doneToday
            ? null
            : () {
                // TODO: استدعِ StreakService.checkIn() فعليًا هنا
                setState(() {
                  _doneToday = true;
                  _streakCount++;
                });
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('تم تسجيل الإنجاز — الشعلة اشتعلت 🔥')));
              },
        child: Text(_doneToday ? 'أنجزت وردك اليوم — بارك الله فيك' : 'أنجزت وردي اليوم — أشعل الشعلة'),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Text(title,
        style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep));
  }

  Widget _buildQuickAccessGrid(BuildContext context) {
    final items = [
      ('تحدي الخُلق', Icons.favorite_border, '/ethics/challenge'),
      ('موقف نبوي', Icons.auto_stories, '/ethics/seerah'),
      ('فقه العبادات', Icons.mosque_outlined, '/fiqh'),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.85,
      ),
      itemBuilder: (context, i) {
        final (title, icon, route) = items[i];
        return Material(
          color: AppColors.paperDim,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => context.push(route),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: AppColors.emerald, size: 26),
                  const SizedBox(height: 8),
                  Text(title,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.tajawal(fontSize: 11.5, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}


/// آية اليوم وحديث اليوم من ملفات assets/data
class _DailyContent extends StatelessWidget {
  const _DailyContent();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Object>>(
      future: Future.wait<Object>([
        LocalDataService.dailyAyah(),
        LocalDataService.dailyHadith(),
      ]),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final ayah = snap.data![0] as Map<String, dynamic>;
        final hadith = snap.data![1] as Hadith;
        Widget card(String title, Widget child) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.tajawal(
                        fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.paperDim,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
                  ),
                  child: child,
                ),
              ],
            );
        return Column(
          children: [
            card(
              'آية اليوم',
              Column(
                children: [
                  Text('${ayah['text']}',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.amiri(fontSize: 22, height: 2.1, color: AppColors.ink)),
                  Text('${ayah['ref']}',
                      style: GoogleFonts.tajawal(
                          fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text('${ayah['meaning']}',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.tajawal(fontSize: 13, color: AppColors.inkSoft, height: 1.8)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            card(
              'حديث اليوم',
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('«${hadith.arabicText}»',
                      style: GoogleFonts.tajawal(fontSize: 15.5, height: 2)),
                  const SizedBox(height: 6),
                  Text('${hadith.reference} — ${hadith.gradeLabel}',
                      style: GoogleFonts.tajawal(
                          fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
