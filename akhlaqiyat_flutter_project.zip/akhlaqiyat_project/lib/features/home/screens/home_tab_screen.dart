import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/daily_tasks_service.dart';
import '../../../core/services/hadith_progress_service.dart';
import '../../../core/services/khatma_service.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/services/share_service.dart';
import '../../../core/services/streak_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/share_card.dart';
import '../../habits/widgets/tree_card.dart';
import '../../hadith/models/hadith_model.dart';

// نسخة "جسم الشاشة فقط" من الصفحة الرئيسية — بدون Scaffold أو
// BottomNavigationBar خاصين بها، لأن AppShell يوفرهما الآن لكل
// التبويبات. هذا الملف يحل محل home_screen.dart القديم كواجهة
// فعلية للتبويب الأول ضمن نظام التنقل الموحّد.

class HomeTabScreen extends StatefulWidget {
  const HomeTabScreen({super.key});
  @override
  State<HomeTabScreen> createState() => _HomeTabScreenState();
}

class _HomeTabScreenState extends State<HomeTabScreen> {
  int _streakCount = 0;
  bool _doneToday = false;
  bool _loadingStreak = true;

  @override
  void initState() {
    super.initState();
    _loadStreak();
    StreakService.version.addListener(_loadStreak);
  }

  @override
  void dispose() {
    StreakService.version.removeListener(_loadStreak);
    super.dispose();
  }

  Future<void> _loadStreak() async {
    final (count, done) = await StreakService.load();
    if (!mounted) return;
    setState(() {
      _streakCount = count;
      _doneToday = done;
      _loadingStreak = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: AppColors.night2,
            expandedHeight: 90,
            pinned: true,
            automaticallyImplyLeading: false,
            actions: [
              IconButton(
                tooltip: 'الإعدادات',
                icon: Icon(Icons.settings_outlined, color: AppColors.goldBright),
                onPressed: () => context.push('/settings'),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [AppColors.night1, AppColors.night2, AppColors.emeraldDeep],
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                alignment: Alignment.bottomRight,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset('assets/icon/logo_512.png', width: 30, height: 30),
                        ),
                        const SizedBox(width: 8),
                        Text('أخلاقيات',
                            style: AppFonts.ui(
                                fontSize: 23, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('خطوة كل يوم أقرب إلى ربك',
                        style: AppFonts.ui(fontSize: 13, color: AppColors.onGrad.withOpacity(0.8))),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _buildStreakCard(),
                const SizedBox(height: 20),
                _buildCheckinButton(),
                const SizedBox(height: 14),
                const _MissionsCard(),
                const SizedBox(height: 14),
                const _KhatmaHomeCard(),
                const TreeCard(),
                const SizedBox(height: 24),
                const _DailyContent(),
                const SizedBox(height: 24),
                _sectionHeader('الوصول السريع'),
                const SizedBox(height: 10),
                _buildQuickAccessGrid(context),
                const SizedBox(height: 20),
                _buildShareCard(),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStreakCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.emerald, AppColors.emeraldDeep],
        ),
        boxShadow: [BoxShadow(color: AppColors.emeraldDeep.withOpacity(0.3), blurRadius: 22, offset: const Offset(0, 8))],
      ),
      child: Row(
        children: [
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [AppColors.ember2, AppColors.ember1],
            ).createShader(bounds),
            child: const Icon(Icons.local_fire_department, size: 54, color: Colors.white),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$_streakCount',
                  style: AppFonts.ui(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.onGrad, height: 1)),
              Text('يوم متواصل من الشعلة',
                  style: AppFonts.ui(fontSize: 13, color: const Color(0xFFEAD9A6))),
              const SizedBox(height: 6),
              Text(
                _doneToday ? 'شعلتك مشتعلة، عد غدًا لتحافظ عليها' : 'أنجز وردك اليوم قبل منتصف الليل',
                style: AppFonts.ui(fontSize: 11.5, color: AppColors.onGrad.withOpacity(0.9)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCheckinButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _doneToday
            ? null
            : () async {
                final (count, _) = await StreakService.checkIn();
                if (!mounted) return;
                setState(() {
                  _doneToday = true;
                  _streakCount = count;
                });
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('تم تسجيل الإنجاز — الشعلة اشتعلت 🔥')));
              },
        child: Text(_doneToday ? 'أنجزت وردك اليوم — بارك الله فيك' : 'أنجزت وردي اليوم — أشعل الشعلة'),
      ),
    );
  }

  Widget _buildShareCard() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: ShareService.shareApp,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.gold, AppColors.goldBright]),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              const Icon(Icons.favorite, color: Color(0xFF3A1E00)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('شارك الخير',
                        style: AppFonts.ui(
                            fontSize: 15, fontWeight: FontWeight.w900, color: const Color(0xFF3A1E00))),
                    Text('شارك هذا التطبيق مع من تحب',
                        style: AppFonts.ui(fontSize: 11.5, color: const Color(0xFF3A1E00).withOpacity(0.8))),
                  ],
                ),
              ),
              const Icon(Icons.ios_share, color: Color(0xFF3A1E00), size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Text(title,
        style: AppFonts.ui(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep));
  }

  Widget _buildQuickAccessGrid(BuildContext context) {
    final items = [
      ('تحدي الخُلق', Icons.favorite_border, '/ethics/challenge'),
      ('قصص وعِبَر', Icons.auto_stories, '/stories'),
      ('فقه العبادات', Icons.mosque_outlined, '/fiqh'),
      ('تتبع الحفظ', Icons.bookmark_border, '/hifz'),
      ('ختمتي', Icons.auto_awesome_motion, '/khatma'),
      ('إحصائياتي', Icons.bar_chart_rounded, '/stats'),
      ('شجرة الأخلاق', Icons.park_outlined, '/habits'),
      ('حِكَم ابن القيم', Icons.format_quote_rounded, '/hikam'),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 0.85,
      ),
      itemBuilder: (context, i) {
        final (title, icon, route) = items[i];
        return Material(
          color: AppColors.paperDim,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => context.push(route),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: AppColors.emerald, size: 26),
                  const SizedBox(height: 8),
                  Text(title,
                      textAlign: TextAlign.center,
                      style: AppFonts.ui(fontSize: 11.5, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}


/// آية اليوم وحديث اليوم من ملفات assets/data
class _DailyContent extends StatelessWidget {
  const _DailyContent();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Object>>(
      future: Future.wait<Object>([
        LocalDataService.dailyAyah(),
        LocalDataService.dailyHadith(),
      ]),
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final ayah = snap.data![0] as Map<String, dynamic>;
        final hadith = snap.data![1] as Hadith;
        Widget card(String title, Widget child) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: AppFonts.ui(
                        fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.paperDim,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
                  ),
                  child: child,
                ),
              ],
            );
        return Column(
          children: [
            card(
              'آية اليوم',
              Column(
                children: [
                  Text('${ayah['text']}',
                      textAlign: TextAlign.center,
                      style: AppFonts.quran(fontSize: 22, height: 2.1, color: AppColors.ink)),
                  Text('${ayah['ref']}',
                      style: AppFonts.ui(
                          fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                  ShareCardButton(text: '${ayah['text']}', source: '${ayah['ref']}'),
                  const SizedBox(height: 8),
                  Text('${ayah['meaning']}',
                      textAlign: TextAlign.center,
                      style: AppFonts.ui(fontSize: 13, color: AppColors.inkSoft, height: 1.8)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            card(
              'حديث اليوم',
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('«${hadith.arabicText}»',
                      style: AppFonts.ui(fontSize: 15.5, height: 2)),
                  const SizedBox(height: 6),
                  Text('${hadith.reference} — ${hadith.gradeLabel}',
                      style: AppFonts.ui(
                          fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                  if (hadith.meaning.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(hadith.meaning,
                        style: AppFonts.ui(
                            fontSize: 13.5, color: AppColors.inkSoft, height: 1.8)),
                  ],
                  const SizedBox(height: 8),
                  ShareCardButton(
                      text: '«${hadith.arabicText}»', source: '${hadith.reference} — ${hadith.gradeLabel}'),
                  const SizedBox(height: 4),
                  const _HomeHadithMemorizeButton(),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

/// زر "حفظت هذا الحديث" داخل بطاقة حديث اليوم بالرئيسية — يربط مباشرة
/// بعدّاد الحفظ وبالشعلة العامة، حتى يصير جزءًا من روتين الدخول
/// اليومي للتطبيق بدل الاكتفاء بالقراءة فقط.
class _HomeHadithMemorizeButton extends StatefulWidget {
  const _HomeHadithMemorizeButton();
  @override
  State<_HomeHadithMemorizeButton> createState() => _HomeHadithMemorizeButtonState();
}

class _HomeHadithMemorizeButtonState extends State<_HomeHadithMemorizeButton> {
  bool _doneToday = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final (_, done) = await HadithProgressService.load();
    if (!mounted) return;
    setState(() {
      _doneToday = done;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox.shrink();
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _doneToday
            ? null
            : () async {
                await HadithProgressService.markTodayMemorized();
                await StreakService.checkIn();
                if (!mounted) return;
                setState(() => _doneToday = true);
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('أحسنت! تم تسجيل حفظك لحديث اليوم 📿')));
              },
        icon: Icon(_doneToday ? Icons.check_circle : Icons.bookmark_add_outlined,
            size: 18, color: AppColors.emerald),
        label: Text(_doneToday ? 'حفظت حديث اليوم' : 'حفظته — سجّل إنجازي',
            style: AppFonts.ui(fontSize: 12.5, fontWeight: FontWeight.w800)),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: AppColors.emerald.withOpacity(0.4)),
          padding: const EdgeInsets.symmetric(vertical: 10),
        ),
      ),
    );
  }
}


/// بطاقة "مهام اليوم" بالرئيسية: تُظهر تقدّم المهام الثلاث (آية، خُلق،
/// حديث) وتفتح شاشة المهام. تتحدّث فورًا عند إنجاز أي مهمة من أي شاشة.
class _MissionsCard extends StatefulWidget {
  const _MissionsCard();
  @override
  State<_MissionsCard> createState() => _MissionsCardState();
}

class _MissionsCardState extends State<_MissionsCard> {
  Map<DailyTask, bool> _done = {for (final t in DailyTask.values) t: false};

  @override
  void initState() {
    super.initState();
    _refresh();
    DailyTasksService.version.addListener(_refresh);
    HadithProgressService.version.addListener(_refresh);
  }

  @override
  void dispose() {
    DailyTasksService.version.removeListener(_refresh);
    HadithProgressService.version.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _refresh() async {
    final m = await DailyTasksService.load();
    if (!mounted) return;
    setState(() => _done = m);
  }

  @override
  Widget build(BuildContext context) {
    final count = _done.values.where((v) => v).length;
    final total = DailyTask.values.length;
    final all = count == total;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => context.push('/daily'),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.paperDim,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: all ? AppColors.emerald : AppColors.gold.withOpacity(0.5), width: 1.4),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(all ? Icons.check_circle : Icons.flag_outlined,
                      color: all ? AppColors.emerald : AppColors.gold, size: 22),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('مهام اليوم',
                        style: AppFonts.ui(
                            fontSize: 15.5, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
                  ),
                  Text('$count / $total',
                      style: AppFonts.ui(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.gold)),
                  Icon(Icons.chevron_left, color: AppColors.inkSoft),
                ],
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: count / total,
                  minHeight: 7,
                  backgroundColor: AppColors.emerald.withOpacity(0.12),
                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.emerald),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                all ? 'أتممت مهام اليوم، بارك الله فيك' : 'احفظ آية بتفسيرها، طبّق خُلقًا، واحفظ حديثًا بمعناه',
                style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft, height: 1.6),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


/// بطاقة ورد الختمة على الرئيسية (تظهر فقط إن كانت لديه خطة ختمة).
class _KhatmaHomeCard extends StatefulWidget {
  const _KhatmaHomeCard();
  @override
  State<_KhatmaHomeCard> createState() => _KhatmaHomeCardState();
}

class _KhatmaHomeCardState extends State<_KhatmaHomeCard> {
  KhatmaPlan? _plan;

  @override
  void initState() {
    super.initState();
    KhatmaService.version.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    KhatmaService.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final surahs = await LocalDataService.surahs();
    KhatmaService.init(surahs);
    final p = await KhatmaService.load();
    if (!mounted) return;
    setState(() => _plan = p);
  }

  @override
  Widget build(BuildContext context) {
    final p = _plan;
    if (p == null) return const SizedBox.shrink();
    final done = p.finished || p.todayDone;
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Material(
        color: AppColors.paperDim,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => context.push('/khatma'),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Icon(done ? Icons.check_circle : Icons.auto_awesome_motion,
                  color: done ? AppColors.emerald : AppColors.gold),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('ختمتي — ${(p.progress * 100).floor()}%',
                      style: AppFonts.ui(
                          fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
                  Text(
                      p.finished
                          ? 'أتممت الختمة، بارك الله فيك'
                          : done
                              ? 'أتممت ورد اليوم'
                              : 'متبقٍ من ورد اليوم ${p.todayAyat} آية',
                      style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft)),
                ]),
              ),
              Icon(Icons.chevron_left, color: AppColors.inkSoft),
            ]),
          ),
        ),
      ),
    );
  }
}
