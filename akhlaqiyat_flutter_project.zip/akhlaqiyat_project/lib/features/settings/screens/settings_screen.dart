import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/services/notification_service.dart';
import '../../../core/services/prayer_time_service.dart';
import '../../../core/settings/app_settings.dart';
import '../../../core/theme/app_theme.dart';

/// شاشة الإعدادات: المظهر، الخطوط، التنبيهات، وطريقة حساب الصلاة.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  static const _kDaily = 'daily_reminder_enabled';

  bool _prayerAlerts = true;
  bool _dailyReminder = true;
  bool _exactOk = true;
  String _method = 'muslim_world_league';
  String _madhab = 'shafi';
  int _city = -1;

  AppSettings get s => AppSettings.I;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final exact = await NotificationService.canScheduleExact();
    if (!mounted) return;
    setState(() {
      _prayerAlerts = p.getBool(PrayerSettings.kAlerts) ?? true;
      _dailyReminder = p.getBool(_kDaily) ?? true;
      _method = p.getString(PrayerSettings.kMethod) ?? 'muslim_world_league';
      _madhab = p.getString(PrayerSettings.kMadhab) ?? 'shafi';
      _city = p.getInt(PrayerSettings.kCity) ?? -1;
      _exactOk = exact;
    });
  }

  Future<void> _reschedulePrayer() async {
    await NotificationService.cancelPrayerNotifications();
    await NotificationService.refreshPrayerSchedule();
  }

  Future<void> _setPrayerAlerts(bool v) async {
    setState(() => _prayerAlerts = v);
    final p = await SharedPreferences.getInstance();
    await p.setBool(PrayerSettings.kAlerts, v);
    if (v) {
      await NotificationService.requestPermission();
      await NotificationService.refreshPrayerSchedule();
    } else {
      await NotificationService.cancelPrayerNotifications();
    }
  }

  Future<void> _setDaily(bool v) async {
    setState(() => _dailyReminder = v);
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kDaily, v);
    if (v) {
      await NotificationService.requestPermission();
      await NotificationService.scheduleDailyReminder();
    } else {
      await NotificationService.cancelDailyReminder();
    }
  }

  Future<void> _setPrayerPref(String key, Object value) async {
    final p = await SharedPreferences.getInstance();
    if (value is String) await p.setString(key, value);
    if (value is int) await p.setInt(key, value);
    if (_prayerAlerts) await _reschedulePrayer();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.paper,
        appBar: AppBar(title: const Text('الإعدادات')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 40),
          children: [
            _section('المظهر'),
            _card([
              _label('وضع الألوان'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final e in const [
                    (0, 'تلقائي'),
                    (1, 'فاتح'),
                    (2, 'داكن'),
                    (3, 'أسود OLED'),
                  ])
                    _chip(e.$2, s.themeMode == e.$1, () => s.update(() => s.themeMode = e.$1)),
                ],
              ),
              const SizedBox(height: 6),
              Text('وضع OLED أسود حقيقي: أريح للعين ليلًا ويوفّر البطارية.',
                  style: AppFonts.ui(fontSize: 11.5, color: AppColors.inkSoft)),
              const Divider(height: 26),
              _label('لون الخط'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < inkChoices.length; i++)
                    _chip(inkChoices[i].label, s.inkIndex == i, () => s.update(() => s.inkIndex = i)),
                ],
              ),
            ]),
            _section('الخط والكتابة'),
            _card([
              _label('خط التطبيق'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < uiFonts.length; i++)
                    _chip(uiFonts[i].label, s.uiFont == i, () => s.update(() => s.uiFont = i)),
                ],
              ),
              const Divider(height: 26),
              _label('طريقة كتابة القرآن (الخط)'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < quranFonts.length; i++)
                    _chip(quranFonts[i].label, s.quranFont == i, () => s.update(() => s.quranFont = i)),
                ],
              ),
              const Divider(height: 26),
              _label('حجم الخط: ${(s.textScale * 100).round()}%'),
              Slider(
                value: s.textScale,
                min: 0.85,
                max: 1.5,
                divisions: 13,
                activeColor: AppColors.emerald,
                onChanged: (v) => s.update(() => s.textScale = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: AppColors.emerald,
                title: Text('خط أثقل (أوضح)', style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w700)),
                value: s.boldText,
                onChanged: (v) => s.update(() => s.boldText = v),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.paper,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.emerald.withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    Text('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',
                        textAlign: TextAlign.center,
                        style: AppFonts.quran(fontSize: 24, height: 1.9, color: AppColors.ink)),
                    const SizedBox(height: 6),
                    Text('هذا مثال لشكل الخط والحجم واللون',
                        style: AppFonts.ui(fontSize: 14, color: AppColors.ink)),
                  ],
                ),
              ),
            ]),
            _section('التنبيهات'),
            _card([
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: AppColors.emerald,
                title: Text('تنبيه دخول وقت الصلاة',
                    style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w700)),
                value: _prayerAlerts,
                onChanged: _setPrayerAlerts,
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: AppColors.emerald,
                title: Text('تذكير الشعلة اليومي (8 مساءً)',
                    style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w700)),
                value: _dailyReminder,
                onChanged: _setDaily,
              ),
              if (!_exactOk)
                Container(
                  margin: const EdgeInsets.only(top: 6),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.gold.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'لتصل تنبيهات الصلاة في دقيقتها بالضبط، اسمح للتطبيق بـ «المنبهات والتذكيرات». بدونه قد يتأخر الإشعار بضع دقائق.',
                        style: AppFonts.ui(fontSize: 12, height: 1.7, color: AppColors.ink),
                      ),
                      const SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: () async {
                          await NotificationService.requestExactAlarms();
                          await Future<void>.delayed(const Duration(seconds: 1));
                          _load();
                        },
                        child: const Text('السماح بالمنبهات الدقيقة'),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    await NotificationService.showTest();
                  },
                  icon: const Icon(Icons.notifications_active_outlined),
                  label: const Text('جرّب إشعار الصلاة الآن'),
                ),
              ),
            ]),
            _section('حساب مواقيت الصلاة'),
            _card([
              _label('طريقة الحساب'),
              DropdownButtonFormField<String>(
                value: prayerMethods.containsKey(_method) ? _method : 'muslim_world_league',
                isExpanded: true,
                dropdownColor: AppColors.paperDim,
                items: [
                  for (final e in prayerMethods.entries)
                    DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value, style: AppFonts.ui(fontSize: 14, color: AppColors.ink)),
                    ),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _method = v);
                  _setPrayerPref(PrayerSettings.kMethod, v);
                },
              ),
              const SizedBox(height: 14),
              _label('المذهب (يؤثر على وقت العصر)'),
              Wrap(
                spacing: 8,
                children: [
                  _chip('الجمهور (شافعي/مالكي/حنبلي)', _madhab == 'shafi', () {
                    setState(() => _madhab = 'shafi');
                    _setPrayerPref(PrayerSettings.kMadhab, 'shafi');
                  }),
                  _chip('حنفي', _madhab == 'hanafi', () {
                    setState(() => _madhab = 'hanafi');
                    _setPrayerPref(PrayerSettings.kMadhab, 'hanafi');
                  }),
                ],
              ),
              const SizedBox(height: 14),
              _label('الموقع'),
              DropdownButtonFormField<int>(
                value: _city,
                isExpanded: true,
                dropdownColor: AppColors.paperDim,
                items: [
                  DropdownMenuItem(
                    value: -1,
                    child: Text('تلقائي (GPS)', style: AppFonts.ui(fontSize: 14, color: AppColors.ink)),
                  ),
                  for (var i = 0; i < prayerCities.length; i++)
                    DropdownMenuItem(
                      value: i,
                      child: Text(prayerCities[i].name,
                          style: AppFonts.ui(fontSize: 14, color: AppColors.ink)),
                    ),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _city = v);
                  _setPrayerPref(PrayerSettings.kCity, v);
                },
              ),
            ]),
            _section('عام'),
            _card([
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: AppColors.emerald,
                title: Text('اهتزاز خفيف عند العدّ',
                    style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w700)),
                value: s.haptics,
                onChanged: (v) => s.update(() => s.haptics = v),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: () => s.update(() {
                    s.themeMode = 0;
                    s.uiFont = 0;
                    s.quranFont = 0;
                    s.inkIndex = 0;
                    s.textScale = 1.0;
                    s.boldText = false;
                  }),
                  icon: const Icon(Icons.restart_alt),
                  label: const Text('إعادة المظهر للافتراضي'),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Center(
              child: Text('أخلاقيات — نسخة Beta 4',
                  style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
        child: Text(t,
            style: AppFonts.ui(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emerald)),
      );

  Widget _card(List<Widget> children) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.paperDim,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.emerald.withOpacity(0.12)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
      );

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(t,
            style: AppFonts.ui(fontSize: 13.5, fontWeight: FontWeight.w800, color: AppColors.ink)),
      );

  Widget _chip(String label, bool selected, VoidCallback onTap) => ChoiceChip(
        label: Text(label,
            style: AppFonts.ui(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: selected ? AppColors.onGrad : AppColors.ink)),
        selected: selected,
        selectedColor: AppColors.emerald,
        backgroundColor: AppColors.paper,
        showCheckmark: false,
        onSelected: (_) => onTap(),
      );
}
