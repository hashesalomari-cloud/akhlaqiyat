import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../../../core/theme/app_theme.dart';

class StoryItem {
  final String category, title, story, lesson, apply, source;
  const StoryItem({
    required this.category,
    required this.title,
    required this.story,
    required this.lesson,
    required this.apply,
    required this.source,
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
        category: j['category'] as String,
        title: j['title'] as String,
        story: j['story'] as String,
        lesson: j['lesson'] as String,
        apply: j['apply'] as String,
        source: j['source'] as String,
      );
}

Future<List<StoryItem>> loadStories() async {
  final raw = jsonDecode(await rootBundle.loadString('assets/data/stories.json')) as List;
  return raw.map((e) => StoryItem.fromJson(e as Map<String, dynamic>)).toList();
}

/// قصص الأنبياء والسيرة والصحابة — لكل قصة العبرة وكيف أستفيد منها.
class StoriesScreen extends StatefulWidget {
  const StoriesScreen({super.key});
  @override
  State<StoriesScreen> createState() => _StoriesScreenState();
}

class _StoriesScreenState extends State<StoriesScreen> {
  late final Future<List<StoryItem>> _future = loadStories();

  static const _tabs = [
    ('prophets', 'الأنبياء'),
    ('seerah', 'السيرة النبوية'),
    ('sahaba', 'الصحابة'),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: _tabs.length,
        child: Scaffold(
          backgroundColor: AppColors.paper,
          appBar: AppBar(
            title: const Text('القصص والعِبَر'),
            bottom: TabBar(
              indicatorColor: AppColors.goldBright,
              labelColor: AppColors.goldBright,
              unselectedLabelColor: Colors.white60,
              labelStyle: AppFonts.ui(fontWeight: FontWeight.w800, fontSize: 14),
              tabs: [for (final t in _tabs) Tab(text: t.$2)],
            ),
          ),
          body: FutureBuilder<List<StoryItem>>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError || snap.data == null) {
                return Center(child: Text('تعذّر تحميل القصص', style: AppFonts.ui(fontSize: 14)));
              }
              final all = snap.data!;
              return TabBarView(children: [
                for (final t in _tabs)
                  ListView(
                    padding: const EdgeInsets.all(14),
                    children: [
                      for (final s in all.where((x) => x.category == t.$1)) _StoryCard(story: s),
                    ],
                  ),
              ]);
            },
          ),
        ),
      ),
    );
  }
}

class _StoryCard extends StatefulWidget {
  final StoryItem story;
  const _StoryCard({required this.story});
  @override
  State<_StoryCard> createState() => _StoryCardState();
}

class _StoryCardState extends State<_StoryCard> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final s = widget.story;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.paperDim,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.emerald.withOpacity(_open ? 0.5 : 0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => setState(() => _open = !_open),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Text(s.title,
                        style: AppFonts.ui(
                            fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.ink, height: 1.6)),
                  ),
                  Icon(_open ? Icons.expand_less : Icons.expand_more, color: AppColors.emerald),
                ],
              ),
            ),
          ),
          if (_open)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.story,
                      style: AppFonts.ui(fontSize: 16, height: 2.0, color: AppColors.ink)),
                  const SizedBox(height: 14),
                  _block('العبرة', Icons.lightbulb_outline, s.lesson),
                  const SizedBox(height: 10),
                  _block('كيف أستفيد منها في حياتي؟', Icons.volunteer_activism_outlined, s.apply),
                  const SizedBox(height: 10),
                  Text('المصدر: ${s.source}',
                      style: AppFonts.ui(fontSize: 11.5, color: AppColors.inkSoft, height: 1.6)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _block(String title, IconData icon, String body) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.emerald.withOpacity(0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, size: 18, color: AppColors.emerald),
              const SizedBox(width: 6),
              Text(title,
                  style: AppFonts.ui(fontSize: 13.5, fontWeight: FontWeight.w900, color: AppColors.emerald)),
            ]),
            const SizedBox(height: 6),
            Text(body, style: AppFonts.ui(fontSize: 14.5, height: 1.9, color: AppColors.ink)),
          ],
        ),
      );
}
