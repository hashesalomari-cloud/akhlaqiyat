import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/services/notification_service.dart';
import '../../../core/services/prayer_time_service.dart';
import '../../../core/theme/app_theme.dart';

class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});
  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  static const _kAlertsPrefKey = PrayerSettings.kAlerts;
  late Future<PrayerTimesResult> _future = _loadAndSchedule();
  bool _alertsEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadAlertsPref();
  }

  Future<void> _loadAlertsPref() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool(_kAlertsPrefKey) ?? true;
    if (mounted) setState(() => _alertsEnabled = enabled);
  }

  Future<PrayerTimesResult> _loadAndSchedule() async {
    final r = await PrayerTimeService().loadForCurrentLocation();
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool(_kAlertsPrefKey) ?? true;
    if (enabled) {
      await NotificationService.requestPermission();
      await NotificationService.schedulePrayerNotifications({
        'fajr': r.fajr,
        'dhuhr': r.dhuhr,
        'asr': r.asr,
        'maghrib': r.maghrib,
        'isha': r.isha,
      });
    }
    return r;
  }

  Future<void> _toggleAlerts(bool value) async {
    setState(() => _alertsEnabled = value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAlertsPrefKey, value);
    if (value) {
      setState(() => _future = _loadAndSchedule());
    } else {
      await NotificationService.cancelPrayerNotifications();
    }
  }

  String _fmt(DateTime t) {
    final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
    final period = t.hour >= 12 ? 'م' : 'ص';
    return '${h.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')} $period';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('الصلاة والقبلة'),
            actions: [
              IconButton(
                tooltip: 'إعدادات الصلاة',
                icon: const Icon(Icons.tune),
                onPressed: () async {
                  await context.push('/settings');
                  if (mounted) setState(() => _future = _loadAndSchedule());
                },
              ),
            ],
            bottom: TabBar(
              indicatorColor: AppColors.goldBright,
              labelColor: AppColors.goldBright,
              unselectedLabelColor: Colors.white60,
              labelStyle: AppFonts.ui(fontWeight: FontWeight.w800),
              tabs: const [Tab(text: 'المواقيت'), Tab(text: 'القبلة')],
            ),
          ),
          body: FutureBuilder<PrayerTimesResult>(
            future: _future,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError || snap.data == null) {
                return Center(
                  child: ElevatedButton(
                    onPressed: () => setState(() => _future = _loadAndSchedule()),
                    child: const Text('إعادة المحاولة'),
                  ),
                );
              }
              final r = snap.data!;
              return TabBarView(children: [_times(r), _qibla(r)]);
            },
          ),
        ),
      ),
    );
  }

  Widget _times(PrayerTimesResult r) {
    final prayers = [
      ('الفجر', r.fajr, Icons.brightness_4_outlined),
      ('الشروق', r.sunrise, Icons.wb_twilight),
      ('الظهر', r.dhuhr, Icons.wb_sunny_outlined),
      ('العصر', r.asr, Icons.wb_sunny),
      ('المغرب', r.maghrib, Icons.nights_stay_outlined),
      ('العشاء', r.isha, Icons.dark_mode_outlined),
    ];
    final now = DateTime.now();
    final real = prayers.where((p) => p.$1 != 'الشروق').toList();
    final upcoming = real.firstWhere(
      (p) => p.$2.isAfter(now),
      orElse: () => ('الفجر', r.tomorrowFajr, Icons.brightness_4_outlined),
    );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.paperDim,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.emerald.withOpacity(0.15)),
          ),
          child: Row(
            children: [
              Icon(Icons.notifications_active_outlined, color: AppColors.emerald, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('تنبيه دخول وقت الصلاة',
                        style: AppFonts.ui(fontSize: 13.5, fontWeight: FontWeight.w800)),
                    Text('إشعار قوي عند كل صلاة يذكّرك بترك هاتفك',
                        style: AppFonts.ui(fontSize: 10.5, color: AppColors.inkSoft)),
                  ],
                ),
              ),
              Switch(
                value: _alertsEnabled,
                activeColor: AppColors.emerald,
                onChanged: _toggleAlerts,
              ),
            ],
          ),
        ),
        if (r.isFallbackLocation)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.gold.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text('تعذّر تحديد موقعك، المواقيت معروضة لمكة المكرمة. فعّل الموقع، أو اختر مدينتك من الإعدادات (زر ⚙ بالأعلى).',
                style: AppFonts.ui(fontSize: 12, height: 1.7)),
          ),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            children: [
              Text('الصلاة القادمة', style: AppFonts.ui(fontSize: 12, color: AppColors.goldBright)),
              const SizedBox(height: 6),
              Text(upcoming.$1,
                  style: AppFonts.ui(fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.onGrad)),
              Text(_fmt(upcoming.$2),
                  style: AppFonts.ui(fontSize: 15, color: AppColors.onGrad)),
              const SizedBox(height: 8),
              _Countdown(target: upcoming.$2),
              if (r.cityName != null) ...[
                const SizedBox(height: 6),
                Text('📍 ${r.cityName}',
                    style: AppFonts.ui(fontSize: 11.5, color: AppColors.onGrad.withOpacity(0.8))),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        ...prayers.map((p) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: p.$1 == upcoming.$1 ? AppColors.emerald.withOpacity(0.1) : AppColors.paperDim,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                    color: p.$1 == upcoming.$1 ? AppColors.emerald : AppColors.emerald.withOpacity(0.12)),
              ),
              child: Row(
                children: [
                  Icon(p.$3, color: AppColors.emerald, size: 22),
                  const SizedBox(width: 12),
                  Expanded(child: Text(p.$1, style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w800))),
                  Text(_fmt(p.$2),
                      style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.inkSoft)),
                ],
              ),
            )),
      ],
    );
  }

  Widget _qibla(PrayerTimesResult r) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.paperDim,
                border: Border.all(color: AppColors.gold, width: 3),
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Positioned(
                    top: 10,
                    child: Text('ش', style: AppFonts.ui(fontWeight: FontWeight.w900, color: AppColors.inkSoft)),
                  ),
                  Transform.rotate(
                    angle: r.qiblaDegrees * math.pi / 180,
                    child: Icon(Icons.navigation, size: 90, color: AppColors.emeraldDeep),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Text('اتجاه القبلة: ${r.qiblaDegrees.toStringAsFixed(1)}° من الشمال',
                style: AppFonts.ui(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('السهم يشير إلى القبلة بالنسبة للشمال (ش). استخدم بوصلة هاتفك لتحديد الشمال ثم أدر وجهك بهذه الزاوية.',
                textAlign: TextAlign.center,
                style: AppFonts.ui(fontSize: 12.5, color: AppColors.inkSoft, height: 1.8)),
          ],
        ),
      ),
    );
  }
}

/// عدّاد تنازلي لموعد الصلاة القادمة (يتحدث كل ثانية).
class _Countdown extends StatefulWidget {
  final DateTime target;
  const _Countdown({required this.target});
  @override
  State<_Countdown> createState() => _CountdownState();
}

class _CountdownState extends State<_Countdown> {
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var d = widget.target.difference(DateTime.now());
    if (d.isNegative) d = Duration.zero;
    String two(int n) => n.toString().padLeft(2, '0');
    final txt = '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Text('متبقٍ $txt',
          style: AppFonts.ui(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
    );
  }
}
