import 'dart:async';
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/services/quran_api_service.dart';
import '../../../core/services/tafsir_audio_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/surah_model.dart';

/// قراءة السورة: النص العثماني وتفسير السعدي من islamic.app (خدمة
/// مجانية بلا تسجيل)، والتلاوة بأصوات عدة قرّاء بتشغيل متواصل لكامل
/// السورة. يتطلب اتصالاً بالإنترنت.
class SurahReaderScreen extends StatefulWidget {
  const SurahReaderScreen({super.key, required this.surah});
  final Surah surah;
  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  final _api = QuranApiService();
  final _player = AudioPlayer(); // التلاوة
  final _tafsirPlayer = AudioPlayer(); // التفسير المسجَّل بصوت بشري
  final _tts = FlutterTts(); // النطق الآلي لنص السعدي
  final _scroll = ScrollController();
  final Map<int, GlobalKey> _keys = {};

  late Future<List<Ayah>> _versesFuture;
  List<Ayah> _ayat = const [];

  /// فهرس أول آية في قائمة التشغيل الحالية (القائمة تبدأ من الآية المختارة)
  int _startOffset = 0;
  int? _playingAyah;
  int? _expandedAyah;
  bool _repeat = false;
  bool _isPlaying = false;
  String _reciter = QuranApiService.defaultReciter;

  // التفسير المسجَّل
  int? _tafsirAudioAyah;
  int? _tafsirLoadingAyah;

  // النطق الآلي
  bool _speakingTafsir = false;
  List<String> _speechChunks = [];
  int _speechIndex = 0;
  double _speechRate = 0.42;

  static const _kReciterPrefKey = 'selected_reciter';
  static const _kVoicePrefName = 'tts_voice_name';
  static const _kVoicePrefLocale = 'tts_voice_locale';
  static const _kRatePref = 'tts_rate';

  /// فهرس الآية الجارية داخل السورة (أو -1)
  int get _currentIndex => _playingAyah == null ? -1 : _ayat.indexWhere((a) => a.number == _playingAyah);

  Future<List<Ayah>> _loadVerses() async {
    final v = await _api.getSurahVerses(widget.surah.number);
    _ayat = v;
    return v;
  }

  @override
  void initState() {
    super.initState();
    _versesFuture = _loadVerses();

    _player.playerStateStream.listen((s) {
      if (!mounted) return;
      if (s.processingState == ProcessingState.completed) {
        setState(() {
          _playingAyah = null;
          _isPlaying = false;
        });
      } else if (_isPlaying != s.playing) {
        setState(() => _isPlaying = s.playing);
      }
    });

    // عند الانتقال لآية جديدة داخل قائمة التشغيل: نميّزها ونجعلها مرئية
    _player.currentIndexStream.listen((i) {
      if (!mounted || i == null) return;
      final idx = _startOffset + i;
      if (idx < 0 || idx >= _ayat.length) return;
      setState(() => _playingAyah = _ayat[idx].number);
      _scrollToAyah(idx);
    });

    // خطأ في تحميل ملف صوت (انقطاع نت أو قارئ غير متاح)
    _player.playbackEventStream.listen((_) {}, onError: (Object e, StackTrace st) {
      if (!mounted) return;
      setState(() {
        _playingAyah = null;
        _isPlaying = false;
      });
      _snack('تعذّر تشغيل التلاوة، تحقق من الاتصال بالإنترنت أو جرّب قارئًا آخر');
    });

    _tafsirPlayer.playerStateStream.listen((s) {
      if (!mounted) return;
      if (s.processingState == ProcessingState.completed && _tafsirAudioAyah != null) {
        setState(() => _tafsirAudioAyah = null);
      }
    });

    _tts.setCompletionHandler(() {
      if (!mounted) return;
      if (_speakingTafsir) _speakNextChunk();
    });

    _initTts();
    _loadReciterPref();
  }

  @override
  void dispose() {
    _speakingTafsir = false;
    _player.dispose();
    _tafsirPlayer.dispose();
    _tts.stop();
    _scroll.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  void _scrollToAyah(int idx) {
    final ctx = _keys[idx]?.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 400), alignment: 0.15, curve: Curves.easeOut);
    } else if (_scroll.hasClients) {
      // العنصر خارج الشاشة ولم يُبنَ بعد: قفزة تقريبية ثم يصحّحها التمرير التالي
      final target = (idx * 190.0).clamp(0.0, _scroll.position.maxScrollExtent);
      _scroll.animateTo(target, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
    }
  }

  // ───────────────────────── التلاوة المتواصلة ─────────────────────────

  /// يشغّل السورة من الآية [index] حتى آخرها بتتابع بدون توقف
  Future<void> _playFrom(int index) async {
    if (_ayat.isEmpty || index < 0 || index >= _ayat.length) return;
    try {
      if (_speakingTafsir) await _stopTafsirSpeech();
      await _stopRecordedTafsir();
      _startOffset = index;
      setState(() => _playingAyah = _ayat[index].number);
      final sources = [
        for (final a in _ayat.sublist(index))
          AudioSource.uri(Uri.parse(QuranApiService.audioUrlForGlobalAyah(a.globalId, reciter: _reciter)))
      ];
      await _player.setAudioSource(ConcatenatingAudioSource(children: sources), initialIndex: 0);
      await _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
      _player.play(); // لا ننتظر اكتمال التشغيل (يستمر حتى نهاية السورة)
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _playingAyah = null;
        _isPlaying = false;
      });
      _snack('تعذّر تشغيل التلاوة، تحقق من الاتصال بالإنترنت');
    }
  }

  /// زر الآية: إن كانت هي الجارية يوقف/يستأنف مؤقتًا، وإلا يبدأ منها ويكمل للنهاية
  Future<void> _onAyahPlayTap(int index) async {
    final a = _ayat[index];
    if (_playingAyah == a.number) {
      if (_player.playing) {
        await _player.pause();
      } else {
        await _player.play();
      }
      return;
    }
    await _playFrom(index);
  }

  Future<void> _stopRecitation() async {
    await _player.stop();
    if (!mounted) return;
    setState(() {
      _playingAyah = null;
      _isPlaying = false;
    });
  }

  Future<void> _loadReciterPref() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_kReciterPrefKey);
    if (saved != null && QuranApiService.reciters.any((r) => r.$1 == saved) && mounted) {
      setState(() => _reciter = saved);
    }
  }

  Future<void> _setReciter(String code) async {
    final resumeAt = _currentIndex;
    setState(() => _reciter = code);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kReciterPrefKey, code);
    // لو كانت التلاوة جارية نكمل من نفس الآية بصوت القارئ الجديد
    if (resumeAt >= 0) await _playFrom(resumeAt);
  }

  void _showReciterPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.paper,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('اختر القارئ', style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                ...QuranApiService.reciters.map((r) => ListTile(
                      title: Text(r.$2, style: GoogleFonts.tajawal(fontSize: 14.5)),
                      trailing: _reciter == r.$1 ? const Icon(Icons.check_circle, color: AppColors.emerald) : null,
                      onTap: () {
                        Navigator.pop(context);
                        _setReciter(r.$1);
                      },
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ───────────────────── التفسير المسجَّل بصوت بشري ─────────────────────

  Future<void> _stopRecordedTafsir() async {
    if (_tafsirAudioAyah == null && _tafsirLoadingAyah == null) return;
    await _tafsirPlayer.stop();
    if (mounted) {
      setState(() {
        _tafsirAudioAyah = null;
        _tafsirLoadingAyah = null;
      });
    }
  }

  Future<void> _toggleRecordedTafsir(Ayah a) async {
    if (_tafsirAudioAyah == a.number) {
      await _stopRecordedTafsir();
      return;
    }
    setState(() => _tafsirLoadingAyah = a.number);
    try {
      final seg = await TafsirAudioService.segmentFor(widget.surah.number, a.number);
      if (seg == null) {
        if (!mounted) return;
        setState(() => _tafsirLoadingAyah = null);
        _snack('لا يتوفر تسجيل مسموع للتفسير لهذه الآية. جرّب «نطق آلي لنص السعدي».');
        return;
      }
      // لا نتكلم فوق صوت التلاوة أو النطق الآلي
      if (_player.playing) await _player.pause();
      if (_speakingTafsir) await _stopTafsirSpeech();
      await _tafsirPlayer.setUrl(seg.url);
      if (!mounted) return;
      setState(() {
        _tafsirLoadingAyah = null;
        _tafsirAudioAyah = a.number;
      });
      final range = seg.endAyah >= 9999 ? 'السورة كاملة' : 'الآيات ${seg.startAyah}–${seg.endAyah}';
      _snack('يُشغَّل مقطع التفسير الذي يغطي $range، ويبدأ من أول المقطع.');
      _tafsirPlayer.play();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _tafsirLoadingAyah = null;
        _tafsirAudioAyah = null;
      });
      _snack('تعذّر تحميل التفسير المسجَّل، تحقق من الاتصال بالإنترنت');
    }
  }

  // ───────────────────────── النطق الآلي لنص السعدي ─────────────────────────

  /// إعداد صوت النطق الآلي: يفضّل أي صوت عربي مثبّت على الجهاز (محرك Google
  /// غالبًا أوضح)، مع سرعة أهدأ من الافتراضية.
  Future<void> _initTts() async {
    final prefs = await SharedPreferences.getInstance();
    _speechRate = prefs.getDouble(_kRatePref) ?? 0.42;
    await _tts.setSpeechRate(_speechRate);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);

    final savedName = prefs.getString(_kVoicePrefName);
    final savedLocale = prefs.getString(_kVoicePrefLocale);
    if (savedName != null && savedLocale != null) {
      await _tts.setVoice({'name': savedName, 'locale': savedLocale});
      return;
    }

    try {
      final arabicVoices = await _availableArabicVoices();
      if (arabicVoices.isNotEmpty) {
        final best = arabicVoices.firstWhere(
          (v) => v['name']!.toLowerCase().contains('google'),
          orElse: () => arabicVoices.first,
        );
        await _tts.setVoice({'name': best['name']!, 'locale': best['locale']!});
      } else {
        await _tts.setLanguage('ar');
      }
    } catch (_) {
      await _tts.setLanguage('ar');
    }
  }

  Future<List<Map<String, String>>> _availableArabicVoices() async {
    try {
      final voices = await _tts.getVoices;
      if (voices is! List) return [];
      return voices
          .whereType<Map>()
          .where((v) => (v['locale'] as String? ?? '').toLowerCase().startsWith('ar'))
          .map((v) => <String, String>{
                'name': v['name'] as String? ?? '',
                'locale': v['locale'] as String? ?? '',
              })
          .where((v) => v['name']!.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _setTtsVoice(String name, String locale) async {
    await _tts.setVoice({'name': name, 'locale': locale});
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kVoicePrefName, name);
    await prefs.setString(_kVoicePrefLocale, locale);
  }

  Future<void> _setSpeechRate(double r) async {
    _speechRate = r;
    await _tts.setSpeechRate(r);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kRatePref, r);
  }

  /// يقسّم نص التفسير لمقاطع قصيرة عند علامات الوقف. محرك النطق في أندرويد
  /// يتعثر مع النصوص الطويلة جدًا (وله حد أقصى لطول النص)، والمقاطع القصيرة
  /// تعطي نطقًا أوضح وتمنع انقطاع القراءة في منتصف التفسير.
  List<String> _splitForSpeech(String text) {
    final parts = text
        .replaceAll(RegExp(r'\s+'), ' ')
        .split(RegExp(r'(?<=[.،؛؟!:])\s+'))
        .where((p) => p.trim().isNotEmpty)
        .toList();
    final chunks = <String>[];
    var current = '';
    for (final p in parts) {
      if (current.isNotEmpty && (current.length + p.length) > 400) {
        chunks.add(current);
        current = p;
      } else {
        current = current.isEmpty ? p : '$current $p';
      }
    }
    if (current.isNotEmpty) chunks.add(current);
    return chunks;
  }

  Future<void> _speakNextChunk() async {
    if (!_speakingTafsir) return;
    if (_speechIndex >= _speechChunks.length) {
      if (mounted) setState(() => _speakingTafsir = false);
      return;
    }
    await _tts.speak(_speechChunks[_speechIndex++]);
  }

  Future<void> _stopTafsirSpeech() async {
    _speakingTafsir = false;
    await _tts.stop();
    if (mounted) setState(() {});
  }

  Future<void> _toggleTafsirSpeech(String text) async {
    if (_speakingTafsir) {
      await _stopTafsirSpeech();
      return;
    }
    // لا نتكلم فوق صوت التلاوة أو التفسير المسجَّل
    if (_player.playing) await _player.pause();
    await _stopRecordedTafsir();
    _speechChunks = _splitForSpeech(text);
    _speechIndex = 0;
    setState(() => _speakingTafsir = true);
    await _speakNextChunk();
  }

  /// يفتح إعدادات النطق في أندرويد حيث يمكن تنزيل أصوات عربية عالية الجودة
  /// وتغيير محرك النطق (مثل Google Text-to-Speech أو Samsung TTS)
  Future<void> _openSystemTtsSettings() async {
    try {
      await const AndroidIntent(action: 'com.android.settings.TTS_SETTINGS').launch();
    } catch (_) {
      _snack('افتح: الإعدادات ← إمكانية الوصول (أو النظام) ← تحويل النص إلى كلام');
    }
  }

  void _showVoicePicker() async {
    final voices = await _availableArabicVoices();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.paper,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: StatefulBuilder(
              builder: (context, setSheet) => Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('إعدادات النطق الآلي', style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text('الأصوات مثبّتة على جهازك وليست من التطبيق، وجودتها تعتمد على محرك النطق عندك',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft, height: 1.6)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Text('السرعة', style: GoogleFonts.tajawal(fontSize: 13, fontWeight: FontWeight.w800)),
                      Expanded(
                        child: Slider(
                          value: _speechRate,
                          min: 0.25,
                          max: 0.75,
                          divisions: 10,
                          activeColor: AppColors.emerald,
                          onChanged: (v) {
                            setSheet(() => _speechRate = v);
                          },
                          onChangeEnd: _setSpeechRate,
                        ),
                      ),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _openSystemTtsSettings();
                    },
                    icon: const Icon(Icons.settings_voice_outlined, size: 18),
                    label: Text('تنزيل أصوات عربية أفضل / تغيير محرك النطق',
                        style: GoogleFonts.tajawal(fontSize: 12.5, fontWeight: FontWeight.w800)),
                  ),
                  if (voices.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text('لم يُعثر على أصوات عربية مثبّتة. استخدم الزر أعلاه لتنزيل صوت عربي.',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.inkSoft, height: 1.6)),
                    )
                  else
                    ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
                      child: ListView(
                        shrinkWrap: true,
                        children: voices
                            .map((v) => ListTile(
                                  title: Text(v['name']!, style: GoogleFonts.tajawal(fontSize: 13.5)),
                                  subtitle: Text(v['locale']!, style: GoogleFonts.tajawal(fontSize: 10.5)),
                                  trailing: IconButton(
                                    icon: const Icon(Icons.volume_up, color: AppColors.emerald),
                                    onPressed: () async {
                                      await _tts.setVoice({'name': v['name']!, 'locale': v['locale']!});
                                      await _tts.speak('هذا نموذج لصوت قراءة التفسير');
                                    },
                                  ),
                                  onTap: () {
                                    _setTtsVoice(v['name']!, v['locale']!);
                                    Navigator.pop(context);
                                    _snack('تم حفظ الصوت المختار');
                                  },
                                ))
                            .toList(),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ───────────────────────────── الواجهة ─────────────────────────────

  Widget _playerBar() {
    final idx = _currentIndex;
    return Material(
      color: AppColors.night2,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            children: [
              IconButton(
                tooltip: 'إيقاف',
                icon: const Icon(Icons.stop, color: Colors.white70),
                onPressed: _stopRecitation,
              ),
              Expanded(
                child: Text(
                  idx >= 0 ? 'الآية ${_ayat[idx].number} من ${_ayat.length}' : '',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.tajawal(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.goldBright),
                ),
              ),
              IconButton(
                tooltip: 'الآية السابقة',
                icon: const Icon(Icons.skip_next, color: Colors.white),
                onPressed: () => _player.seekToPrevious(),
              ),
              IconButton(
                tooltip: _isPlaying ? 'إيقاف مؤقت' : 'متابعة',
                iconSize: 34,
                icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
                    color: AppColors.goldBright),
                onPressed: () => _isPlaying ? _player.pause() : _player.play(),
              ),
              IconButton(
                tooltip: 'الآية التالية',
                icon: const Icon(Icons.skip_previous, color: Colors.white),
                onPressed: () => _player.seekToNext(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _errorView(Object? error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off, size: 40, color: AppColors.inkSoft),
            const SizedBox(height: 12),
            Text('تعذّر تحميل السورة.', textAlign: TextAlign.center, style: GoogleFonts.tajawal(height: 1.8)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => setState(() => _versesFuture = _loadVerses()),
              child: const Text('إعادة المحاولة'),
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: AppColors.paperDim, borderRadius: BorderRadius.circular(10)),
              child: SelectableText(
                'تفاصيل تقنية (أرسل صورة لهذا النص):\n${error ?? "لا توجد بيانات في الاستجابة"}',
                style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _ayahTile(int i, Ayah a) {
    final playing = _playingAyah == a.number && _isPlaying;
    final current = _playingAyah == a.number;
    final expanded = _expandedAyah == a.number;
    final recorded = _tafsirAudioAyah == a.number;
    return KeyedSubtree(
      key: _keys.putIfAbsent(i, () => GlobalKey()),
      child: Container(
        decoration: BoxDecoration(
          color: current ? AppColors.emerald.withOpacity(0.10) : AppColors.paperDim,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: current ? AppColors.emerald : AppColors.emerald.withOpacity(0.18), width: current ? 1.6 : 1),
        ),
        child: Column(
          children: [
            ListTile(
              onTap: a.tafsirText == null ? null : () => setState(() => _expandedAyah = expanded ? null : a.number),
              leading: IconButton(
                icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                    color: AppColors.emerald, size: 32),
                onPressed: () => _onAyahPlayTap(i),
              ),
              title: Text('${a.arabicText} ﴿${a.number}﴾',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.amiri(fontSize: 22, height: 2, color: AppColors.ink)),
              subtitle: (expanded || a.tafsirText == null)
                  ? null
                  : Center(
                      child: Text('اضغط لعرض التفسير',
                          style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft))),
            ),
            if (expanded && a.tafsirText != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('تفسير السعدي',
                        style: GoogleFonts.tajawal(fontSize: 13, color: AppColors.gold, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        ActionChip(
                          avatar: _tafsirLoadingAyah == a.number
                              ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                              : Icon(recorded ? Icons.stop_circle : Icons.headphones,
                                  size: 18, color: AppColors.emerald),
                          label: Text(recorded ? 'إيقاف التفسير المسجَّل' : 'استماع بصوت قارئ',
                              style: GoogleFonts.tajawal(fontSize: 12, fontWeight: FontWeight.w800)),
                          onPressed: _tafsirLoadingAyah == null ? () => _toggleRecordedTafsir(a) : null,
                        ),
                        ActionChip(
                          avatar: Icon(_speakingTafsir ? Icons.stop_circle : Icons.record_voice_over,
                              size: 18, color: AppColors.inkSoft),
                          label: Text(_speakingTafsir ? 'إيقاف' : 'نطق آلي لنص السعدي',
                              style: GoogleFonts.tajawal(fontSize: 12)),
                          onPressed: () => _toggleTafsirSpeech(a.tafsirText!),
                        ),
                        ActionChip(
                          avatar: const Icon(Icons.tune, size: 16, color: AppColors.inkSoft),
                          label: Text('الصوت', style: GoogleFonts.tajawal(fontSize: 12)),
                          onPressed: _showVoicePicker,
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                        'التسجيل البشري: ${TafsirAudioService.collectionName} (مقطع يغطي هذه الآية)، وليس قراءة لنص السعدي المكتوب.',
                        style: GoogleFonts.tajawal(fontSize: 10.5, color: AppColors.inkSoft, height: 1.6)),
                    const SizedBox(height: 8),
                    Text(a.tafsirText!,
                        style: GoogleFonts.tajawal(
                            fontSize: 19, color: AppColors.ink, fontWeight: FontWeight.w700, height: 2.1)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('سورة ${widget.surah.nameArabic}'),
          actions: [
            IconButton(
              tooltip: 'تشغيل السورة كاملة',
              icon: const Icon(Icons.playlist_play, color: AppColors.goldBright, size: 28),
              onPressed: _ayat.isEmpty ? null : () => _playFrom(0),
            ),
            IconButton(
              tooltip: 'اختيار القارئ',
              icon: const Icon(Icons.record_voice_over_outlined, color: Colors.white70),
              onPressed: _showReciterPicker,
            ),
            IconButton(
              tooltip: 'وضع الترديد (تكرار الآية)',
              icon: Icon(Icons.repeat, color: _repeat ? AppColors.goldBright : Colors.white70),
              onPressed: () {
                setState(() => _repeat = !_repeat);
                _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
              },
            ),
          ],
        ),
        bottomNavigationBar: _playingAyah == null ? null : _playerBar(),
        body: FutureBuilder<List<Ayah>>(
          future: _versesFuture,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError || snap.data == null || snap.data!.isEmpty) {
              return _errorView(snap.error);
            }
            final ayat = snap.data!;
            return ListView.separated(
              controller: _scroll,
              padding: const EdgeInsets.all(14),
              itemCount: ayat.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) => _ayahTile(i, ayat[i]),
            );
          },
        ),
      ),
    );
  }
}
