import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import '../../../core/services/quran_api_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/surah_model.dart';

/// قراءة السورة: النص العثماني والتفسير من Quran.com API، والتلاوة بصوت العفاسي.
/// يتطلب اتصالاً بالإنترنت.
class SurahReaderScreen extends StatefulWidget {
  const SurahReaderScreen({super.key, required this.surah});
  final Surah surah;
  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  final _api = QuranApiService();
  final _player = AudioPlayer();
  late Future<List<Ayah>> _versesFuture;
  final Map<int, Future<Tafsir>> _tafsirCache = {};
  int? _playingAyah;
  int? _expandedAyah;
  bool _repeat = false;

  @override
  void initState() {
    super.initState();
    _versesFuture = _api.getSurahVerses(widget.surah.number);
    _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed && mounted) {
        setState(() => _playingAyah = null);
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  String _audioUrl(int ayah) {
    final s = widget.surah.number.toString().padLeft(3, '0');
    final a = ayah.toString().padLeft(3, '0');
    return 'https://verses.quran.com/Alafasy/mp3/$s$a.mp3';
  }

  Future<void> _toggleAudio(int ayah) async {
    try {
      if (_playingAyah == ayah) {
        await _player.stop();
        setState(() => _playingAyah = null);
        return;
      }
      setState(() => _playingAyah = ayah);
      await _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
      await _player.setUrl(_audioUrl(ayah));
      await _player.play();
    } catch (_) {
      if (!mounted) return;
      setState(() => _playingAyah = null);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تعذّر تشغيل التلاوة، تحقق من الاتصال بالإنترنت')));
    }
  }

  Future<Tafsir> _tafsirFor(int ayah) => _tafsirCache.putIfAbsent(
      ayah, () => _api.getAyahTafsir('${widget.surah.number}:$ayah'));

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('سورة ${widget.surah.nameArabic}'),
          actions: [
            IconButton(
              tooltip: 'وضع الترديد (تكرار الآية)',
              icon: Icon(Icons.repeat, color: _repeat ? AppColors.goldBright : Colors.white70),
              onPressed: () {
                setState(() => _repeat = !_repeat);
                _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
              },
            ),
          ],
        ),
        body: FutureBuilder<List<Ayah>>(
          future: _versesFuture,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError || snap.data == null) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.wifi_off, size: 40, color: AppColors.inkSoft),
                      const SizedBox(height: 12),
                      Text('تعذّر تحميل السورة.\nتحقق من الاتصال بالإنترنت وحاول مجددًا.',
                          textAlign: TextAlign.center, style: GoogleFonts.tajawal(height: 1.8)),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => setState(
                            () => _versesFuture = _api.getSurahVerses(widget.surah.number)),
                        child: const Text('إعادة المحاولة'),
                      ),
                    ],
                  ),
                ),
              );
            }
            final ayat = snap.data!;
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: ayat.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final a = ayat[i];
                final playing = _playingAyah == a.number;
                final expanded = _expandedAyah == a.number;
                return Container(
                  decoration: BoxDecoration(
                    color: AppColors.paperDim,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        onTap: () => setState(() => _expandedAyah = expanded ? null : a.number),
                        leading: IconButton(
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                              color: AppColors.emerald, size: 32),
                          onPressed: () => _toggleAudio(a.number),
                        ),
                        title: Text('${a.arabicText} ﴿${a.number}﴾',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.amiri(fontSize: 22, height: 2, color: AppColors.ink)),
                        subtitle: expanded
                            ? null
                            : Center(
                                child: Text('اضغط لعرض التفسير',
                                    style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft))),
                      ),
                      if (expanded)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                          child: FutureBuilder<Tafsir>(
                            future: _tafsirFor(a.number),
                            builder: (context, t) {
                              if (t.connectionState != ConnectionState.done) {
                                return const Padding(
                                  padding: EdgeInsets.all(8),
                                  child: LinearProgressIndicator(),
                                );
                              }
                              if (t.hasError || t.data == null) {
                                return Text('تعذّر تحميل التفسير.',
                                    style: GoogleFonts.tajawal(color: AppColors.inkSoft));
                              }
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(t.data!.resourceName,
                                      style: GoogleFonts.tajawal(
                                          fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                                  const SizedBox(height: 6),
                                  Text(t.data!.text,
                                      style: GoogleFonts.tajawal(
                                          fontSize: 13.5, color: AppColors.inkSoft, height: 1.9)),
                                ],
                              );
                            },
                          ),
                        ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
