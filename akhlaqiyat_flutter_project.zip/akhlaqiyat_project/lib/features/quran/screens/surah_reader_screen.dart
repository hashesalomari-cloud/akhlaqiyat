import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/services/quran_api_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/surah_model.dart';

/// قراءة السورة: النص العثماني وتفسير السعدي من islamic.app (خدمة
/// مجانية بلا تسجيل)، والتلاوة بصوت العفاسي. يتطلب اتصالاً بالإنترنت.
class SurahReaderScreen extends StatefulWidget {
  const SurahReaderScreen({super.key, required this.surah});
  final Surah surah;
  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  final _api = QuranApiService();
  final _player = AudioPlayer();
  final _tts = FlutterTts();
  late Future<List<Ayah>> _versesFuture;
  int? _playingAyah;
  int? _expandedAyah;
  bool _repeat = false;
  bool _speakingTafsir = false;
  String _reciter = QuranApiService.defaultReciter;

  static const _kReciterPrefKey = 'selected_reciter';

  @override
  void initState() {
    super.initState();
    _versesFuture = _api.getSurahVerses(widget.surah.number);
    _player.playerStateStream.listen((s) {
      if (s.processingState == ProcessingState.completed && mounted) {
        setState(() => _playingAyah = null);
      }
    });
    _tts.setCompletionHandler(() {
      if (mounted) setState(() => _speakingTafsir = false);
    });
    _initTts();
    _loadReciterPref();
  }

  static const _kVoicePrefName = 'tts_voice_name';
  static const _kVoicePrefLocale = 'tts_voice_locale';

  /// إعداد صوت قراءة التفسير: يفضّل أي صوت عربي مثبّت على الجهاز
  /// (محرك Google للنطق عادة يقدّم أصواتًا عربية أوضح من الصوت
  /// الافتراضي)، ويخفّض سرعة النطق قليلًا فهذا وحده يحسّن الوضوح
  /// بشكل ملحوظ مقارنة بالسرعة الافتراضية.
  Future<void> _initTts() async {
    await _tts.setSpeechRate(0.42);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);

    final prefs = await SharedPreferences.getInstance();
    final savedName = prefs.getString(_kVoicePrefName);
    final savedLocale = prefs.getString(_kVoicePrefLocale);
    if (savedName != null && savedLocale != null) {
      await _tts.setVoice({'name': savedName, 'locale': savedLocale});
      return;
    }

    // لا يوجد اختيار محفوظ: يحاول اختيار أفضل صوت عربي متاح تلقائيًا
    // بدل الاعتماد على صوت اللغة الافتراضي للجهاز.
    try {
      final voices = await _tts.getVoices;
      if (voices is List) {
        final arabicVoices = voices
            .whereType<Map>()
            .where((v) => (v['locale'] as String? ?? '').toLowerCase().startsWith('ar'))
            .toList();
        if (arabicVoices.isNotEmpty) {
          // يفضّل محرك Google (يعطي أصواتًا طبيعية أكثر) إن وُجد، وإلا
          // يأخذ أول صوت عربي متاح.
          final best = arabicVoices.firstWhere(
            (v) => (v['name'] as String? ?? '').toLowerCase().contains('google'),
            orElse: () => arabicVoices.first,
          );
          await _tts.setVoice({
            'name': best['name'] as String,
            'locale': best['locale'] as String,
          });
        } else {
          await _tts.setLanguage('ar');
        }
      } else {
        await _tts.setLanguage('ar');
      }
    } catch (_) {
      await _tts.setLanguage('ar');
    }
  }

  Future<List<Map<String, String>>> _availableArabicVoices() async {
    try {
      final voices = await _tts.getVoices;
      if (voices is! List) return [];
      return voices
          .whereType<Map>()
          .where((v) => (v['locale'] as String? ?? '').toLowerCase().startsWith('ar'))
          .map((v) => {
                'name': v['name'] as String? ?? '',
                'locale': v['locale'] as String? ?? '',
              })
          .where((v) => v['name']!.isNotEmpty)
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _setTtsVoice(String name, String locale) async {
    await _tts.setVoice({'name': name, 'locale': locale});
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kVoicePrefName, name);
    await prefs.setString(_kVoicePrefLocale, locale);
  }

  Future<void> _loadReciterPref() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_kReciterPrefKey);
    if (saved != null && mounted) setState(() => _reciter = saved);
  }

  Future<void> _setReciter(String code) async {
    setState(() => _reciter = code);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kReciterPrefKey, code);
  }

  Future<void> _toggleTafsirSpeech(String text) async {
    if (_speakingTafsir) {
      await _tts.stop();
      setState(() => _speakingTafsir = false);
      return;
    }
    setState(() => _speakingTafsir = true);
    await _tts.speak(text);
  }

  void _showVoicePicker() async {
    final voices = await _availableArabicVoices();
    if (!mounted) return;
    if (voices.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('جهازك لا يوفّر أصوات عربية متعددة. جرّب تثبيت "Google Text-to-Speech" من متجر Play للحصول على صوت أوضح.')));
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.paper,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('اختر صوت قراءة التفسير', style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('الأصوات المتاحة مثبّتة على جهازك، وليست من التطبيق',
                    style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft)),
                const SizedBox(height: 12),
                ConstrainedBox(
                  constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
                  child: ListView(
                    shrinkWrap: true,
                    children: voices
                        .map((v) => ListTile(
                              title: Text(v['name']!, style: GoogleFonts.tajawal(fontSize: 13.5)),
                              subtitle: Text(v['locale']!, style: GoogleFonts.tajawal(fontSize: 10.5)),
                              trailing: IconButton(
                                icon: const Icon(Icons.volume_up, color: AppColors.emerald),
                                onPressed: () => _tts.speak('هذا نموذج لصوت قراءة التفسير'),
                              ),
                              onTap: () {
                                _setTtsVoice(v['name']!, v['locale']!);
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('تم حفظ الصوت المختار')));
                              },
                            ))
                        .toList(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _player.dispose();
    _tts.stop();
    super.dispose();
  }

  Future<void> _toggleAudio(Ayah a) async {
    try {
      if (_playingAyah == a.number) {
        await _player.stop();
        setState(() => _playingAyah = null);
        return;
      }
      setState(() => _playingAyah = a.number);
      await _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
      await _player.setUrl(QuranApiService.audioUrlForGlobalAyah(a.globalId, reciter: _reciter));
      await _player.play();
    } catch (_) {
      if (!mounted) return;
      setState(() => _playingAyah = null);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تعذّر تشغيل التلاوة، تحقق من الاتصال بالإنترنت')));
    }
  }

  void _showReciterPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.paper,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('اختر القارئ',
                    style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                ...QuranApiService.reciters.map((r) => ListTile(
                      title: Text(r.$2, style: GoogleFonts.tajawal(fontSize: 14.5)),
                      trailing: _reciter == r.$1
                          ? const Icon(Icons.check_circle, color: AppColors.emerald)
                          : null,
                      onTap: () {
                        _setReciter(r.$1);
                        Navigator.pop(context);
                      },
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('سورة ${widget.surah.nameArabic}'),
          actions: [
            IconButton(
              tooltip: 'اختيار القارئ',
              icon: const Icon(Icons.record_voice_over_outlined, color: Colors.white70),
              onPressed: _showReciterPicker,
            ),
            IconButton(
              tooltip: 'وضع الترديد (تكرار الآية)',
              icon: Icon(Icons.repeat, color: _repeat ? AppColors.goldBright : Colors.white70),
              onPressed: () {
                setState(() => _repeat = !_repeat);
                _player.setLoopMode(_repeat ? LoopMode.one : LoopMode.off);
              },
            ),
          ],
        ),
        body: FutureBuilder<List<Ayah>>(
          future: _versesFuture,
          builder: (context, snap) {
            if (snap.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError || snap.data == null || snap.data!.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.wifi_off, size: 40, color: AppColors.inkSoft),
                      const SizedBox(height: 12),
                      Text('تعذّر تحميل السورة.',
                          textAlign: TextAlign.center, style: GoogleFonts.tajawal(height: 1.8)),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => setState(
                            () => _versesFuture = _api.getSurahVerses(widget.surah.number)),
                        child: const Text('إعادة المحاولة'),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.paperDim,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: SelectableText(
                          'تفاصيل تقنية (أرسل صورة لهذا النص):\n${snap.error ?? "لا توجد بيانات في الاستجابة"}',
                          style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }
            final ayat = snap.data!;
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: ayat.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final a = ayat[i];
                final playing = _playingAyah == a.number;
                final expanded = _expandedAyah == a.number;
                return Container(
                  decoration: BoxDecoration(
                    color: AppColors.paperDim,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        onTap: a.tafsirText == null
                            ? null
                            : () => setState(() => _expandedAyah = expanded ? null : a.number),
                        leading: IconButton(
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                              color: AppColors.emerald, size: 32),
                          onPressed: () => _toggleAudio(a),
                        ),
                        title: Text('${a.arabicText} ﴿${a.number}﴾',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.amiri(fontSize: 22, height: 2, color: AppColors.ink)),
                        subtitle: (expanded || a.tafsirText == null)
                            ? null
                            : Center(
                                child: Text('اضغط لعرض التفسير',
                                    style: GoogleFonts.tajawal(fontSize: 11, color: AppColors.inkSoft))),
                      ),
                      if (expanded && a.tafsirText != null)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text('تفسير السعدي',
                                      style: GoogleFonts.tajawal(
                                          fontSize: 13, color: AppColors.gold, fontWeight: FontWeight.w900)),
                                  const Spacer(),
                                  InkWell(
                                    onTap: _showVoicePicker,
                                    borderRadius: BorderRadius.circular(20),
                                    child: const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                      child: Icon(Icons.tune, size: 16, color: AppColors.inkSoft),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  InkWell(
                                    onTap: () => _toggleTafsirSpeech(a.tafsirText!),
                                    borderRadius: BorderRadius.circular(20),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      child: Row(
                                        children: [
                                          Icon(
                                            _speakingTafsir ? Icons.stop_circle : Icons.volume_up,
                                            size: 18,
                                            color: AppColors.emerald,
                                          ),
                                          const SizedBox(width: 4),
                                          Text(_speakingTafsir ? 'إيقاف' : 'استماع',
                                              style: GoogleFonts.tajawal(
                                                  fontSize: 11.5, color: AppColors.emerald, fontWeight: FontWeight.w700)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(a.tafsirText!,
                                  style: GoogleFonts.tajawal(
                                      fontSize: 19,
                                      color: AppColors.ink,
                                      fontWeight: FontWeight.w700,
                                      height: 2.1)),
                            ],
                          ),
                        ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
