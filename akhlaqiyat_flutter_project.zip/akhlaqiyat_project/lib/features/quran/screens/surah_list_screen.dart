import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/services/quran_bookmarks.dart';
import '../../../core/theme/app_theme.dart';
import '../models/surah_model.dart';
import 'surah_reader_screen.dart';

/// بدايات الأجزاء (سورة، آية) — مطابقة لبيانات alquran.cloud.
const _juzStarts = <List<int>>[
  [1, 1], [2, 142], [2, 253], [3, 93], [4, 24], [4, 148], [5, 82], [6, 111],
  [7, 88], [8, 41], [9, 93], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75],
  [21, 1], [23, 1], [25, 21], [27, 56], [29, 46], [33, 31], [36, 28], [39, 32],
  [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1],
];

/// تطبيع للبحث: يحذف التشكيل ويوحّد الألف والياء والتاء المربوطة.
String _norm(String s) {
  var t = s.replaceAll(RegExp(r'[ً-ٰٟـ]'), '');
  t = t
      .replaceAll(RegExp(r'[أإآٱ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ؤ', 'و')
      .replaceAll('ئ', 'ي');
  return t.trim().toLowerCase();
}

class SurahListScreen extends StatefulWidget {
  const SurahListScreen({super.key});
  @override
  State<SurahListScreen> createState() => _SurahListScreenState();
}

class _SurahListScreenState extends State<SurahListScreen> {
  String _query = '';
  int _tab = 0; // 0 سور، 1 أجزاء، 2 علاماتي
  late final Future<List<Surah>> _future = LocalDataService.surahs();

  void _open(Surah s, [int ayah = 1]) =>
      context.push('/quran/surah', extra: SurahReaderArgs(s, ayah));

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('القرآن الكريم')),
        body: FutureBuilder<List<Surah>>(
          future: _future,
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final all = snap.data!;
            return ValueListenableBuilder<int>(
              valueListenable: QuranBookmarks.version,
              builder: (context, _, __) => Column(
                children: [
                  _continueCard(all),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
                    child: SegmentedButton<int>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(value: 0, label: Text('السور')),
                        ButtonSegment(value: 1, label: Text('الأجزاء')),
                        ButtonSegment(value: 2, label: Text('علاماتي')),
                      ],
                      selected: {_tab},
                      onSelectionChanged: (v) => setState(() => _tab = v.first),
                    ),
                  ),
                  if (_tab == 0)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                      child: TextField(
                        onChanged: (v) => setState(() => _query = v),
                        style: AppFonts.ui(),
                        decoration: InputDecoration(
                          hintText: 'ابحث باسم السورة أو رقمها...',
                          filled: true,
                          fillColor: AppColors.paperDim,
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                  Expanded(
                    child: _tab == 0
                        ? _surahs(all)
                        : _tab == 1
                            ? _juzs(all)
                            : _marks(all),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _continueCard(List<Surah> all) {
    return FutureBuilder<QuranMark?>(
      future: QuranBookmarks.lastRead(),
      builder: (context, s) {
        final m = s.data;
        if (m == null) return const SizedBox.shrink();
        final idx = all.indexWhere((x) => x.number == m.surah);
        if (idx < 0) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 6),
          child: Material(
            color: AppColors.emeraldDeep,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => _open(all[idx], m.ayah),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Icon(Icons.menu_book_rounded, color: AppColors.goldBright),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('واصل القراءة',
                              style: AppFonts.ui(
                                  fontSize: 12, color: AppColors.onGrad.withOpacity(0.8))),
                          Text('سورة ${m.surahName} — الآية ${m.ayah}',
                              style: AppFonts.ui(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.onGrad)),
                        ],
                      ),
                    ),
                    Icon(Icons.chevron_left, color: AppColors.onGrad),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _surahs(List<Surah> all) {
    final q = _norm(_query);
    final list = q.isEmpty
        ? all
        : all
            .where((s) =>
                _norm(s.nameArabic).contains(q) ||
                '${s.number}' == q ||
                s.nameEnglish.toLowerCase().contains(q))
            .toList();
    if (list.isEmpty) {
      return Center(
          child: Text('لا توجد نتائج', style: AppFonts.ui(color: AppColors.inkSoft)));
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      itemCount: list.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) => _tile(
        number: '${list[i].number}',
        title: 'سورة ${list[i].nameArabic}',
        sub: '${list[i].versesCount} آية',
        onTap: () => _open(list[i]),
      ),
    );
  }

  Widget _juzs(List<Surah> all) {
    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      itemCount: _juzStarts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final st = _juzStarts[i];
        final s = all.firstWhere((x) => x.number == st[0]);
        return _tile(
          number: '${i + 1}',
          title: 'الجزء ${i + 1}',
          sub: 'يبدأ من سورة ${s.nameArabic} — الآية ${st[1]}',
          onTap: () => _open(s, st[1]),
        );
      },
    );
  }

  Widget _marks(List<Surah> all) {
    return FutureBuilder<List<QuranMark>>(
      future: QuranBookmarks.all(),
      builder: (context, s) {
        final marks = s.data ?? const <QuranMark>[];
        if (marks.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Text(
                'لا علامات بعد.\nاضغط أيقونة العلامة بجانب أي آية لحفظها هنا.',
                textAlign: TextAlign.center,
                style: AppFonts.ui(color: AppColors.inkSoft, height: 1.7),
              ),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          itemCount: marks.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final m = marks[i];
            final idx = all.indexWhere((x) => x.number == m.surah);
            return _tile(
              number: '${m.ayah}',
              title: 'سورة ${m.surahName}',
              sub: 'الآية ${m.ayah}',
              onTap: idx < 0 ? null : () => _open(all[idx], m.ayah),
              trailing: IconButton(
                icon: Icon(Icons.bookmark_remove_outlined, color: AppColors.inkSoft),
                onPressed: () => QuranBookmarks.toggle(m),
              ),
            );
          },
        );
      },
    );
  }

  Widget _tile({
    required String number,
    required String title,
    required String sub,
    VoidCallback? onTap,
    Widget? trailing,
  }) {
    return Material(
      color: AppColors.paperDim,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.gold, width: 1.4),
                ),
                child: Text(number,
                    style: AppFonts.ui(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.emeraldDeep)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: AppFonts.ui(fontSize: 15.5, fontWeight: FontWeight.w800)),
                    Text(sub, style: AppFonts.ui(fontSize: 11.5, color: AppColors.inkSoft)),
                  ],
                ),
              ),
              trailing ?? Icon(Icons.chevron_left, color: AppColors.inkSoft),
            ],
          ),
        ),
      ),
    );
  }
}
