import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/surah_model.dart';

class SurahListScreen extends StatefulWidget {
  const SurahListScreen({super.key});
  @override
  State<SurahListScreen> createState() => _SurahListScreenState();
}

class _SurahListScreenState extends State<SurahListScreen> {
  String _query = '';
  late final Future<List<Surah>> _future = LocalDataService.surahs();

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('القرآن الكريم')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: TextField(
                onChanged: (v) => setState(() => _query = v.trim()),
                style: GoogleFonts.tajawal(),
                decoration: InputDecoration(
                  hintText: 'ابحث عن سورة...',
                  filled: true,
                  fillColor: AppColors.paperDim,
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Surah>>(
                future: _future,
                builder: (context, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final list = snap.data!
                      .where((s) => s.nameArabic.contains(_query))
                      .toList();
                  return ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, i) => _SurahTile(surah: list[i]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SurahTile extends StatelessWidget {
  const _SurahTile({required this.surah});
  final Surah surah;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.paperDim,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => context.push('/quran/surah', extra: surah),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.gold, width: 1.4),
                ),
                child: Text('${surah.number}',
                    style: GoogleFonts.tajawal(
                        fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.emeraldDeep)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('سورة ${surah.nameArabic}',
                        style: GoogleFonts.tajawal(fontSize: 15.5, fontWeight: FontWeight.w800)),
                    Text('${surah.versesCount} آية',
                        style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.inkSoft)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left, color: AppColors.inkSoft),
            ],
          ),
        ),
      ),
    );
  }
}
