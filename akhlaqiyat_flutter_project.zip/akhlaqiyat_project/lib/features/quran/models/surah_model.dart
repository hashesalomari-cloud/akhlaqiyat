// نماذج القرآن.

class Surah {
  final int number;
  final String nameArabic;
  final String nameEnglish;
  final String revelationPlace;
  final int versesCount;

  const Surah({
    required this.number,
    required this.nameArabic,
    required this.nameEnglish,
    required this.revelationPlace,
    required this.versesCount,
  });
}

class Ayah {
  final int globalId; // الرقم المطلق للآية في كامل القرآن (1..6236) — يُستخدم لرابط الصوت
  final int number; // رقم الآية داخل السورة
  final String arabicText;
  final String? tafsirText;

  Ayah withNumber(int n) =>
      Ayah(globalId: globalId, number: n, arabicText: arabicText, tafsirText: tafsirText);

  const Ayah({
    required this.globalId,
    required this.number,
    required this.arabicText,
    this.tafsirText,
  });

  factory Ayah.fromJson(Map<String, dynamic> json) {
    final tafsirs = json['tafsirs'] as List?;
    // رقم الآية داخل السورة: نفضّل verse_key ("2:5") لأنه دائمًا نسبي للسورة.
    var number = json['verse_number'] as int;
    final key = json['verse_key'];
    if (key is String && key.contains(':')) {
      number = int.tryParse(key.split(':').last) ?? number;
    }
    return Ayah(
      globalId: json['id'] as int,
      number: number,
      arabicText: json['text_uthmani'] as String,
      tafsirText: (tafsirs != null && tafsirs.isNotEmpty)
          ? _stripHtml(tafsirs.first['text'] as String? ?? '')
          : null,
    );
  }

  static String _stripHtml(String s) => s.replaceAll(RegExp(r'<[^>]*>'), '').trim();
}
