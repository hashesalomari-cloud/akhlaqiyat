// نماذج القرآن.

class Surah {
  final int number;
  final String nameArabic;
  final String nameEnglish;
  final String revelationPlace;
  final int versesCount;

  const Surah({
    required this.number,
    required this.nameArabic,
    required this.nameEnglish,
    required this.revelationPlace,
    required this.versesCount,
  });
}

class Ayah {
  final int globalId; // الرقم المطلق للآية في كامل القرآن (1..6236) — يُستخدم لرابط الصوت
  final int number; // رقم الآية داخل السورة
  final String arabicText;
  final String? tafsirText; // تفسير السعدي (موسّع)
  final String? tafsirSimple; // التفسير الميسر (مختصر وواضح)

  bool get hasTafsir =>
      (tafsirText ?? '').isNotEmpty || (tafsirSimple ?? '').isNotEmpty;

  Ayah withNumber(int n) => Ayah(
      globalId: globalId,
      number: n,
      arabicText: arabicText,
      tafsirText: tafsirText,
      tafsirSimple: tafsirSimple);

  const Ayah({
    required this.globalId,
    required this.number,
    required this.arabicText,
    this.tafsirText,
    this.tafsirSimple,
  });

  factory Ayah.fromJson(Map<String, dynamic> json) {
    final tafsirs = json['tafsirs'] as List?;
    // رقم الآية داخل السورة: نفضّل verse_key ("2:5") لأنه دائمًا نسبي للسورة.
    var number = json['verse_number'] as int;
    final key = json['verse_key'];
    if (key is String && key.contains(':')) {
      number = int.tryParse(key.split(':').last) ?? number;
    }
    String? saadi, simple;
    if (tafsirs != null) {
      for (var i = 0; i < tafsirs.length; i++) {
        final t = tafsirs[i];
        if (t is! Map) continue;
        final txt = _stripHtml(t['text'] as String? ?? '');
        if (txt.isEmpty) continue;
        final id = '${t['slug'] ?? t['resource_slug'] ?? t['tafsir_slug'] ?? t['name'] ?? t['resource_name'] ?? ''}'
            .toLowerCase();
        if (id.contains('muyassar') || id.contains('ميسر')) {
          simple = txt;
        } else if (id.contains('sadd') || id.contains('saad') || id.contains('سعد')) {
          saadi = txt;
        } else {
          // لا معرّف في الرد: نعتمد ترتيب الطلب (الميسر ثم السعدي)
          if (i == 0) {
            simple ??= txt;
          } else {
            saadi ??= txt;
          }
        }
      }
    }
    return Ayah(
      globalId: json['id'] as int,
      number: number,
      arabicText: json['text_uthmani'] as String,
      tafsirText: saadi,
      tafsirSimple: simple,
    );
  }

  static String _stripHtml(String s) => s.replaceAll(RegExp(r'<[^>]*>'), '').trim();
}
