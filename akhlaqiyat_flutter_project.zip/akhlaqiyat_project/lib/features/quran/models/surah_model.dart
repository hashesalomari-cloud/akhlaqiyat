// نماذج البيانات الخاصة بالقرآن الكريم — مطابقة لاستجابة Quran.com API v4
// التوثيق: https://api-docs.quran.foundation

class Surah {
  final int number;
  final String nameArabic;
  final String nameEnglish;
  final String revelationPlace; // "meccan" | "medinan"
  final int versesCount;

  const Surah({
    required this.number,
    required this.nameArabic,
    required this.nameEnglish,
    required this.revelationPlace,
    required this.versesCount,
  });

  factory Surah.fromJson(Map<String, dynamic> json) {
    return Surah(
      number: json['id'] as int,
      nameArabic: json['name_arabic'] as String,
      nameEnglish: json['name_simple'] as String,
      revelationPlace: json['revelation_place'] as String,
      versesCount: json['verses_count'] as int,
    );
  }
}

class Ayah {
  final int number; // رقم الآية داخل السورة
  final String arabicText; // النص العربي (uthmani script)
  final String? audioUrl; // رابط تلاوة الآية للقارئ المختار
  final List<Tafsir> tafsirs;

  const Ayah({
    required this.number,
    required this.arabicText,
    this.audioUrl,
    this.tafsirs = const [],
  });

  factory Ayah.fromJson(Map<String, dynamic> json) {
    return Ayah(
      number: json['verse_number'] as int,
      arabicText: json['text_uthmani'] as String,
      audioUrl: json['audio']?['url'] as String?,
    );
  }
}

class Tafsir {
  final String resourceName; // مثال: "تفسير السعدي"
  final String text;

  const Tafsir({required this.resourceName, required this.text});

  factory Tafsir.fromJson(Map<String, dynamic> json) {
    return Tafsir(
      resourceName: json['resource_name'] as String,
      text: json['text'] as String,
    );
  }
}

class Reciter {
  final int id;
  final String name;
  const Reciter({required this.id, required this.name});

  factory Reciter.fromJson(Map<String, dynamic> json) {
    return Reciter(id: json['id'] as int, name: json['reciter_name'] as String);
  }
}
