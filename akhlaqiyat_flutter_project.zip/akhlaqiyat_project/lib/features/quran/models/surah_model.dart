// نماذج القرآن.

class Surah {
  final int number;
  final String nameArabic;
  final String nameEnglish;
  final String revelationPlace;
  final int versesCount;

  const Surah({
    required this.number,
    required this.nameArabic,
    required this.nameEnglish,
    required this.revelationPlace,
    required this.versesCount,
  });
}

class Ayah {
  final int globalId; // الرقم المطلق للآية في كامل القرآن (1..6236) — يُستخدم لرابط الصوت
  final int number; // رقم الآية داخل السورة
  final String arabicText;
  final String? tafsirText;

  const Ayah({
    required this.globalId,
    required this.number,
    required this.arabicText,
    this.tafsirText,
  });

  factory Ayah.fromJson(Map<String, dynamic> json) {
    final tafsirs = json['tafsirs'] as List?;
    return Ayah(
      globalId: json['id'] as int,
      number: json['verse_number'] as int,
      arabicText: json['text_uthmani'] as String,
      tafsirText: (tafsirs != null && tafsirs.isNotEmpty)
          ? _stripHtml(tafsirs.first['text'] as String? ?? '')
          : null,
    );
  }

  static String _stripHtml(String s) => s.replaceAll(RegExp(r'<[^>]*>'), '').trim();
}
