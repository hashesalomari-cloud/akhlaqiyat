import 'package:flutter/material.dart';
import '../../core/services/local_data_service.dart';
import '../../core/theme/app_theme.dart';

/// مقتطفات من كتب ابن القيم، كل واحدة بمصدرها وموضعها.
class HikamScreen extends StatelessWidget {
  const HikamScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('من كلام ابن القيم')),
        body: FutureBuilder<Map<String, dynamic>>(
          future: LocalDataService.hikam(),
          builder: (context, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final d = snap.data!;
            final items = (d['items'] as List).cast<Map<String, dynamic>>();
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
              itemCount: items.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                if (i == 0) {
                  return Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.paperDim,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text('${d['author']}\n${d['note']}',
                        style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft, height: 1.8)),
                  );
                }
                final it = items[i - 1];
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.paperDim,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.gold.withOpacity(0.35)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(it['theme'] as String,
                          style: AppFonts.ui(
                              fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      Text('«${it['text']}»',
                          style: AppFonts.ui(
                              fontSize: 18, fontWeight: FontWeight.w800, height: 2, color: AppColors.ink)),
                      const SizedBox(height: 6),
                      Text('${it['book']} — ص ${it['page']} — ${it['chapter']}',
                          style: AppFonts.ui(fontSize: 11.5, color: AppColors.inkSoft)),
                      const SizedBox(height: 8),
                      Text('الفائدة: ${it['benefit']}',
                          style: AppFonts.ui(fontSize: 13.5, color: AppColors.ink, height: 1.9)),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
