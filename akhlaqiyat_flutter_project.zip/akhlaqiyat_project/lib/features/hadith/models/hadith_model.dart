// نماذج الحديث الشريف.

enum HadithGrade { sahih, hasan, daif, unknown }

class Hadith {
  final int hadithNumber;
  final String bookName;
  final String arabicText;
  final String meaning;
  final String narrator;
  final String reference;
  final HadithGrade grade;

  const Hadith({
    required this.hadithNumber,
    required this.bookName,
    required this.arabicText,
    required this.meaning,
    required this.narrator,
    required this.reference,
    required this.grade,
  });

  String get gradeLabel {
    switch (grade) {
      case HadithGrade.sahih:
        return 'صحيح';
      case HadithGrade.hasan:
        return 'حسن';
      case HadithGrade.daif:
        return 'ضعيف';
      case HadithGrade.unknown:
        return 'غير مصنّف';
    }
  }
}

class HadithCollection {
  final String slug;
  final String nameArabic;
  final int totalHadiths;
  final List<Hadith> hadiths;

  const HadithCollection({
    required this.slug,
    required this.nameArabic,
    required this.totalHadiths,
    this.hadiths = const [],
  });
}
