import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/hadith_progress_service.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/services/streak_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/hadith_model.dart';

class HadithCollectionsScreen extends StatelessWidget {
  const HadithCollectionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الحديث الشريف')),
        body: FutureBuilder<List<HadithCollection>>(
          future: LocalDataService.hadithCollections(),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final cols = snap.data!;
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: cols.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                if (i == 0) return const _DailyHadithChallenge();
                i -= 1;
                final c = cols[i];
                return Material(
                  color: AppColors.paperDim,
                  borderRadius: BorderRadius.circular(14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => context.push('/hadith/collection', extra: c),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          const Icon(Icons.menu_book, color: AppColors.emerald),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(c.nameArabic,
                                    style: GoogleFonts.tajawal(fontSize: 15.5, fontWeight: FontWeight.w800)),
                                Text('${c.totalHadiths} أحاديث',
                                    style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.inkSoft)),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_left, color: AppColors.inkSoft),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class HadithListScreen extends StatelessWidget {
  const HadithListScreen({super.key, required this.collection});
  final HadithCollection collection;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(collection.nameArabic)),
        body: ListView.separated(
          padding: const EdgeInsets.all(14),
          itemCount: collection.hadiths.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) => HadithCard(hadith: collection.hadiths[i]),
        ),
      ),
    );
  }
}

class HadithCard extends StatefulWidget {
  const HadithCard({super.key, required this.hadith});
  final Hadith hadith;

  @override
  State<HadithCard> createState() => _HadithCardState();
}

class _HadithCardState extends State<HadithCard> {
  bool _showMeaning = false;

  @override
  Widget build(BuildContext context) {
    final hadith = widget.hadith;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.paperDim,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('«${hadith.arabicText}»',
              style: GoogleFonts.tajawal(fontSize: 15.5, height: 2, fontWeight: FontWeight.w500)),
          const SizedBox(height: 8),
          Text('الراوي: ${hadith.narrator}',
              style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.inkSoft)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Text(hadith.reference,
                  style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.emerald.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(hadith.gradeLabel,
                    style: GoogleFonts.tajawal(
                        fontSize: 10.5, fontWeight: FontWeight.w700, color: AppColors.emeraldDeep)),
              ),
            ],
          ),
          if (hadith.meaning.isNotEmpty) ...[
            const SizedBox(height: 10),
            InkWell(
              onTap: () => setState(() => _showMeaning = !_showMeaning),
              child: Row(
                children: [
                  Icon(_showMeaning ? Icons.expand_less : Icons.expand_more,
                      size: 18, color: AppColors.emerald),
                  const SizedBox(width: 4),
                  Text(_showMeaning ? 'إخفاء المعنى' : 'ما معنى هذا الحديث؟',
                      style: GoogleFonts.tajawal(
                          fontSize: 12.5, color: AppColors.emerald, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            if (_showMeaning)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(hadith.meaning,
                    style: GoogleFonts.tajawal(
                        fontSize: 15.5, color: AppColors.ink, fontWeight: FontWeight.w600, height: 1.9)),
              ),
          ],
        ],
      ),
    );
  }
}

/// بطاقة "تحدي حفظ حديث اليوم" — نفس حديث اليوم المعروض بالرئيسية،
/// مع زر إنجاز يحفّز المستخدم على العودة يوميًا (نفس فكرة "الورد
/// اليومي" في القرآن والأذكار)، ويُحسب ضمن الشعلة العامة للتطبيق.
class _DailyHadithChallenge extends StatefulWidget {
  const _DailyHadithChallenge();
  @override
  State<_DailyHadithChallenge> createState() => _DailyHadithChallengeState();
}

class _DailyHadithChallengeState extends State<_DailyHadithChallenge> {
  late Future<Hadith> _hadithFuture = LocalDataService.dailyHadith();
  int _total = 0;
  bool _doneToday = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final (total, done) = await HadithProgressService.load();
    if (!mounted) return;
    setState(() {
      _total = total;
      _doneToday = done;
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Hadith>(
      future: _hadithFuture,
      builder: (context, snap) {
        if (!snap.hasData) return const SizedBox.shrink();
        final h = snap.data!;
        return Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 4),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.bookmark_added_outlined, color: AppColors.goldBright, size: 20),
                  const SizedBox(width: 6),
                  Text('تحدي اليوم: احفظ هذا الحديث',
                      style: GoogleFonts.tajawal(
                          fontSize: 14.5, fontWeight: FontWeight.w900, color: AppColors.paper)),
                  const Spacer(),
                  Text('حفظت $_total',
                      style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.goldBright)),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('«${h.arabicText}»',
                        style: GoogleFonts.tajawal(fontSize: 15, height: 1.9, color: AppColors.paper)),
                    const SizedBox(height: 8),
                    Text(h.meaning,
                        style: GoogleFonts.tajawal(
                            fontSize: 13.5, color: AppColors.paper.withOpacity(0.85), height: 1.8)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _doneToday ? Colors.white.withOpacity(0.15) : AppColors.goldBright,
                    foregroundColor: _doneToday ? AppColors.paper : const Color(0xFF123524),
                  ),
                  onPressed: _doneToday
                      ? null
                      : () async {
                          final newTotal = await HadithProgressService.markTodayMemorized();
                          await StreakService.checkIn();
                          if (!mounted) return;
                          setState(() {
                            _doneToday = true;
                            _total = newTotal;
                          });
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(content: Text('أحسنت! تم تسجيل حفظك لحديث اليوم 📿')));
                        },
                  child: Text(_doneToday ? 'حفظت حديث اليوم ✅' : 'حفظته — سجّل إنجازي'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
