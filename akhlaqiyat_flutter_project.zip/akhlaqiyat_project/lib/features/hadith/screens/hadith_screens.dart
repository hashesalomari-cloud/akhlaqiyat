import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/theme/app_theme.dart';
import '../models/hadith_model.dart';

class HadithCollectionsScreen extends StatelessWidget {
  const HadithCollectionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الحديث الشريف')),
        body: FutureBuilder<List<HadithCollection>>(
          future: LocalDataService.hadithCollections(),
          builder: (context, snap) {
            if (!snap.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final cols = snap.data!;
            return ListView.separated(
              padding: const EdgeInsets.all(14),
              itemCount: cols.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final c = cols[i];
                return Material(
                  color: AppColors.paperDim,
                  borderRadius: BorderRadius.circular(14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => context.push('/hadith/collection', extra: c),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          const Icon(Icons.menu_book, color: AppColors.emerald),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(c.nameArabic,
                                    style: GoogleFonts.tajawal(fontSize: 15.5, fontWeight: FontWeight.w800)),
                                Text('${c.totalHadiths} أحاديث',
                                    style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.inkSoft)),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_left, color: AppColors.inkSoft),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class HadithListScreen extends StatelessWidget {
  const HadithListScreen({super.key, required this.collection});
  final HadithCollection collection;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(collection.nameArabic)),
        body: ListView.separated(
          padding: const EdgeInsets.all(14),
          itemCount: collection.hadiths.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) => HadithCard(hadith: collection.hadiths[i]),
        ),
      ),
    );
  }
}

class HadithCard extends StatelessWidget {
  const HadithCard({super.key, required this.hadith});
  final Hadith hadith;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.paperDim,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.emerald.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('«${hadith.arabicText}»',
              style: GoogleFonts.tajawal(fontSize: 15.5, height: 2, fontWeight: FontWeight.w500)),
          const SizedBox(height: 8),
          Text('الراوي: ${hadith.narrator}',
              style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.inkSoft)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Text(hadith.reference,
                  style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.emerald.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(hadith.gradeLabel,
                    style: GoogleFonts.tajawal(
                        fontSize: 10.5, fontWeight: FontWeight.w700, color: AppColors.emeraldDeep)),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
