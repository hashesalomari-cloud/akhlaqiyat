// نماذج قسم "أخلاقيات" — تحدي الخُلق اليومي ومواقف من السيرة النبوية.

class DailyEthicChallenge {
  final String title;
  final String description;
  final String howTo; // خطوة عملية بسيطة لتطبيق الخُلق اليوم
  final String relatedVerseOrHadith;

  const DailyEthicChallenge({
    required this.title,
    required this.description,
    required this.howTo,
    required this.relatedVerseOrHadith,
  });
}

class SeerahMoment {
  final String title;
  final String story; // قصة مختصرة جدًا (3-5 أسطر) موثقة من كتب السيرة المعتمدة
  final String lesson; // الدرس الأخلاقي المستفاد
  final String source;

  const SeerahMoment({
    required this.title,
    required this.story,
    required this.lesson,
    required this.source,
  });
}

// بنك تحديات مرجعي — يُسحب منه تحدٍ عشوائي/يومي حسب رقم اليوم
const List<DailyEthicChallenge> ethicChallengesBank = [
  DailyEthicChallenge(
    title: 'كظم الغيظ',
    description: 'إن غضبت اليوم من أحد، توقف ولا تُظهر ردة فعل فورية.',
    howTo: 'إذا شعرت بالغضب وأنت واقف فاجلس، وإن لم يذهب فاضطجع، واذكر الله.',
    relatedVerseOrHadith: 'وَالْكَاظِمِينَ الْغَيْظَ وَالْعَافِينَ عَنِ النَّاسِ — آل عمران 134',
  ),
  DailyEthicChallenge(
    title: 'إماطة الأذى عن الطريق',
    description: 'ابحث اليوم عن أذى في طريقك (حجر، زجاج، قمامة) وأزله.',
    howTo: 'لا يشترط أن يكون عملاً كبيرًا، حتى شوكة صغيرة تُزال تُكتب صدقة.',
    relatedVerseOrHadith: 'الإيمان بضع وسبعون شعبة... وأدناها إماطة الأذى عن الطريق — متفق عليه',
  ),
  DailyEthicChallenge(
    title: 'التبسم',
    description: 'ابتسم اليوم لثلاثة أشخاص على الأقل بنية التقرب إلى الله.',
    howTo: 'ابدأ بأهل بيتك، ثم زميلاً في العمل، ثم شخصًا غريبًا تصادفه.',
    relatedVerseOrHadith: 'تبسمك في وجه أخيك لك صدقة — رواه الترمذي',
  ),
  DailyEthicChallenge(
    title: 'صلة الرحم',
    description: 'تواصل اليوم مع قريب لم تكلمه منذ فترة.',
    howTo: 'اتصال قصير أو رسالة تسأل فيها عن حاله كافٍ لتحقيق التحدي.',
    relatedVerseOrHadith: 'من أحب أن يُبسط له في رزقه... فليصل رحمه — متفق عليه',
  ),
];

const List<SeerahMoment> seerahMomentsBank = [
  SeerahMoment(
    title: 'عفو النبي ﷺ يوم فتح مكة',
    story:
        'بعد سنوات من إيذاء قريش له ولأصحابه، دخل النبي ﷺ مكة فاتحًا منتصرًا، وقد كان بإمكانه الانتقام. فسأل أهل مكة: "ما تظنون أني فاعل بكم؟" قالوا: خيرًا، أخ كريم وابن أخ كريم. فقال: "اذهبوا فأنتم الطلقاء".',
    lesson: 'العفو عند المقدرة من أعظم الأخلاق، والقوة الحقيقية في ضبط النفس عند الانتصار.',
    source: 'سيرة ابن هشام',
  ),
  SeerahMoment(
    title: 'رفق النبي ﷺ بالأعرابي',
    story:
        'دخل أعرابي المسجد فبال فيه، فهمّ الصحابة به، فقال النبي ﷺ: "لا تزرموه" (لا تقطعوا عليه بوله)، ثم أمر بذنوب من ماء فأُهريق عليه، وعلّمه برفق.',
    lesson: 'الرفق في التعليم والدعوة أنجع من الشدة، خاصة مع الجاهل بالحكم.',
    source: 'رواه البخاري 6128',
  ),
  SeerahMoment(
    title: 'وفاء النبي ﷺ لخديجة بعد وفاتها',
    story:
        'كان النبي ﷺ بعد وفاة خديجة رضي الله عنها يذبح الشاة ويهدي منها لصديقاتها وفاءً لذكراها، حتى غارت منها عائشة رضي الله عنها.',
    lesson: 'الوفاء للأحبة لا ينقطع بموتهم، وحسن العهد من كمال الخُلق.',
    source: 'رواه مسلم 2435',
  ),
];
