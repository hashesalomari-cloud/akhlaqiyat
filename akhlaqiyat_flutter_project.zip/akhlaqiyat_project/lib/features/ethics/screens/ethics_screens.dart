import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/ethics_model.dart';

const _kEmerald = Color(0xFF0E6E52);
const _kEmeraldDeep = Color(0xFF0A4A3B);
const _kNight2 = Color(0xFF0E3B3A);
const _kGold = Color(0xFFC9992E);
const _kGoldBright = Color(0xFFE8B94A);
const _kPaper = Color(0xFFFBF6EA);
const _kPaperDim = Color(0xFFF1E8D3);
const _kInkSoft = Color(0xFF5B6154);
const _kEmber2 = Color(0xFFFFCB57);

// شاشة "تحدي الخُلق اليومي" — يحدَّد التحدي حسب رقم اليوم (تدويري على البنك)
// حتى يتكرر بانتظام دون تدخل خادم، ويمكن لاحقًا استبداله بمنطق أذكى
// (تجنب تكرار نفس الخُلق خلال أسبوع، ربطه بتقييم المستخدم لنفسه...).

class DailyChallengeScreen extends StatefulWidget {
  const DailyChallengeScreen({super.key});
  @override
  State<DailyChallengeScreen> createState() => _DailyChallengeScreenState();
}

class _DailyChallengeScreenState extends State<DailyChallengeScreen> {
  bool _completed = false;

  DailyEthicChallenge get _today {
    final dayIndex = DateTime.now().difference(DateTime(2026, 1, 1)).inDays;
    return ethicChallengesBank[dayIndex % ethicChallengesBank.length];
  }

  @override
  Widget build(BuildContext context) {
    final challenge = _today;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _kPaper,
        appBar: AppBar(
          backgroundColor: _kNight2,
          title: Text('تحدي الخُلق اليومي',
              style: GoogleFonts.tajawal(fontWeight: FontWeight.w900, color: _kGoldBright)),
        ),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [_kEmerald, _kEmeraldDeep],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('تحدي اليوم', style: GoogleFonts.tajawal(fontSize: 12, color: _kGoldBright)),
                  const SizedBox(height: 6),
                  Text(challenge.title,
                      style: GoogleFonts.tajawal(fontSize: 24, fontWeight: FontWeight.w900, color: _kPaper)),
                  const SizedBox(height: 10),
                  Text(challenge.description,
                      style: GoogleFonts.tajawal(fontSize: 14, color: _kPaper, height: 1.8)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _infoCard('كيف أطبقه اليوم؟', challenge.howTo, Icons.checklist_rtl),
            const SizedBox(height: 10),
            _infoCard('الأصل الشرعي', challenge.relatedVerseOrHadith, Icons.menu_book_outlined),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _completed ? null : () => setState(() => _completed = true),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kEmber2,
                  disabledBackgroundColor: _kPaperDim,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(
                  _completed ? 'أنجزت التحدي اليوم — أحسنت' : 'طبّقت هذا الخُلق اليوم',
                  style: GoogleFonts.tajawal(
                      fontWeight: FontWeight.w900,
                      color: _completed ? _kInkSoft : const Color(0xFF3A1E00)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(String title, String body, IconData icon) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kPaperDim,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _kEmerald.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 18, color: _kGold),
            const SizedBox(width: 8),
            Text(title, style: GoogleFonts.tajawal(fontSize: 13, fontWeight: FontWeight.w800, color: _kEmeraldDeep)),
          ]),
          const SizedBox(height: 8),
          Text(body, style: GoogleFonts.tajawal(fontSize: 13, color: _kInkSoft, height: 1.8)),
        ],
      ),
    );
  }
}

// شاشة "موقف نبوي" — قصص مختصرة موثقة من كتب السيرة المعتمدة، بدرس مستخلص.

class SeerahMomentScreen extends StatelessWidget {
  const SeerahMomentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _kPaper,
        appBar: AppBar(
          backgroundColor: _kNight2,
          title: Text('مواقف نبوية',
              style: GoogleFonts.tajawal(fontWeight: FontWeight.w900, color: _kGoldBright)),
        ),
        body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: seerahMomentsBank.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (context, i) {
            final m = seerahMomentsBank[i];
            return Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: _kPaperDim,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: _kEmerald.withOpacity(0.18)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.auto_stories, color: _kGold, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(m.title,
                            style: GoogleFonts.tajawal(fontSize: 16, fontWeight: FontWeight.w900, color: _kEmeraldDeep)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(m.story, style: GoogleFonts.tajawal(fontSize: 13.5, height: 1.9)),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _kEmerald.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.lightbulb_outline, size: 16, color: _kEmeraldDeep),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(m.lesson,
                              style: GoogleFonts.tajawal(fontSize: 12.5, color: _kEmeraldDeep, height: 1.7)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(m.source, style: GoogleFonts.tajawal(fontSize: 11, color: _kGold, fontWeight: FontWeight.w700)),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
