import 'package:flutter/material.dart';
import '../../core/services/habit_service.dart';
import '../../core/theme/app_theme.dart';

/// إحصائيات الأسبوع: إنجازات كل يوم، وأكثر العادات التزامًا.
class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});
  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  List<DateTime> _days = const []; // الأقدم أولًا
  List<Set<String>> _done = const [];
  int _points = 0;
  bool _loading = true;

  static const _dayNames = {
    DateTime.saturday: 'السبت',
    DateTime.sunday: 'الأحد',
    DateTime.monday: 'الاثنين',
    DateTime.tuesday: 'الثلاثاء',
    DateTime.wednesday: 'الأربعاء',
    DateTime.thursday: 'الخميس',
    DateTime.friday: 'الجمعة',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final now = DateTime.now();
    final days = [for (var i = 6; i >= 0; i--) DateTime(now.year, now.month, now.day - i)];
    final done = [for (final d in days) await HabitService.doneOn(d)];
    final pts = await HabitService.points();
    if (!mounted) return;
    setState(() {
      _days = days;
      _done = done;
      _points = pts;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('إحصائيات الأسبوع')),
        body: _loading ? const Center(child: CircularProgressIndicator()) : _body(),
      ),
    );
  }

  Widget _body() {
    final total = HabitService.habits.length;
    final counts = [for (final s in _done) s.length];
    final sum = counts.fold(0, (a, b) => a + b);
    final bestIdx = counts.indexOf(counts.reduce((a, b) => a > b ? a : b));
    final activeDays = counts.where((c) => c > 0).length;

    Widget stat(String n, String l) => Expanded(
          child: Column(children: [
            Text(n,
                style: AppFonts.ui(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
            Text(l, style: AppFonts.ui(fontSize: 11.5, color: AppColors.onGrad.withOpacity(0.85))),
          ]),
        );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(children: [
            stat('$sum', 'إنجاز هذا الأسبوع'),
            stat('$activeDays/7', 'أيام نشطة'),
            stat('$_points', 'نقاط الشجرة'),
          ]),
        ),
        const SizedBox(height: 18),
        Text('إنجازك كل يوم', style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        SizedBox(
          height: 150,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              for (var i = 0; i < 7; i++)
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('${counts[i]}', style: AppFonts.ui(fontSize: 11, color: AppColors.inkSoft)),
                      const SizedBox(height: 3),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 5),
                        height: 6 + 100 * counts[i] / total,
                        decoration: BoxDecoration(
                          color: i == 6 ? AppColors.gold : AppColors.emerald,
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(_dayNames[_days[i].weekday]!,
                          style: AppFonts.ui(fontSize: 9.5, color: AppColors.inkSoft)),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text('التزامك بكل عبادة', style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        for (final h in HabitService.habits)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(children: [
              SizedBox(
                width: 118,
                child: Text(h.title, style: AppFonts.ui(fontSize: 12.5, fontWeight: FontWeight.w700)),
              ),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: _done.where((s) => s.contains(h.id)).length / 7,
                    minHeight: 8,
                    backgroundColor: AppColors.emerald.withOpacity(0.12),
                    valueColor: AlwaysStoppedAnimation<Color>(AppColors.emerald),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text('${_done.where((s) => s.contains(h.id)).length}/7',
                  style: AppFonts.ui(fontSize: 11.5, color: AppColors.inkSoft)),
            ]),
          ),
        const SizedBox(height: 16),
        Text(
          sum == 0
              ? 'لم تسجّل شيئًا هذا الأسبوع. ابدأ بعبادة واحدة اليوم، فالبداية الصغيرة تكفي.'
              : 'أفضل أيامك: ${_dayNames[_days[bestIdx].weekday]} (${counts[bestIdx]} من $total). حافظ على الاستمرار ولو قلّ.',
          style: AppFonts.ui(fontSize: 13, color: AppColors.inkSoft, height: 1.8),
        ),
      ],
    );
  }
}
