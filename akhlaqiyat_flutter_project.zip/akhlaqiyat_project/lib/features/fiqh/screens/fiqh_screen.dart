import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// قسم فقه العبادات الأساسي — يبدأ بالطهارة والوضوء (أساس صحة الصلاة).
// المحتوى الفقهي هنا مبني على الصفة الثابتة في حديث عثمان بن عفان
// رضي الله عنه لوضوء النبي ﷺ (رواه البخاري 164، مسلم 226) وفق
// المتفق عليه بين المذاهب في الأركان، مع ملاحظة أن بعض التفاصيل
// (كالمضمضة والاستنشاق: واجبة أم سنة) محل خلاف فقهي معتبر، وننصح
// بمراجعة كتاب فقه معتمد أو عالم لمسائل التفصيل والخلاف المذهبي.

const _kEmerald = Color(0xFF0E6E52);
const _kEmeraldDeep = Color(0xFF0A4A3B);
const _kNight2 = Color(0xFF0E3B3A);
const _kGold = Color(0xFFC9992E);
const _kGoldBright = Color(0xFFE8B94A);
const _kPaper = Color(0xFFFBF6EA);
const _kPaperDim = Color(0xFFF1E8D3);
const _kInkSoft = Color(0xFF5B6154);

class WudustepModel {
  final int order;
  final String title;
  final String description;
  const WudustepModel({required this.order, required this.title, required this.description});
}

const _wuduSteps = [
  WudustepModel(order: 1, title: 'النية', description: 'ينوي المسلم الوضوء بقلبه، دون التلفظ بها.'),
  WudustepModel(order: 2, title: 'التسمية', description: 'يقول "بسم الله" في بداية الوضوء.'),
  WudustepModel(order: 3, title: 'غسل الكفين', description: 'ثلاث مرات، قبل إدخالهما في الإناء.'),
  WudustepModel(order: 4, title: 'المضمضة والاستنشاق', description: 'يأخذ ماءً بيده، يتمضمض به ثم يستنشقه في أنفه وينثره، ثلاث مرات.'),
  WudustepModel(order: 5, title: 'غسل الوجه', description: 'من منابت الشعر إلى الذقن، ومن الأذن إلى الأذن، ثلاث مرات.'),
  WudustepModel(order: 6, title: 'غسل اليدين إلى المرفقين', description: 'اليد اليمنى ثم اليسرى، ثلاث مرات لكل منهما.'),
  WudustepModel(order: 7, title: 'مسح الرأس', description: 'بيدين مبلولتين، من مقدمة الرأس إلى مؤخرته ثم رجوعًا، مرة واحدة، ثم مسح الأذنين.'),
  WudustepModel(order: 8, title: 'غسل الرجلين إلى الكعبين', description: 'اليمنى ثم اليسرى، ثلاث مرات، مع التأكد من إيصال الماء بين الأصابع.'),
];

class FiqhScreen extends StatelessWidget {
  const FiqhScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: _kPaper,
          appBar: AppBar(
            backgroundColor: _kNight2,
            title: Text('فقه العبادات',
                style: GoogleFonts.tajawal(fontWeight: FontWeight.w900, color: _kGoldBright)),
            bottom: TabBar(
              indicatorColor: _kGoldBright,
              labelColor: _kGoldBright,
              unselectedLabelColor: Colors.white60,
              labelStyle: GoogleFonts.tajawal(fontWeight: FontWeight.w800),
              tabs: const [Tab(text: 'صفة الوضوء'), Tab(text: 'نواقض الوضوء')],
            ),
          ),
          body: const TabBarView(
            children: [_WuduStepsTab(), _WuduNullifiersTab()],
          ),
        ),
      ),
    );
  }
}

class _WuduStepsTab extends StatelessWidget {
  const _WuduStepsTab();

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _wuduSteps.length,
      itemBuilder: (context, i) {
        final s = _wuduSteps[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: _kEmerald),
                child: Text('${s.order}',
                    style: GoogleFonts.tajawal(color: _kPaper, fontWeight: FontWeight.w900, fontSize: 13)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _kPaperDim,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _kEmerald.withOpacity(0.15)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s.title, style: GoogleFonts.tajawal(fontSize: 14.5, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text(s.description,
                          style: GoogleFonts.tajawal(fontSize: 12.5, color: _kInkSoft, height: 1.7)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _WuduNullifiersTab extends StatelessWidget {
  const _WuduNullifiersTab();

  static const _nullifiers = [
    'الخارج من السبيلين (بول، غائط، ريح)',
    'النوم المستغرق الزائل للشعور',
    'زوال العقل بإغماء أو سكر أو جنون',
    'أكل لحم الإبل (على الراجح من أقوال أهل العلم)',
    'مس الفرج بشهوة بدون حائل (محل تفصيل فقهي)',
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: _kGold.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kGold.withOpacity(0.3)),
          ),
          child: Text(
            'بعض هذه المسائل فيها خلاف معتبر بين المذاهب الفقهية، اعرضها على عالم موثوق لمذهبك عند الحاجة لتفصيل أدق.',
            style: GoogleFonts.tajawal(fontSize: 12, color: _kEmeraldDeep, height: 1.8),
          ),
        ),
        ..._nullifiers.map((n) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(color: _kPaperDim, borderRadius: BorderRadius.circular(12)),
              child: Row(
                children: [
                  const Icon(Icons.remove_circle_outline, color: _kEmerald, size: 18),
                  const SizedBox(width: 10),
                  Expanded(child: Text(n, style: GoogleFonts.tajawal(fontSize: 13.5))),
                ],
              ),
            )),
      ],
    );
  }
}
