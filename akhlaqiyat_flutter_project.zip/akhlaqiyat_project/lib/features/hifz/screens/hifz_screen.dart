import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/theme/app_theme.dart';

/// تتبع حفظ القرآن — قوائم مبسطة (جزء عمّ + سور مختارة)، يحفظ التقدم
/// فعليًا على الجهاز عبر SharedPreferences.
class HifzScreen extends StatefulWidget {
  const HifzScreen({super.key});
  @override
  State<HifzScreen> createState() => _HifzScreenState();
}

class _HifzScreenState extends State<HifzScreen> {
  static const _groups = [
    (
      'من جزء عمّ',
      [
        'الفاتحة', 'الناس', 'الفلق', 'الإخلاص', 'المسد', 'النصر', 'الكافرون', 'الكوثر',
        'الماعون', 'قريش', 'الفيل', 'الهمزة', 'العصر', 'التكاثر', 'القارعة', 'العاديات',
        'الزلزلة', 'البينة', 'القدر', 'العلق', 'التين', 'الشرح', 'الضحى', 'الليل',
        'الشمس', 'البلد', 'الفجر', 'الغاشية', 'الأعلى', 'الطارق'
      ]
    ),
    ('سور مختارة للحفظ', ['الملك', 'السجدة', 'يس', 'الرحمن', 'الواقعة', 'الكهف', 'الدخان', 'الجمعة', 'المنافقون', 'التغابن']),
  ];

  Map<String, bool> _state = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, bool>{};
    for (final g in _groups) {
      for (final name in g.$2) {
        map['${g.$1}|$name'] = prefs.getBool('hifz|${g.$1}|$name') ?? false;
      }
    }
    if (!mounted) return;
    setState(() {
      _state = map;
      _loading = false;
    });
  }

  Future<void> _toggle(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final newVal = !(_state[key] ?? false);
    await prefs.setBool('hifz|$key', newVal);
    setState(() => _state[key] = newVal);
  }

  @override
  Widget build(BuildContext context) {
    final total = _state.length;
    final done = _state.values.where((v) => v).length;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تتبع الحفظ')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Text('$done من $total سورة',
                            style: GoogleFonts.tajawal(
                                fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.paper)),
                        const SizedBox(height: 6),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: LinearProgressIndicator(
                            value: total == 0 ? 0 : done / total,
                            minHeight: 8,
                            backgroundColor: Colors.white24,
                            valueColor: const AlwaysStoppedAnimation(AppColors.goldBright),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  for (final g in _groups) ...[
                    Text(g.$1,
                        style: GoogleFonts.tajawal(
                            fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.emeraldDeep)),
                    const SizedBox(height: 8),
                    ...g.$2.map((name) {
                      final key = '${g.$1}|$name';
                      final on = _state[key] ?? false;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        decoration: BoxDecoration(
                          color: AppColors.paperDim,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: ListTile(
                          onTap: () => _toggle(key),
                          title: Text('سورة $name', style: GoogleFonts.tajawal(fontSize: 14)),
                          trailing: Icon(
                            on ? Icons.check_circle : Icons.radio_button_unchecked,
                            color: on ? AppColors.emerald : AppColors.inkSoft,
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 16),
                  ],
                ],
              ),
      ),
    );
  }
}
