import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/services/hifz_service.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../quran/models/surah_model.dart';
import '../../quran/screens/surah_reader_screen.dart';
import 'hifz_checklist.dart';

/// متتبع الحفظ: مقاطع يحددها المستخدم (سورة + آيات)، حالة كل مقطع،
/// ومراجعة متباعدة (١، ٣، ٧، ١٤، ٣٠ يومًا…) تُظهر ما حان وقت مراجعته.
class HifzScreen extends StatefulWidget {
  const HifzScreen({super.key});
  @override
  State<HifzScreen> createState() => _HifzScreenState();
}

class _HifzScreenState extends State<HifzScreen> {
  List<HifzItem> _items = const [];
  List<Surah> _surahs = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    HifzService.version.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    HifzService.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final items = await HifzService.all();
    final surahs = _surahs.isEmpty ? await LocalDataService.surahs() : _surahs;
    if (!mounted) return;
    setState(() {
      _items = items;
      _surahs = surahs;
      _loading = false;
    });
  }

  void _open(HifzItem it) {
    final s = _surahs.firstWhere((x) => x.number == it.surah);
    context.push('/quran/surah', extra: SurahReaderArgs(s, it.from));
  }

  Future<void> _add() async {
    int surah = 1;
    final from = TextEditingController(text: '1');
    final to = TextEditingController(text: '7');
    String? err;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('أضف مقطعًا للحفظ'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  value: surah,
                  isExpanded: true,
                  items: [
                    for (final s in _surahs)
                      DropdownMenuItem(value: s.number, child: Text('${s.number}. ${s.nameArabic}')),
                  ],
                  onChanged: (v) {
                    if (v == null) return;
                    final s = _surahs.firstWhere((x) => x.number == v);
                    setD(() {
                      surah = v;
                      from.text = '1';
                      to.text = '${s.versesCount < 10 ? s.versesCount : 10}';
                    });
                  },
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: from,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'من آية'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: to,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'إلى آية'),
                      ),
                    ),
                  ],
                ),
                if (err != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(err!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
                  ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
              TextButton(
                onPressed: () {
                  final s = _surahs.firstWhere((x) => x.number == surah);
                  final f = int.tryParse(from.text.trim()) ?? 0;
                  final t = int.tryParse(to.text.trim()) ?? 0;
                  if (f < 1 || t < f || t > s.versesCount) {
                    setD(() => err = 'الآيات في سورة ${s.nameArabic}: من 1 إلى ${s.versesCount}');
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                child: const Text('إضافة'),
              ),
            ],
          ),
        ),
      ),
    );
    if (ok == true) {
      final s = _surahs.firstWhere((x) => x.number == surah);
      await HifzService.add(s.number, s.nameArabic, int.parse(from.text.trim()), int.parse(to.text.trim()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('تتبع الحفظ'),
            bottom: const TabBar(tabs: [Tab(text: 'حفظي'), Tab(text: 'قوائم سريعة')]),
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _loading ? null : _add,
            icon: const Icon(Icons.add),
            label: const Text('مقطع جديد'),
          ),
          body: TabBarView(
            children: [
              _loading ? const Center(child: CircularProgressIndicator()) : _mine(),
              const HifzChecklist(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mine() {
    final due = _items.where((i) => i.due).toList();
    final learning = _items.where((i) => i.status == 0).toList();
    final memo = _items.where((i) => i.status == 1 && !i.due).toList();
    if (_items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Text(
            'ابدأ بمقطع قصير (آيات قليلة) واحفظه بثبات.\nاضغط «مقطع جديد» لتحديد السورة والآيات، وسأذكّرك بموعد مراجعته.',
            textAlign: TextAlign.center,
            style: AppFonts.ui(color: AppColors.inkSoft, height: 1.8),
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 90),
      children: [
        _summary(due.length, learning.length, _items.where((i) => i.status == 1).length),
        if (due.isNotEmpty) ..._section('حان وقت مراجعتها', due, Icons.alarm, AppColors.gold),
        if (learning.isNotEmpty) ..._section('قيد الحفظ', learning, Icons.edit_note, AppColors.emerald),
        if (memo.isNotEmpty) ..._section('محفوظة', memo, Icons.check_circle_outline, AppColors.emeraldDeep),
      ],
    );
  }

  Widget _summary(int due, int learning, int memo) {
    Widget cell(String n, String l) => Expanded(
          child: Column(
            children: [
              Text(n,
                  style: AppFonts.ui(
                      fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
              Text(l, style: AppFonts.ui(fontSize: 11.5, color: AppColors.onGrad.withOpacity(0.85))),
            ],
          ),
        );
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        cell('$memo', 'محفوظة'),
        cell('$learning', 'قيد الحفظ'),
        cell('$due', 'للمراجعة'),
      ]),
    );
  }

  List<Widget> _section(String title, List<HifzItem> list, IconData icon, Color c) => [
        const SizedBox(height: 18),
        Row(children: [
          Icon(icon, size: 18, color: c),
          const SizedBox(width: 6),
          Text(title, style: AppFonts.ui(fontSize: 14.5, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 8),
        for (final it in list) _tile(it),
      ];

  Widget _tile(HifzItem it) {
    String sub;
    if (it.status == 0) {
      sub = it.rangeLabel;
    } else if (it.due) {
      sub = '${it.rangeLabel} — راجعها اليوم';
    } else {
      final n = it.nextReview!;
      final left = n.difference(DateTime.now()).inDays + 1;
      sub = '${it.rangeLabel} — المراجعة القادمة بعد $left يوم';
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppColors.paperDim,
        borderRadius: BorderRadius.circular(14),
        border: it.due ? Border.all(color: AppColors.gold, width: 1.4) : null,
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(
                child: Text('سورة ${it.surahName}',
                    style: AppFonts.ui(fontSize: 15.5, fontWeight: FontWeight.w800)),
              ),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'del') await HifzService.remove(it.id);
                  if (v == 'forgot') await HifzService.forgot(it.id);
                },
                itemBuilder: (_) => [
                  if (it.status == 1)
                    const PopupMenuItem(value: 'forgot', child: Text('نسيت جزءًا منه (أعد الجدول)')),
                  const PopupMenuItem(value: 'del', child: Text('حذف')),
                ],
              ),
            ]),
            Text(sub, style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              OutlinedButton.icon(
                onPressed: () => _open(it),
                icon: const Icon(Icons.menu_book, size: 16),
                label: const Text('افتح للقراءة'),
              ),
              if (it.status == 0)
                FilledButton.icon(
                  onPressed: () => HifzService.markMemorized(it.id),
                  icon: const Icon(Icons.check, size: 16),
                  label: const Text('حفظته'),
                ),
              if (it.status == 1 && it.due)
                FilledButton.icon(
                  onPressed: () => HifzService.reviewed(it.id),
                  icon: const Icon(Icons.check, size: 16),
                  label: const Text('راجعته'),
                ),
            ]),
          ],
        ),
      ),
    );
  }
}
