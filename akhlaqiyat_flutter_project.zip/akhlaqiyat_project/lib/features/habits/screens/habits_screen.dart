import 'package:flutter/material.dart';

import '../../../core/services/habit_service.dart';
import '../../../core/theme/app_theme.dart';
import '../widgets/tree_painter.dart';

/// وردي اليومي: شجرة الأخلاق + قائمة العادات + آخر 7 أيام.
class HabitsScreen extends StatefulWidget {
  const HabitsScreen({super.key});
  @override
  State<HabitsScreen> createState() => _HabitsScreenState();
}

class _HabitsScreenState extends State<HabitsScreen> {
  Set<String> _done = {};
  int _points = 0;
  List<int> _week = const [];

  @override
  void initState() {
    super.initState();
    HabitService.version.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    HabitService.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final d = await HabitService.doneToday();
    final p = await HabitService.points();
    final w = await HabitService.lastDays(7);
    if (!mounted) return;
    setState(() {
      _done = d;
      _points = p;
      _week = w;
    });
  }

  IconData _icon(String k) => switch (k) {
        'prayer' => Icons.mosque_outlined,
        'sun' => Icons.wb_sunny_outlined,
        'moon' => Icons.nights_stay_outlined,
        'book' => Icons.menu_book_outlined,
        _ => Icons.favorite_border,
      };

  @override
  Widget build(BuildContext context) {
    final stage = HabitService.stageFor(_points);
    final stageName = HabitService.stages[stage].$2;
    final nextAt = stage + 1 < HabitService.stages.length ? HabitService.stages[stage + 1].$1 : null;
    final from = HabitService.stages[stage].$1;
    final progress = nextAt == null ? 1.0 : ((_points - from) / (nextAt - from)).clamp(0.0, 1.0);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.paper,
        appBar: AppBar(title: const Text('وردي اليومي')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [AppColors.night1, AppColors.night2],
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 190,
                    width: double.infinity,
                    child: CustomPaint(painter: TreePainter(stage, dark: AppColors.isDark)),
                  ),
                  Text('شجرتك: $stageName',
                      style: AppFonts.ui(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: Colors.white24,
                      color: AppColors.goldBright,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    nextAt == null
                        ? 'بلغت أعلى مراحل الشجرة، واصل الإحسان 🌳'
                        : 'تحتاج ${nextAt - _points} إنجازًا لتنمو للمرحلة التالية',
                    style: AppFonts.ui(fontSize: 12, color: AppColors.onGrad.withOpacity(0.85)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Text('عبادات اليوم (${_done.length}/${HabitService.habits.length})',
                      style: AppFonts.ui(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emerald)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            for (final h in HabitService.habits)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: _done.contains(h.id) ? AppColors.emerald.withOpacity(0.12) : AppColors.paperDim,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: _done.contains(h.id) ? AppColors.emerald : AppColors.emerald.withOpacity(0.12)),
                ),
                child: CheckboxListTile(
                  value: _done.contains(h.id),
                  activeColor: AppColors.emerald,
                  checkColor: AppColors.onGrad,
                  controlAffinity: ListTileControlAffinity.trailing,
                  secondary: Icon(_icon(h.icon), color: AppColors.emerald),
                  title: Text(h.title, style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.ink)),
                  onChanged: (v) => HabitService.set(h.id, v ?? false),
                ),
              ),
            const SizedBox(height: 14),
            Text('آخر 7 أيام',
                style: AppFonts.ui(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.emerald)),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var i = _week.length - 1; i >= 0; i--)
                  Column(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _week[i] == 0
                              ? AppColors.paperDim
                              : AppColors.emerald.withOpacity((0.25 + _week[i] / HabitService.habits.length * 0.75).clamp(0.0, 1.0)),
                        ),
                        child: Text('${_week[i]}',
                            style: AppFonts.ui(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: _week[i] == 0 ? AppColors.inkSoft : AppColors.onGrad)),
                      ),
                      const SizedBox(height: 4),
                      Text(i == 0 ? 'اليوم' : '-$i',
                          style: AppFonts.ui(fontSize: 10, color: AppColors.inkSoft)),
                    ],
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
