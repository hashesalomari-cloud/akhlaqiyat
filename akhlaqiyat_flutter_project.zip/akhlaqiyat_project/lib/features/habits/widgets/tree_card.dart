import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/services/habit_service.dart';
import '../../../core/theme/app_theme.dart';
import 'tree_painter.dart';

/// بطاقة الرئيسية: شجرة الأخلاق المصغّرة + تقدّم عبادات اليوم.
class TreeCard extends StatefulWidget {
  const TreeCard({super.key});
  @override
  State<TreeCard> createState() => _TreeCardState();
}

class _TreeCardState extends State<TreeCard> {
  int _points = 0;
  int _done = 0;

  @override
  void initState() {
    super.initState();
    HabitService.version.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    HabitService.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final p = await HabitService.points();
    final d = await HabitService.doneToday();
    if (!mounted) return;
    setState(() {
      _points = p;
      _done = d.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final stage = HabitService.stageFor(_points);
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => context.push('/habits'),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [AppColors.night1, AppColors.night2]),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            SizedBox(width: 90, height: 100, child: CustomPaint(painter: TreePainter(stage))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('شجرة الأخلاق: ${HabitService.stages[stage].$2}',
                      style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
                  const SizedBox(height: 6),
                  Text('أنجزت اليوم $_done من ${HabitService.habits.length} عبادات',
                      style: AppFonts.ui(fontSize: 12.5, color: AppColors.onGrad)),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: _done / HabitService.habits.length,
                      minHeight: 6,
                      backgroundColor: Colors.white24,
                      color: AppColors.goldBright,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text('اضغط لتسجيل وردك وتنمية شجرتك',
                      style: AppFonts.ui(fontSize: 11, color: AppColors.onGrad.withOpacity(0.75))),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
