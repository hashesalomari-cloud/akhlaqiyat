import 'dart:math' as math;
import 'package:flutter/material.dart';

/// يرسم شجرة الأخلاق بمراحلها السبع (0 بذرة … 6 شجرة مثمرة) بدون صور.
class TreePainter extends CustomPainter {
  final int stage; // 0..6
  final bool dark;
  const TreePainter(this.stage, {this.dark = false});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final ground = h * 0.88;

    // التربة
    final soil = Paint()..color = const Color(0xFF6B4A2B);
    canvas.drawOval(Rect.fromCenter(center: Offset(w / 2, ground + 4), width: w * 0.55, height: h * 0.1), soil);

    final trunk = Paint()
      ..color = const Color(0xFF7A5230)
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final leaf = Paint()..color = const Color(0xFF2E9B6B);
    final leafLight = Paint()..color = const Color(0xFF58C28D);
    final flower = Paint()..color = const Color(0xFFFF9EB5);
    final fruit = Paint()..color = const Color(0xFFFFB02E);

    if (stage == 0) {
      // بذرة صغيرة على التربة
      canvas.drawOval(
          Rect.fromCenter(center: Offset(w / 2, ground - 2), width: w * 0.08, height: h * 0.05),
          Paint()..color = const Color(0xFF9A6B3A));
      return;
    }

    // ارتفاع الجذع حسب المرحلة
    final trunkH = [0.0, h * 0.14, h * 0.28, h * 0.42, h * 0.5, h * 0.52, h * 0.52][stage];
    final trunkW = [0.0, 3.0, 5.0, 8.0, 11.0, 12.0, 12.0][stage];
    trunk.strokeWidth = trunkW;
    final top = Offset(w / 2, ground - trunkH);
    canvas.drawLine(Offset(w / 2, ground), top, trunk);

    if (stage == 1) {
      // ورقتان
      _leaf(canvas, top, -0.9, w * 0.13, leafLight);
      _leaf(canvas, top, 0.9, w * 0.13, leafLight);
      return;
    }

    if (stage == 2) {
      _leaf(canvas, top, -1.0, w * 0.16, leaf);
      _leaf(canvas, top, 1.0, w * 0.16, leaf);
      _leaf(canvas, top, 0, w * 0.15, leafLight);
      return;
    }

    // أفرع جانبية للمراحل 3+
    final branchY = ground - trunkH * 0.55;
    trunk.strokeWidth = trunkW * 0.5;
    canvas.drawLine(Offset(w / 2, branchY), Offset(w / 2 - w * 0.16, branchY - h * 0.1), trunk);
    canvas.drawLine(Offset(w / 2, branchY - h * 0.05), Offset(w / 2 + w * 0.16, branchY - h * 0.15), trunk);

    // التاج (مجموعة دوائر خضراء)
    final crownR = [0.0, 0, 0, w * 0.2, w * 0.27, w * 0.3, w * 0.31][stage].toDouble();
    final c = Offset(w / 2, top.dy - crownR * 0.2);
    final blobs = <Offset>[
      c,
      c + Offset(-crownR * 0.75, crownR * 0.25),
      c + Offset(crownR * 0.75, crownR * 0.25),
      c + Offset(-crownR * 0.4, -crownR * 0.55),
      c + Offset(crownR * 0.45, -crownR * 0.5),
    ];
    for (var i = 0; i < blobs.length; i++) {
      canvas.drawCircle(blobs[i], crownR * (i == 0 ? 0.8 : 0.62), i.isEven ? leaf : leafLight);
    }

    // أزهار (المرحلة 5+) وثمار (المرحلة 6)
    if (stage >= 5) {
      final rnd = math.Random(7);
      for (var i = 0; i < 12; i++) {
        final a = rnd.nextDouble() * math.pi * 2;
        final r = rnd.nextDouble() * crownR * 1.1;
        final p = c + Offset(math.cos(a) * r, math.sin(a) * r * 0.85);
        canvas.drawCircle(p, 4.2, stage == 6 && i % 2 == 0 ? fruit : flower);
        if (stage == 5 || i % 2 == 1) canvas.drawCircle(p, 1.6, Paint()..color = Colors.white);
      }
    }
  }

  void _leaf(Canvas canvas, Offset base, double angle, double len, Paint paint) {
    canvas.save();
    canvas.translate(base.dx, base.dy);
    canvas.rotate(angle);
    final path = Path()
      ..moveTo(0, 0)
      ..quadraticBezierTo(len * 0.5, -len * 0.5, 0, -len)
      ..quadraticBezierTo(-len * 0.5, -len * 0.5, 0, 0);
    canvas.drawPath(path, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant TreePainter old) => old.stage != stage || old.dark != dark;
}
