import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/services/streak_service.dart';
import '../../../core/settings/app_settings.dart';
import '../models/azkar_model.dart';
import '../../../core/theme/app_theme.dart';

// شاشة العداد الإلكتروني للتسبيح — تعرض ذكرًا واحدًا في كل مرة،
// المستخدم يضغط على الدائرة للعد، وعند الوصول للعدد المطلوب
// (اهتزاز خفيف + تحول لون) تنتقل تلقائيًا للذكر التالي.
//
// في المشروع الفعلي: مرّر قائمة أذكار حقيقية حسب category.id
// من مصدر بيانات مراجَع (assets/data/azkar.json)، بدل _list.

Color get _kEmerald => AppColors.emerald;
Color get _kEmeraldDeep => AppColors.emeraldDeep;
Color get _kNight2 => AppColors.night2;
const _kGold = AppColors.gold;
const _kGoldBright = AppColors.goldBright;
Color get _kPaper => AppColors.paper;
Color get _kPaperDim => AppColors.paperDim;
Color get _kInkSoft => AppColors.inkSoft;
const _kEmber1 = AppColors.ember1;
const _kEmber2 = AppColors.ember2;

class AzkarCounterScreen extends StatefulWidget {
  const AzkarCounterScreen({super.key, required this.category});
  final AzkarCategory category;

  @override
  State<AzkarCounterScreen> createState() => _AzkarCounterScreenState();
}

class _AzkarCounterScreenState extends State<AzkarCounterScreen>
    with SingleTickerProviderStateMixin {
  List<Dhikr> _list = const [];
  bool _loading = true;
  int _dhikrIndex = 0;
  int _currentCount = 0;
  late AnimationController _pulseController;


  Dhikr get _current => _list[_dhikrIndex];
  bool get _isLastDhikr => _dhikrIndex == _list.length - 1;
  double get _progress => _currentCount / _current.targetCount;

  @override
  void initState() {
    super.initState();
    LocalDataService.azkarFor(widget.category.id).then((l) {
      if (!mounted) return;
      setState(() {
        _list = l;
        _loading = false;
      });
    });
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.95,
      upperBound: 1.0,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _onTap() {
    if (_currentCount >= _current.targetCount) return;
    if (AppSettings.I.haptics) HapticFeedback.lightImpact();
    _pulseController.reverse().then((_) => _pulseController.forward());
    setState(() => _currentCount++);

    if (_currentCount == _current.targetCount) {
      if (AppSettings.I.haptics) HapticFeedback.mediumImpact();
      Future.delayed(const Duration(milliseconds: 500), () {
        if (!mounted) return;
        if (_isLastDhikr) {
          _showCompletionSheet();
        } else {
          setState(() {
            _dhikrIndex++;
            _currentCount = 0;
          });
        }
      });
    }
  }

  void _showCompletionSheet() {
    StreakService.checkIn();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: _kPaper,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🔥', style: TextStyle(fontSize: 46)),
              const SizedBox(height: 12),
              Text('أتممت ${widget.category.nameArabic}',
                  style: AppFonts.ui(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('بارك الله فيك، هذا الإنجاز يُحسب ضمن وردك اليومي',
                  textAlign: TextAlign.center,
                  style: AppFonts.ui(fontSize: 13, color: _kInkSoft)),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kEmber2,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text('تم',
                      style: AppFonts.ui(fontWeight: FontWeight.w900, color: const Color(0xFF3A1E00))),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _list.isEmpty) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text(widget.category.nameArabic)),
          body: Center(
            child: _loading
                ? const CircularProgressIndicator()
                : const Text('لا توجد أذكار في هذا القسم بعد'),
          ),
        ),
      );
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _kPaper,
        appBar: AppBar(
          backgroundColor: _kNight2,
          title: Text(widget.category.nameArabic,
              style: AppFonts.ui(fontWeight: FontWeight.w900, color: _kGoldBright)),
        ),
        body: SafeArea(
          child: Column(
            children: [
              // مؤشر التقدم بين الأذكار
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  children: List.generate(_list.length, (i) {
                    final done = i < _dhikrIndex;
                    final active = i == _dhikrIndex;
                    return Expanded(
                      child: Container(
                        height: 5,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        decoration: BoxDecoration(
                          color: done || active ? _kEmerald : _kPaperDim,
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                    );
                  }),
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(22),
                        decoration: BoxDecoration(
                          color: _kPaperDim,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _kEmerald.withOpacity(0.18)),
                        ),
                        child: Column(
                          children: [
                            Text(_current.text,
                                textAlign: TextAlign.center,
                                style: AppFonts.quran(fontSize: 24, height: 1.8)),
                            if (_current.virtue != null) ...[
                              const SizedBox(height: 12),
                              Text(_current.virtue!,
                                  textAlign: TextAlign.center,
                                  style: AppFonts.ui(fontSize: 12, color: _kInkSoft, height: 1.7)),
                            ],
                            const SizedBox(height: 8),
                            Text(_current.source,
                                style: AppFonts.ui(fontSize: 11, color: _kGold, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 40),
                      GestureDetector(
                        onTap: _onTap,
                        child: ScaleTransition(
                          scale: _pulseController,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              SizedBox(
                                width: 180,
                                height: 180,
                                child: CircularProgressIndicator(
                                  value: _progress.clamp(0, 1),
                                  strokeWidth: 10,
                                  backgroundColor: _kPaperDim,
                                  valueColor: const AlwaysStoppedAnimation(_kEmber1),
                                ),
                              ),
                              Container(
                                width: 150,
                                height: 150,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [_kEmerald, _kEmeraldDeep],
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('$_currentCount',
                                        style: AppFonts.ui(
                                            fontSize: 40, fontWeight: FontWeight.w900, color: AppColors.onGrad)),
                                    Text('من ${_current.targetCount}',
                                        style: AppFonts.ui(fontSize: 12, color: _kGoldBright)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text('اضغط على الدائرة للعد',
                          style: AppFonts.ui(fontSize: 12, color: _kInkSoft)),
                    ],
                  ),
                ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
