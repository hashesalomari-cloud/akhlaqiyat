import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/azkar_model.dart';
import '../../../core/theme/app_theme.dart';

Color get _kEmerald => AppColors.emerald;
Color get _kNight2 => AppColors.night2;
const _kGoldBright = AppColors.goldBright;
Color get _kPaper => AppColors.paper;
Color get _kPaperDim => AppColors.paperDim;
Color get _kInkSoft => AppColors.inkSoft;

class AzkarCategoriesScreen extends StatelessWidget {
  const AzkarCategoriesScreen({super.key});

  static const _categories = [
    AzkarCategory(id: 'morning', nameArabic: 'أذكار الصباح', icon: 'wb_sunny_outlined'),
    AzkarCategory(id: 'evening', nameArabic: 'أذكار المساء', icon: 'nights_stay_outlined'),
    AzkarCategory(id: 'sleep', nameArabic: 'أذكار النوم', icon: 'bedtime_outlined'),
    AzkarCategory(id: 'wakeup', nameArabic: 'أذكار الاستيقاظ', icon: 'wb_twilight'),
    AzkarCategory(id: 'after_prayer', nameArabic: 'أذكار بعد الصلاة', icon: 'mosque_outlined'),
    AzkarCategory(id: 'quran_duas', nameArabic: 'أدعية قرآنية', icon: 'menu_book_outlined'),
    AzkarCategory(id: 'distress', nameArabic: 'الهمّ والكرب', icon: 'favorite_border'),
    AzkarCategory(id: 'istikhara', nameArabic: 'دعاء الاستخارة', icon: 'help_outline'),
    AzkarCategory(id: 'home', nameArabic: 'دخول البيت والخروج', icon: 'home_outlined'),
    AzkarCategory(id: 'toilet', nameArabic: 'دخول الخلاء', icon: 'wc_outlined'),
    AzkarCategory(id: 'wudu', nameArabic: 'أذكار الوضوء', icon: 'water_drop_outlined'),
    AzkarCategory(id: 'mosque', nameArabic: 'أذكار المسجد', icon: 'location_city_outlined'),
    AzkarCategory(id: 'food', nameArabic: 'الطعام والصيام', icon: 'restaurant_outlined'),
    AzkarCategory(id: 'clothes', nameArabic: 'اللباس', icon: 'checkroom_outlined'),
    AzkarCategory(id: 'travel', nameArabic: 'أذكار السفر', icon: 'flight_outlined'),
    AzkarCategory(id: 'weather', nameArabic: 'المطر والريح', icon: 'cloud_outlined'),
    AzkarCategory(id: 'social', nameArabic: 'مواقف اجتماعية', icon: 'people_outline'),
    AzkarCategory(id: 'free_tasbih', nameArabic: 'سبحة حرة', icon: 'fingerprint'),
  ];

  static const _icons = {
    'wb_sunny_outlined': Icons.wb_sunny_outlined,
    'nights_stay_outlined': Icons.nights_stay_outlined,
    'bedtime_outlined': Icons.bedtime_outlined,
    'wb_twilight': Icons.wb_twilight,
    'mosque_outlined': Icons.mosque_outlined,
    'menu_book_outlined': Icons.menu_book_outlined,
    'favorite_border': Icons.favorite_border,
    'help_outline': Icons.help_outline,
    'home_outlined': Icons.home_outlined,
    'wc_outlined': Icons.wc_outlined,
    'water_drop_outlined': Icons.water_drop_outlined,
    'location_city_outlined': Icons.location_city_outlined,
    'restaurant_outlined': Icons.restaurant_outlined,
    'checkroom_outlined': Icons.checkroom_outlined,
    'flight_outlined': Icons.flight_outlined,
    'cloud_outlined': Icons.cloud_outlined,
    'people_outline': Icons.people_outline,
    'fingerprint': Icons.fingerprint,
  };

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _kPaper,
        appBar: AppBar(
          backgroundColor: _kNight2,
          title: Text('الأذكار',
              style: AppFonts.ui(fontWeight: FontWeight.w900, color: _kGoldBright)),
        ),
        body: GridView.builder(
          padding: const EdgeInsets.all(14),
          itemCount: _categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
          ),
          itemBuilder: (context, i) {
            final c = _categories[i];
            return Material(
              color: _kPaperDim,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => context.push('/azkar/counter', extra: c),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(_icons[c.icon], size: 34, color: _kEmerald),
                      const SizedBox(height: 10),
                      Text(c.nameArabic,
                          textAlign: TextAlign.center,
                          style: AppFonts.ui(fontSize: 14, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
