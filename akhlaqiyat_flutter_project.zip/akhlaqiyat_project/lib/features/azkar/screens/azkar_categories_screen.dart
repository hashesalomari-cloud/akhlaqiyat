import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../models/azkar_model.dart';

const _kEmerald = Color(0xFF0E6E52);
const _kNight2 = Color(0xFF0E3B3A);
const _kGoldBright = Color(0xFFE8B94A);
const _kPaper = Color(0xFFFBF6EA);
const _kPaperDim = Color(0xFFF1E8D3);
const _kInkSoft = Color(0xFF5B6154);

class AzkarCategoriesScreen extends StatelessWidget {
  const AzkarCategoriesScreen({super.key});

  static const _categories = [
    AzkarCategory(id: 'morning', nameArabic: 'أذكار الصباح', icon: 'wb_sunny_outlined'),
    AzkarCategory(id: 'evening', nameArabic: 'أذكار المساء', icon: 'nights_stay_outlined'),
    AzkarCategory(id: 'sleep', nameArabic: 'أذكار النوم', icon: 'bedtime_outlined'),
    AzkarCategory(id: 'after_prayer', nameArabic: 'أذكار بعد الصلاة', icon: 'mosque_outlined'),
    AzkarCategory(id: 'travel', nameArabic: 'أذكار السفر', icon: 'flight_outlined'),
    AzkarCategory(id: 'free_tasbih', nameArabic: 'سبحة حرة', icon: 'fingerprint'),
  ];

  static const _icons = {
    'wb_sunny_outlined': Icons.wb_sunny_outlined,
    'nights_stay_outlined': Icons.nights_stay_outlined,
    'bedtime_outlined': Icons.bedtime_outlined,
    'mosque_outlined': Icons.mosque_outlined,
    'flight_outlined': Icons.flight_outlined,
    'fingerprint': Icons.fingerprint,
  };

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: _kPaper,
        appBar: AppBar(
          backgroundColor: _kNight2,
          title: Text('الأذكار',
              style: GoogleFonts.tajawal(fontWeight: FontWeight.w900, color: _kGoldBright)),
        ),
        body: GridView.builder(
          padding: const EdgeInsets.all(14),
          itemCount: _categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
          ),
          itemBuilder: (context, i) {
            final c = _categories[i];
            return Material(
              color: _kPaperDim,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => context.push('/azkar/counter', extra: c),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(_icons[c.icon], size: 34, color: _kEmerald),
                      const SizedBox(height: 10),
                      Text(c.nameArabic,
                          textAlign: TextAlign.center,
                          style: GoogleFonts.tajawal(fontSize: 14, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
