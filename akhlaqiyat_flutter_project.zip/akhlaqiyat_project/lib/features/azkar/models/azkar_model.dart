// نماذج بيانات الأذكار.

class AzkarCategory {
  final String id; // "morning" | "evening" | "sleep" | "after_prayer" | "travel"...
  final String nameArabic;
  final String icon; // اسم أيقونة Material
  const AzkarCategory({required this.id, required this.nameArabic, required this.icon});
}

class Dhikr {
  final String text;
  final int targetCount; // عدد التكرار المطلوب (مثال: 33 للتسبيح، 1 لدعاء طويل)
  final String? virtue; // فضل الذكر (اختياري، مختصر)
  final String source;

  const Dhikr({
    required this.text,
    required this.targetCount,
    this.virtue,
    required this.source,
  });
}
