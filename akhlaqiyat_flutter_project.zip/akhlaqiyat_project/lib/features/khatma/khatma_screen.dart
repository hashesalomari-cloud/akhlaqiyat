import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/services/khatma_service.dart';
import '../../core/services/local_data_service.dart';
import '../../core/theme/app_theme.dart';
import '../quran/models/surah_model.dart';
import '../quran/screens/surah_reader_screen.dart';

/// خطة ختمة: اختر المدة، ويُحسب لك ورد كل يوم من عدد آيات المصحف.
class KhatmaScreen extends StatefulWidget {
  const KhatmaScreen({super.key});
  @override
  State<KhatmaScreen> createState() => _KhatmaScreenState();
}

class _KhatmaScreenState extends State<KhatmaScreen> {
  List<Surah> _surahs = const [];
  KhatmaPlan? _plan;
  bool _loading = true;

  static const _presets = <(int, String)>[
    (7, 'أسبوع'),
    (15, '١٥ يومًا'),
    (30, 'شهر (رمضان)'),
    (60, 'شهران'),
    (90, '٣ أشهر'),
    (180, '٦ أشهر'),
    (365, 'سنة'),
  ];

  @override
  void initState() {
    super.initState();
    KhatmaService.version.addListener(_load);
    _load();
  }

  @override
  void dispose() {
    KhatmaService.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    if (_surahs.isEmpty) {
      _surahs = await LocalDataService.surahs();
      KhatmaService.init(_surahs);
    }
    final p = await KhatmaService.load();
    if (!mounted) return;
    setState(() {
      _plan = p;
      _loading = false;
    });
  }

  void _openAt(QuranPos pos) {
    final s = _surahs.firstWhere((x) => x.number == pos.surah);
    context.push('/quran/surah', extra: SurahReaderArgs(s, pos.ayah));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ختمتي')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _plan == null
                ? _chooser()
                : _planView(_plan!),
      ),
    );
  }

  Widget _chooser() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('في كم يومًا تريد أن تختم القرآن؟',
            style: AppFonts.ui(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('سنقسّم آيات المصحف على الأيام، ويظهر لك كل يوم مقدار وردك ومن أين تبدأ.',
            style: AppFonts.ui(fontSize: 13, color: AppColors.inkSoft, height: 1.7)),
        const SizedBox(height: 14),
        for (final (days, label) in _presets)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color: AppColors.paperDim,
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => KhatmaService.start(days),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    Expanded(
                      child: Text(label, style: AppFonts.ui(fontSize: 15.5, fontWeight: FontWeight.w800)),
                    ),
                    Text('≈ ${(KhatmaService.total / days).ceil()} آية يوميًا',
                        style: AppFonts.ui(fontSize: 12.5, color: AppColors.gold, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _planView(KhatmaPlan p) {
    final pct = (p.progress * 100).floor();
    final startPos = KhatmaService.posOf(p.done + 1);
    final endPos = KhatmaService.posOf(p.todayEnd);
    final startName = KhatmaService.nameOf(startPos.surah);
    final endName = KhatmaService.nameOf(endPos.surah);

    if (p.finished) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.emoji_events, size: 64, color: AppColors.gold),
            const SizedBox(height: 14),
            Text('أتممت الختمة، بارك الله فيك',
                style: AppFonts.ui(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('اللهم اجعل القرآن ربيع قلوبنا',
                style: AppFonts.ui(fontSize: 13, color: AppColors.inkSoft)),
            const SizedBox(height: 18),
            FilledButton(onPressed: KhatmaService.reset, child: const Text('ابدأ ختمة جديدة')),
          ]),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(children: [
            Text('اليوم ${p.dayNumber} من ${p.days}',
                style: AppFonts.ui(fontSize: 13, color: AppColors.onGrad.withOpacity(0.85))),
            const SizedBox(height: 4),
            Text('$pct%',
                style: AppFonts.ui(fontSize: 38, fontWeight: FontWeight.w900, color: AppColors.goldBright)),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: p.progress,
                minHeight: 8,
                backgroundColor: Colors.white24,
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.goldBright),
              ),
            ),
            const SizedBox(height: 8),
            Text('قرأت ${p.done} من ${p.total} آية',
                style: AppFonts.ui(fontSize: 12, color: AppColors.onGrad.withOpacity(0.85))),
          ]),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.paperDim,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: p.todayDone ? AppColors.emerald : AppColors.gold.withOpacity(0.6), width: 1.4),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.todayDone ? 'أتممت ورد اليوم ✓' : 'ورد اليوم',
                style: AppFonts.ui(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
            const SizedBox(height: 8),
            if (!p.todayDone) ...[
              Text('من سورة $startName آية ${startPos.ayah}\nإلى سورة $endName آية ${endPos.ayah}',
                  style: AppFonts.ui(fontSize: 15, height: 1.9, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(
                  p.behindDays >= 1
                      ? 'متبقٍ ${p.todayAyat} آية (متأخر ${p.behindDays} يوم، ولا بأس، أكمل بهدوء)'
                      : 'متبقٍ ${p.todayAyat} آية',
                  style: AppFonts.ui(fontSize: 12, color: AppColors.inkSoft)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(
                  onPressed: () => _openAt(startPos),
                  icon: const Icon(Icons.menu_book, size: 16),
                  label: const Text('افتح القراءة'),
                ),
                FilledButton.icon(
                  onPressed: KhatmaService.completeToday,
                  icon: const Icon(Icons.check, size: 16),
                  label: const Text('تم ورد اليوم'),
                ),
              ]),
            ] else
              Text('بارك الله في وقتك. موعدنا غدًا بإذن الله.',
                  style: AppFonts.ui(fontSize: 13, color: AppColors.inkSoft)),
          ]),
        ),
        const SizedBox(height: 14),
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => Directionality(
                  textDirection: TextDirection.rtl,
                  child: AlertDialog(
                    title: const Text('إلغاء الخطة؟'),
                    content: const Text('سيُحذف تقدمك في هذه الختمة.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إلغاء الخطة')),
                    ],
                  ),
                ),
              );
              if (ok == true) await KhatmaService.reset();
            },
            child: const Text('تغيير الخطة / إعادة البدء'),
          ),
        ),
      ],
    );
  }
}
