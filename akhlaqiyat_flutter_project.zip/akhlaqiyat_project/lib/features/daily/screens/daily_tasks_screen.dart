import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/daily_tasks_service.dart';
import '../../../core/services/hadith_progress_service.dart';
import '../../../core/services/local_data_service.dart';
import '../../../core/services/quran_api_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../ethics/models/ethics_model.dart';
import '../../hadith/models/hadith_model.dart';
import '../../quran/models/surah_model.dart';

/// مهام اليوم الثلاث: احفظ آية مع تفسيرها، طبّق الخُلق، احفظ حديثًا مع
/// معناه. إنجاز أي مهمة يُشعل الشعلة العامة، وإتمام الثلاث يكمل اليوم.
class DailyTasksScreen extends StatefulWidget {
  const DailyTasksScreen({super.key});
  @override
  State<DailyTasksScreen> createState() => _DailyTasksScreenState();
}

class _AyahTaskData {
  final String surahName;
  final MemorizeAyah ref;
  final List<Ayah> ayat;
  const _AyahTaskData(this.surahName, this.ref, this.ayat);
}

class _DailyTasksScreenState extends State<DailyTasksScreen> {
  Map<DailyTask, bool> _done = {for (final t in DailyTask.values) t: false};
  late Future<_AyahTaskData> _ayahFuture = _loadAyah();
  late final Future<Hadith> _hadithFuture = LocalDataService.dailyHadith();
  bool _showTafsir = false;

  @override
  void initState() {
    super.initState();
    _refresh();
    DailyTasksService.version.addListener(_refresh);
    HadithProgressService.version.addListener(_refresh);
  }

  @override
  void dispose() {
    DailyTasksService.version.removeListener(_refresh);
    HadithProgressService.version.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _refresh() async {
    final m = await DailyTasksService.load();
    if (!mounted) return;
    setState(() => _done = m);
  }

  Future<_AyahTaskData> _loadAyah() async {
    final ref = await DailyTasksService.todaysAyah();
    final surahs = await LocalDataService.surahs();
    final name = surahs.firstWhere((s) => s.number == ref.surah).nameArabic;
    final api = QuranApiService();
    try {
      List<Ayah> ayat;
      try {
        ayat = await Future.wait([
          for (var n = ref.from; n <= ref.to; n++) api.getVerse(ref.surah, n),
        ]);
      } catch (_) {
        // مسار بديل مضمون: نجلب السورة كاملة (نفس طلب شاشة القرآن) ونقتطع الآيات
        final all = await api.getSurahVerses(ref.surah);
        ayat = all.where((a) => a.number >= ref.from && a.number <= ref.to).toList();
        if (ayat.isEmpty) throw QuranApiException('لم تُعثر الآية في الاستجابة');
      }
      return _AyahTaskData(name, ref, ayat);
    } catch (_) {
      // بدون إنترنت: نعرض النص المضمّن في التطبيق بدون التفسير
      if (ref.text.isEmpty) rethrow;
      return _AyahTaskData(
        name,
        ref,
        [Ayah(globalId: 0, number: ref.from, arabicText: ref.text, tafsirText: null)],
      );
    }
  }

  Future<void> _complete(DailyTask t, String message) async {
    await DailyTasksService.complete(t);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final doneCount = _done.values.where((v) => v).length;
    final total = DailyTask.values.length;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مهام اليوم')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _progressHeader(doneCount, total),
            const SizedBox(height: 16),
            _ayahCard(),
            const SizedBox(height: 14),
            _ethicCard(),
            const SizedBox(height: 14),
            _hadithCard(),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _progressHeader(int done, int total) {
    final allDone = done == total;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppColors.emerald, AppColors.emeraldDeep]),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.local_fire_department, color: AppColors.ember2, size: 26),
              const SizedBox(width: 8),
              Expanded(
                child: Text(allDone ? 'أتممت مهام اليوم، بارك الله فيك' : 'أنجزت $done من $total',
                    style: GoogleFonts.tajawal(
                        fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.paper)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: done / total,
              minHeight: 8,
              backgroundColor: Colors.white.withOpacity(0.18),
              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.goldBright),
            ),
          ),
          const SizedBox(height: 8),
          Text('إنجاز أي مهمة يُشعل شعلتك لهذا اليوم',
              style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.paper.withOpacity(0.85))),
        ],
      ),
    );
  }

  Widget _shell({
    required String title,
    required IconData icon,
    required bool done,
    required Widget body,
    required String buttonLabel,
    required String doneLabel,
    required VoidCallback onDone,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: done ? AppColors.emerald.withOpacity(0.08) : AppColors.paperDim,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: done ? AppColors.emerald : AppColors.emerald.withOpacity(0.18), width: done ? 1.6 : 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(done ? Icons.check_circle : icon, color: done ? AppColors.emerald : AppColors.gold, size: 22),
              const SizedBox(width: 8),
              Expanded(
                child: Text(title,
                    style: GoogleFonts.tajawal(
                        fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.emeraldDeep)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          body,
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: done ? null : onDone,
              child: Text(done ? doneLabel : buttonLabel),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ayahCard() {
    return FutureBuilder<_AyahTaskData>(
      future: _ayahFuture,
      builder: (context, snap) {
        Widget body;
        if (snap.connectionState != ConnectionState.done) {
          body = const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(child: CircularProgressIndicator()),
          );
        } else if (snap.hasError || snap.data == null) {
          body = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('تعذّر تحميل آية اليوم. تحقق من الاتصال بالإنترنت ثم أعد المحاولة.',
                  style: GoogleFonts.tajawal(fontSize: 13, color: AppColors.inkSoft, height: 1.7)),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () => setState(() => _ayahFuture = _loadAyah()),
                child: const Text('إعادة المحاولة'),
              ),
            ],
          );
        } else {
          final d = snap.data!;
          final range = d.ref.from == d.ref.to ? '${d.ref.from}' : '${d.ref.from}-${d.ref.to}';
          body = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.paper,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      d.ayat.map((a) => '${a.arabicText} ﴿${a.number}﴾').join(' '),
                      textAlign: TextAlign.center,
                      style: GoogleFonts.amiri(fontSize: 22, height: 2.1, color: AppColors.ink),
                    ),
                    const SizedBox(height: 4),
                    Text('سورة ${d.surahName} — $range',
                        style: GoogleFonts.tajawal(
                            fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Text('المعنى', style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(d.ref.meaning,
                  style: GoogleFonts.tajawal(fontSize: 14.5, color: AppColors.ink, height: 1.9, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              InkWell(
                onTap: () => setState(() => _showTafsir = !_showTafsir),
                child: Row(
                  children: [
                    Icon(_showTafsir ? Icons.expand_less : Icons.expand_more, size: 18, color: AppColors.emerald),
                    const SizedBox(width: 4),
                    Text(_showTafsir ? 'إخفاء تفسير السعدي' : 'اقرأ تفسير السعدي',
                        style: GoogleFonts.tajawal(
                            fontSize: 12.5, color: AppColors.emerald, fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
              if (_showTafsir && d.ayat.every((a) => (a.tafsirText ?? '').isEmpty))
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text('التفسير غير متاح الآن، يحتاج اتصالًا بالإنترنت.',
                      style: GoogleFonts.tajawal(fontSize: 13, color: AppColors.inkSoft)),
                ),
              if (_showTafsir)
                for (final a in d.ayat)
                  if (a.tafsirText != null && a.tafsirText!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(a.tafsirText!,
                          style: GoogleFonts.tajawal(
                              fontSize: 17, color: AppColors.ink, fontWeight: FontWeight.w700, height: 2)),
                    ),
            ],
          );
        }
        return _shell(
          title: 'احفظ هذه الآية مع تفسيرها',
          icon: Icons.menu_book_outlined,
          done: _done[DailyTask.ayah] ?? false,
          body: body,
          buttonLabel: 'حفظتها وفهمت معناها',
          doneLabel: 'أنجزت مهمة الآية',
          onDone: () => _complete(DailyTask.ayah, 'أحسنت! تم تسجيل حفظ آية اليوم'),
        );
      },
    );
  }

  Widget _ethicCard() {
    final dayIndex = DateTime.now().difference(DateTime(2026, 1, 1)).inDays.abs();
    final c = ethicChallengesBank[dayIndex % ethicChallengesBank.length];
    return _shell(
      title: 'طبّق هذا الخُلق اليوم',
      icon: Icons.favorite_border,
      done: _done[DailyTask.ethic] ?? false,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(c.title,
              style: GoogleFonts.tajawal(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.ink)),
          const SizedBox(height: 6),
          Text(c.description, style: GoogleFonts.tajawal(fontSize: 14, color: AppColors.ink, height: 1.8)),
          const SizedBox(height: 8),
          Text('كيف أطبقه؟', style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(c.howTo, style: GoogleFonts.tajawal(fontSize: 13.5, color: AppColors.inkSoft, height: 1.8)),
          const SizedBox(height: 8),
          Text(c.relatedVerseOrHadith,
              style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.emeraldDeep, height: 1.7)),
        ],
      ),
      buttonLabel: 'طبّقته اليوم',
      doneLabel: 'أنجزت مهمة الخُلق',
      onDone: () => _complete(DailyTask.ethic, 'أحسنت! تم تسجيل تطبيقك للخُلق اليوم'),
    );
  }

  Widget _hadithCard() {
    return FutureBuilder<Hadith>(
      future: _hadithFuture,
      builder: (context, snap) {
        final h = snap.data;
        return _shell(
          title: 'احفظ هذا الحديث مع معناه',
          icon: Icons.bookmark_add_outlined,
          done: _done[DailyTask.hadith] ?? false,
          body: h == null
              ? const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Center(child: CircularProgressIndicator()),
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('«${h.arabicText}»',
                        style: GoogleFonts.tajawal(fontSize: 17, height: 2, color: AppColors.ink, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text('${h.narrator} — ${h.reference} — ${h.gradeLabel}',
                        style: GoogleFonts.tajawal(fontSize: 11.5, color: AppColors.gold, fontWeight: FontWeight.w700, height: 1.6)),
                    if (h.meaning.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text('المعنى',
                          style: GoogleFonts.tajawal(fontSize: 12, color: AppColors.gold, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(h.meaning,
                          style: GoogleFonts.tajawal(fontSize: 14.5, color: AppColors.ink, height: 1.9, fontWeight: FontWeight.w600)),
                    ],
                  ],
                ),
          buttonLabel: 'حفظته وفهمت معناه',
          doneLabel: 'أنجزت مهمة الحديث',
          onDone: () => _complete(DailyTask.hadith, 'أحسنت! تم تسجيل حفظك لحديث اليوم'),
        );
      },
    );
  }
}
