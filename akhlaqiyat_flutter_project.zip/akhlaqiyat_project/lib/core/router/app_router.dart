import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/home/screens/home_tab_screen.dart';
import '../../features/onboarding/screens/onboarding_screen.dart';
import '../../features/quran/screens/surah_list_screen.dart';
import '../../features/quran/screens/surah_reader_screen.dart';
import '../../features/quran/models/surah_model.dart';
import '../../features/hadith/screens/hadith_screens.dart';
import '../../features/hadith/models/hadith_model.dart';
import '../../features/azkar/screens/azkar_categories_screen.dart';
import '../../features/azkar/screens/azkar_counter_screen.dart';
import '../../features/azkar/models/azkar_model.dart';
import '../../features/prayer_times/screens/prayer_times_screen.dart';
import '../../features/ethics/screens/ethics_screens.dart';
import '../../features/fiqh/screens/fiqh_screen.dart';
import '../../features/hifz/screens/hifz_screen.dart';
import '../../features/daily/screens/daily_tasks_screen.dart';
import '../../features/settings/screens/settings_screen.dart';
import '../../features/stories/screens/stories_screen.dart';
import '../../features/habits/screens/habits_screen.dart';
import '../../features/khatma/khatma_screen.dart';
import '../../features/stats/stats_screen.dart';
import '../widgets/app_shell.dart';

// خريطة التنقل الكاملة للتطبيق عبر go_router.
// البنية: StatefulShellRoute.indexedStack يحافظ على حالة كل تبويب
// (مثال: مكان التمرير في قائمة السور) عند التنقل بينها، وهو الأسلوب
// الموصى به رسميًا من فريق Flutter لأشرطة تنقل سفلية بها Navigator
// مستقل لكل تبويب.

final _rootNavigatorKey = GlobalKey<NavigatorState>();

final appRouter = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/onboarding',
  redirect: (context, state) async {
    // يوجّه لشاشة الترحيب مرة واحدة فقط عند أول فتح للتطبيق، ثم لا
    // يعترض أي مسار آخر بعدها.
    final seen = await OnboardingScreen.hasSeen();
    final goingToOnboarding = state.matchedLocation == '/onboarding';
    if (!seen && !goingToOnboarding) return '/onboarding';
    if (seen && goingToOnboarding) return '/home';
    return null;
  },
  routes: [
    GoRoute(
      path: '/onboarding',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const OnboardingScreen(),
    ),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => AppShell(navigationShell: navigationShell),
      branches: [
        // التبويب 1: اليوم (الرئيسية)
        StatefulShellBranch(routes: [
          GoRoute(path: '/home', builder: (context, state) => const HomeTabScreen()),
        ]),
        // التبويب 2: القرآن
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/quran',
            builder: (context, state) => const SurahListScreen(),
            routes: [
              GoRoute(
                path: 'surah', // /quran/surah?number=..
                builder: (context, state) {
                  final extra = state.extra;
                  if (extra is SurahReaderArgs) {
                    return SurahReaderScreen(surah: extra.surah, initialAyah: extra.ayah);
                  }
                  return SurahReaderScreen(surah: extra as Surah);
                },
              ),
            ],
          ),
        ]),
        // التبويب 3: الحديث
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/hadith',
            builder: (context, state) => const HadithCollectionsScreen(),
            routes: [
              GoRoute(
                path: 'collection',
                builder: (context, state) {
                  final collection = state.extra as HadithCollection;
                  return HadithListScreen(collection: collection);
                },
              ),
            ],
          ),
        ]),
        // التبويب 4: الأذكار
        StatefulShellBranch(routes: [
          GoRoute(
            path: '/azkar',
            builder: (context, state) => const AzkarCategoriesScreen(),
            routes: [
              GoRoute(
                path: 'counter',
                builder: (context, state) {
                  final category = state.extra as AzkarCategory;
                  return AzkarCounterScreen(category: category);
                },
              ),
            ],
          ),
        ]),
        // التبويب 5: الصلاة والقبلة
        StatefulShellBranch(routes: [
          GoRoute(path: '/prayer', builder: (context, state) => const PrayerTimesScreen()),
        ]),
      ],
    ),
    // شاشات تُفتح فوق الشريط السفلي (لا تنتمي لتبويب معيّن) — تصل إليها
    // من "الوصول السريع" في الصفحة الرئيسية عبر context.push(...)
    GoRoute(
      path: '/ethics/challenge',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const DailyChallengeScreen(),
    ),
    GoRoute(
      path: '/ethics/seerah',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const SeerahMomentScreen(),
    ),
    GoRoute(
      path: '/fiqh',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const FiqhScreen(),
    ),
    GoRoute(
      path: '/hifz',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const HifzScreen(),
    ),
    GoRoute(
      path: '/daily',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const DailyTasksScreen(),
    ),
    GoRoute(
      path: '/habits',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const HabitsScreen(),
    ),
    GoRoute(
      path: '/stories',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const StoriesScreen(),
    ),
    GoRoute(
      path: '/khatma',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const KhatmaScreen(),
    ),
    GoRoute(
      path: '/stats',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const StatsScreen(),
    ),
    GoRoute(
      path: '/settings',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const SettingsScreen(),
    ),
  ],
);
