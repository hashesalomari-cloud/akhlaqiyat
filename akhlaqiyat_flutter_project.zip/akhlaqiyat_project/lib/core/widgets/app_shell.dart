import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

/// الحاوية الرئيسية: تعرض شريط التنقل السفلي فوق التبويبات الخمسة.
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.navigationShell});
  final StatefulNavigationShell navigationShell;

  static const _items = [
    ('اليوم', Icons.local_fire_department_outlined, Icons.local_fire_department),
    ('القرآن', Icons.menu_book_outlined, Icons.menu_book),
    ('الحديث', Icons.article_outlined, Icons.article),
    ('الأذكار', Icons.spa_outlined, Icons.spa),
    ('الصلاة', Icons.explore_outlined, Icons.explore),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.night1, AppColors.night2],
          ),
          border: Border(top: BorderSide(color: AppColors.gold, width: 2)),
        ),
        child: Material(
          color: Colors.transparent,
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 62,
              child: Row(
                children: List.generate(_items.length, (i) {
                  final selected = i == navigationShell.currentIndex;
                  final item = _items[i];
                  final color = selected
                      ? AppColors.goldBright
                      : AppColors.gold.withOpacity(0.6);
                  return Expanded(
                    child: InkWell(
                      onTap: () => navigationShell.goBranch(
                        i,
                        initialLocation: i == navigationShell.currentIndex,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(selected ? item.$3 : item.$2, size: 22, color: color),
                          const SizedBox(height: 4),
                          Text(
                            item.$1,
                            style: GoogleFonts.tajawal(
                              fontSize: 11,
                              color: color,
                              fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
