import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

// الحاوية الرئيسية (Shell) التي تعرض شريط التنقل السفلي فوق كل تبويب،
// وتحافظ على حالة كل تبويب مستقلة بفضل StatefulShellRoute.indexedStack.

class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.navigationShell});
  final StatefulNavigationShell navigationShell;

  static const _items = [
    ('اليوم', Icons.local_fire_department_outlined, Icons.local_fire_department),
    ('القرآن', Icons.menu_book_outlined, Icons.menu_book),
    ('الحديث', Icons.article_outlined, Icons.article),
    ('الأذكار', Icons.spa_outlined, Icons.spa),
    ('الصلاة', Icons.explore_outlined, Icons.explore),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: navigationShell,
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.night1, AppColors.night2],
            ),
            border: Border(top: BorderSide(color: AppColors.gold, width: 2)),
          ),
          child: SafeArea(
            top: false,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: List.generate(_items.length, (i) {
                final selected = i == navigationShell.currentIndex;
                final item = _items[i];
                return InkWell(
                  onTap: () => navigationShell.goBranch(
                    i,
                    // العودة لجذر التبويب إذا كان مفعّلاً مسبقًا (يمنع تكديس الشاشات)
                    initialLocation: i == navigationShell.currentIndex,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                    child: Column(
                      children: [
                        Icon(selected ? item.$3 : item.$2,
                            size: 20,
                            color: selected ? AppColors.goldBright : AppColors.gold.withOpacity(0.6)),
                        const SizedBox(height: 4),
                        Text(item.$1,
                            style: GoogleFonts.tajawal(
                              fontSize: 11,
                              color: selected ? AppColors.goldBright : AppColors.gold.withOpacity(0.6),
                              fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                            )),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}
