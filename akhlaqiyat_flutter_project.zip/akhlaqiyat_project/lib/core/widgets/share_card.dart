import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../theme/app_theme.dart';

/// أنماط خلفيات البطاقة (ألوان ثابتة هادئة، لا تتأثر بوضع التطبيق)
class _CardStyle {
  final String name;
  final List<Color> colors;
  final Color text, accent;
  const _CardStyle(this.name, this.colors, this.text, this.accent);
}

const _styles = <_CardStyle>[
  _CardStyle('ليل زمردي', [Color(0xFF0B2233), Color(0xFF0E3B3A)], Color(0xFFFBF6EA), Color(0xFFE8B94A)),
  _CardStyle('فجر', [Color(0xFF1E3A5F), Color(0xFF6C5B7B)], Color(0xFFFFF8EC), Color(0xFFFFCB57)),
  _CardStyle('رمل', [Color(0xFFFBF6EA), Color(0xFFF1E8D3)], Color(0xFF20261F), Color(0xFF0E6E52)),
  _CardStyle('أسود', [Color(0xFF000000), Color(0xFF0D0D0D)], Color(0xFFEFE8D6), Color(0xFFC9992E)),
];

/// زر مشاركة صغير يفتح معاينة بطاقة جميلة قابلة للمشاركة كصورة.
class ShareCardButton extends StatelessWidget {
  final String text;
  final String source;
  final Color? color;
  const ShareCardButton({super.key, required this.text, required this.source, this.color});

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: 'مشاركة كبطاقة',
        icon: Icon(Icons.ios_share, size: 20, color: color ?? AppColors.emerald),
        onPressed: () => showQuoteCardDialog(context, text: text, source: source),
      );
}

Future<void> showQuoteCardDialog(BuildContext context,
    {required String text, required String source}) {
  return showDialog<void>(
    context: context,
    builder: (_) => _QuoteCardDialog(text: text, source: source),
  );
}

class _QuoteCardDialog extends StatefulWidget {
  final String text, source;
  const _QuoteCardDialog({required this.text, required this.source});
  @override
  State<_QuoteCardDialog> createState() => _QuoteCardDialogState();
}

class _QuoteCardDialogState extends State<_QuoteCardDialog> {
  final _key = GlobalKey();
  int _style = 0;
  bool _busy = false;

  Future<void> _share() async {
    setState(() => _busy = true);
    try {
      final boundary = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final image = await boundary.toImage(pixelRatio: 3);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/akhlaqiyat_card_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(data!.buffer.asUint8List());
      await Share.shareXFiles([XFile(file.path)], text: 'من تطبيق أخلاقيات');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذّرت المشاركة: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = _styles[_style];
    final long = widget.text.length > 180;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Dialog(
        backgroundColor: AppColors.paper,
        insetPadding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RepaintBoundary(
                key: _key,
                child: Container(
                  width: 320,
                  padding: const EdgeInsets.fromLTRB(22, 28, 22, 20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: st.colors,
                    ),
                  ),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(16, 22, 16, 14),
                    decoration: BoxDecoration(
                      border: Border.all(color: st.accent.withOpacity(0.7), width: 1.2),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('✦', style: TextStyle(color: st.accent, fontSize: 22)),
                        const SizedBox(height: 10),
                        Text(widget.text,
                            textAlign: TextAlign.center,
                            style: AppFonts.quran(
                                fontSize: long ? 17 : 23, height: 2.0, color: st.text)),
                        const SizedBox(height: 14),
                        Text(widget.source,
                            textAlign: TextAlign.center,
                            style: AppFonts.ui(
                                fontSize: 12.5, fontWeight: FontWeight.w800, color: st.accent, height: 1.6)),
                        const SizedBox(height: 16),
                        Container(height: 1, width: 60, color: st.accent.withOpacity(0.6)),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(5),
                              child: Image.asset('assets/icon/logo_512.png', width: 22, height: 22),
                            ),
                            const SizedBox(width: 6),
                            Text('أخلاقيات',
                                style: AppFonts.ui(
                                    fontSize: 13, fontWeight: FontWeight.w900, color: st.text.withOpacity(0.85))),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 6,
                children: [
                  for (var i = 0; i < _styles.length; i++)
                    ChoiceChip(
                      label: Text(_styles[i].name, style: AppFonts.ui(fontSize: 12)),
                      selected: _style == i,
                      onSelected: (_) => setState(() => _style = i),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : _share,
                      icon: _busy
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.share),
                      label: const Text('مشاركة الصورة'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
