import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../settings/app_settings.dart';

/// لوحة ألوان واحدة (فاتح / داكن / OLED أسود).
class AppPalette {
  final Color night1, night2, paper, paperDim, ink, inkSoft, emerald, emeraldDeep;
  const AppPalette({
    required this.night1,
    required this.night2,
    required this.paper,
    required this.paperDim,
    required this.ink,
    required this.inkSoft,
    required this.emerald,
    required this.emeraldDeep,
  });

  static const light = AppPalette(
    night1: Color(0xFF0B2233),
    night2: Color(0xFF0E3B3A),
    paper: Color(0xFFFBF6EA),
    paperDim: Color(0xFFF1E8D3),
    ink: Color(0xFF20261F),
    inkSoft: Color(0xFF5B6154),
    emerald: Color(0xFF0E6E52),
    emeraldDeep: Color(0xFF0A4A3B),
  );

  static const dark = AppPalette(
    night1: Color(0xFF0B2233),
    night2: Color(0xFF0E3B3A),
    paper: Color(0xFF12171B),
    paperDim: Color(0xFF1C2429),
    ink: Color(0xFFEFE8D6),
    inkSoft: Color(0xFFABB3A6),
    emerald: Color(0xFF22906F),
    emeraldDeep: Color(0xFF0E5240),
  );

  /// أسود حقيقي لشاشات OLED (يوفّر البطارية ومريح للعين ليلًا).
  static const oled = AppPalette(
    night1: Color(0xFF000000),
    night2: Color(0xFF07110E),
    paper: Color(0xFF000000),
    paperDim: Color(0xFF111614),
    ink: Color(0xFFE9DFC2),
    inkSoft: Color(0xFFA6A08C),
    emerald: Color(0xFF22906F),
    emeraldDeep: Color(0xFF0E5240),
  );
}

/// ألوان التطبيق. الألوان المتغيرة بين الأوضاع (getters) لا يمكن
/// استخدامها داخل تعبيرات const.
class AppColors {
  static AppPalette _p = AppPalette.light;
  static bool isDark = false;

  static Color get night1 => _p.night1;
  static Color get night2 => _p.night2;
  static Color get paper => _p.paper;
  static Color get paperDim => _p.paperDim;
  static Color get ink => _p.ink;
  static Color get inkSoft => _p.inkSoft;
  static Color get emerald => _p.emerald;
  static Color get emeraldDeep => _p.emeraldDeep;

  // ثابتة في كل الأوضاع
  static const gold = Color(0xFFC9992E);
  static const goldBright = Color(0xFFE8B94A);
  static const ember1 = Color(0xFFFF8A3D);
  static const ember2 = Color(0xFFFFCB57);

  /// لون نص فاتح دائمًا، للكتابة فوق الخلفيات المتدرجة الداكنة.
  static const onGrad = Color(0xFFFBF6EA);

  static void configure({required bool dark, required bool oled, Color? ink}) {
    isDark = dark;
    var p = dark ? (oled ? AppPalette.oled : AppPalette.dark) : AppPalette.light;
    if (ink != null) {
      p = AppPalette(
        night1: p.night1,
        night2: p.night2,
        paper: p.paper,
        paperDim: p.paperDim,
        ink: ink,
        inkSoft: p.inkSoft,
        emerald: p.emerald,
        emeraldDeep: p.emeraldDeep,
      );
    }
    _p = p;
  }
}

/// خطوط التطبيق حسب اختيار المستخدم في الإعدادات.
class AppFonts {
  static TextStyle _make(String family, double? size, FontWeight? weight,
      Color? color, double? height, double? letterSpacing) {
    final base = TextStyle(
      fontSize: size,
      fontWeight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
    );
    try {
      return GoogleFonts.getFont(family, textStyle: base);
    } catch (_) {
      return GoogleFonts.tajawal(textStyle: base);
    }
  }

  static FontWeight? _bump(FontWeight? w) {
    if (!AppSettings.I.boldText) return w;
    final i = ((w?.index ?? 3) + 1).clamp(0, 8);
    return FontWeight.values[i];
  }

  /// خط الواجهة العام
  static TextStyle ui({
    double? fontSize,
    FontWeight? fontWeight,
    Color? color,
    double? height,
    double? letterSpacing,
  }) =>
      _make(AppSettings.I.uiFontFamily, fontSize, _bump(fontWeight), color, height,
          letterSpacing);

  /// خط الآيات والنصوص القرآنية
  static TextStyle quran({
    double? fontSize,
    FontWeight? fontWeight,
    Color? color,
    double? height,
    double? letterSpacing,
  }) =>
      _make(AppSettings.I.quranFontFamily, fontSize, _bump(fontWeight), color,
          height, letterSpacing);
}

class AppTheme {
  static ThemeData build() {
    final dark = AppColors.isDark;
    final base = dark ? ThemeData.dark(useMaterial3: true) : ThemeData.light(useMaterial3: true);
    TextTheme tt;
    try {
      tt = GoogleFonts.getTextTheme(AppSettings.I.uiFontFamily, base.textTheme);
    } catch (_) {
      tt = GoogleFonts.tajawalTextTheme(base.textTheme);
    }
    tt = tt.apply(bodyColor: AppColors.ink, displayColor: AppColors.ink);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.paper,
      canvasColor: AppColors.paper,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.emerald,
        secondary: AppColors.gold,
        surface: AppColors.paperDim,
      ),
      dividerColor: AppColors.inkSoft.withOpacity(0.2),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.night2,
        foregroundColor: AppColors.goldBright,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: AppFonts.ui(
          fontWeight: FontWeight.w900,
          fontSize: 18,
          color: AppColors.goldBright,
        ),
      ),
      textTheme: tt,
      dialogBackgroundColor: AppColors.paper,
      bottomSheetTheme: BottomSheetThemeData(backgroundColor: AppColors.paper),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.ember2,
          foregroundColor: const Color(0xFF3A1E00),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: AppFonts.ui(fontWeight: FontWeight.w900, fontSize: 15),
        ),
      ),
      useMaterial3: true,
    );
  }
}
