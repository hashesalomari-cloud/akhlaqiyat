import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// الثيم الموحّد للتطبيق — يجمع نظام الألوان المستخدم في كل الشاشات
// السابقة في مكان واحد، لتسهيل التعديل المستقبلي (مثال: وضع ليلي كامل).

class AppColors {
  static const night1 = Color(0xFF0B2233);
  static const night2 = Color(0xFF0E3B3A);
  static const paper = Color(0xFFFBF6EA);
  static const paperDim = Color(0xFFF1E8D3);
  static const ink = Color(0xFF20261F);
  static const inkSoft = Color(0xFF5B6154);
  static const emerald = Color(0xFF0E6E52);
  static const emeraldDeep = Color(0xFF0A4A3B);
  static const gold = Color(0xFFC9992E);
  static const goldBright = Color(0xFFE8B94A);
  static const ember1 = Color(0xFFFF8A3D);
  static const ember2 = Color(0xFFFFCB57);
}

class AppTheme {
  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.paper,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.emerald,
        secondary: AppColors.gold,
        surface: AppColors.paperDim,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.night2,
        foregroundColor: AppColors.goldBright,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.tajawal(
          fontWeight: FontWeight.w900,
          fontSize: 18,
          color: AppColors.goldBright,
        ),
      ),
      textTheme: GoogleFonts.tajawalTextTheme(base.textTheme).apply(
        bodyColor: AppColors.ink,
        displayColor: AppColors.ink,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.ember2,
          foregroundColor: const Color(0xFF3A1E00),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: GoogleFonts.tajawal(fontWeight: FontWeight.w900, fontSize: 15),
        ),
      ),
      useMaterial3: true,
    );
  }

  // مساحة جاهزة لثيم داكن كامل لاحقًا — حاليًا بطاقات الألوان في كل
  // شاشة تستخدم قيمًا ثابتة، وتفعيل dark mode كامل يتطلب توحيدها
  // عبر Theme.of(context) بدل الثوابت المباشرة (خطوة تحسين لاحقة).
}
