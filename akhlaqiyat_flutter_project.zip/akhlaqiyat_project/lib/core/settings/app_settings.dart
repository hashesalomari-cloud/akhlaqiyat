import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FontChoice {
  final String family; // اسم الخط في Google Fonts
  final String label;
  const FontChoice(this.family, this.label);
}

const uiFonts = <FontChoice>[
  FontChoice('Tajawal', 'تجوّل'),
  FontChoice('Cairo', 'القاهرة'),
  FontChoice('Almarai', 'المراعي'),
  FontChoice('Noto Naskh Arabic', 'نسخ'),
];

const quranFonts = <FontChoice>[
  FontChoice('Amiri', 'أميري'),
  FontChoice('Amiri Quran', 'أميري قرآن'),
  FontChoice('Scheherazade New', 'شهرزاد'),
  FontChoice('Noto Naskh Arabic', 'نسخ'),
];

class InkChoice {
  final String label;
  final Color? light; // null = اللون الافتراضي
  final Color? dark;
  const InkChoice(this.label, this.light, this.dark);
}

const inkChoices = <InkChoice>[
  InkChoice('الافتراضي', null, null),
  InkChoice('تباين عالٍ', Color(0xFF000000), Color(0xFFFFFFFF)),
  InkChoice('أخضر', Color(0xFF0B5A2B), Color(0xFF7DE0A0)),
  InkChoice('أزرق', Color(0xFF0B3C8C), Color(0xFF8CC4FF)),
  InkChoice('بنّي', Color(0xFF5A2E0A), Color(0xFFE8A86A)),
  InkChoice('ذهبي', Color(0xFF8A5F00), Color(0xFFFFD36B)),
  InkChoice('وردي', Color(0xFF8A1F4B), Color(0xFFFFA3C4)),
];

/// إعدادات المستخدم (تُحفظ على الجهاز ويُعاد بناء التطبيق عند تغييرها).
class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings I = AppSettings._();

  /// 0 = تلقائي (حسب النظام)، 1 = فاتح، 2 = داكن، 3 = أسود OLED
  int themeMode = 0;
  int uiFont = 0;
  int quranFont = 0;
  int inkIndex = 0;
  double textScale = 1.0;
  bool boldText = false;
  bool haptics = true;

  String get uiFontFamily => uiFonts[uiFont.clamp(0, uiFonts.length - 1)].family;
  String get quranFontFamily =>
      quranFonts[quranFont.clamp(0, quranFonts.length - 1)].family;

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      themeMode = p.getInt('set_theme') ?? 0;
      uiFont = p.getInt('set_ui_font') ?? 0;
      quranFont = p.getInt('set_quran_font') ?? 0;
      inkIndex = p.getInt('set_ink') ?? 0;
      textScale = p.getDouble('set_text_scale') ?? 1.0;
      boldText = p.getBool('set_bold') ?? false;
      haptics = p.getBool('set_haptics') ?? true;
    } catch (_) {}
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('set_theme', themeMode);
      await p.setInt('set_ui_font', uiFont);
      await p.setInt('set_quran_font', quranFont);
      await p.setInt('set_ink', inkIndex);
      await p.setDouble('set_text_scale', textScale);
      await p.setBool('set_bold', boldText);
      await p.setBool('set_haptics', haptics);
    } catch (_) {}
  }

  void update(void Function() change) {
    change();
    notifyListeners();
    _save();
  }
}
