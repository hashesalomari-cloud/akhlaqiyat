import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'habit_service.dart';

/// مقطع قرآني يحفظه المستخدم: قيد الحفظ ثم محفوظ، مع جدول مراجعة متباعد.
class HifzItem {
  final String id;
  final int surah, from, to;
  final String surahName;
  final int status; // 0 قيد الحفظ، 1 محفوظ
  final DateTime? lastReview;
  final int step; // موضع جدول المراجعة

  const HifzItem({
    required this.id,
    required this.surah,
    required this.from,
    required this.to,
    required this.surahName,
    this.status = 0,
    this.lastReview,
    this.step = 0,
  });

  /// فواصل المراجعة بالأيام بعد الحفظ: ١، ٣، ٧، ١٤، ٣٠، ٦٠، ٩٠
  static const intervals = [1, 3, 7, 14, 30, 60, 90];

  DateTime? get nextReview => lastReview == null
      ? null
      : lastReview!.add(Duration(days: intervals[step.clamp(0, intervals.length - 1)]));

  bool get due {
    if (status != 1) return false;
    final n = nextReview;
    return n == null || !DateTime.now().isBefore(n);
  }

  String get rangeLabel => from == to ? 'الآية $from' : 'الآيات $from–$to';

  HifzItem copyWith({int? status, DateTime? lastReview, int? step}) => HifzItem(
        id: id,
        surah: surah,
        from: from,
        to: to,
        surahName: surahName,
        status: status ?? this.status,
        lastReview: lastReview ?? this.lastReview,
        step: step ?? this.step,
      );

  Map<String, Object?> toJson() => {
        'id': id,
        's': surah,
        'f': from,
        't': to,
        'n': surahName,
        'st': status,
        'lr': lastReview?.toIso8601String(),
        'sp': step,
      };

  factory HifzItem.fromJson(Map<String, dynamic> j) => HifzItem(
        id: j['id'] as String,
        surah: j['s'] as int,
        from: j['f'] as int,
        to: j['t'] as int,
        surahName: j['n'] as String,
        status: j['st'] as int? ?? 0,
        lastReview: j['lr'] == null ? null : DateTime.tryParse(j['lr'] as String),
        step: j['sp'] as int? ?? 0,
      );
}

class HifzService {
  static const _k = 'hifz_items_v2';
  static final ValueNotifier<int> version = ValueNotifier(0);

  static Future<List<HifzItem>> all() async {
    final p = await SharedPreferences.getInstance();
    final out = <HifzItem>[];
    for (final s in p.getStringList(_k) ?? const <String>[]) {
      try {
        out.add(HifzItem.fromJson(jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {}
    }
    return out;
  }

  static Future<void> _save(List<HifzItem> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_k, [for (final i in l) jsonEncode(i.toJson())]);
    version.value++;
  }

  static Future<void> add(int surah, String name, int from, int to) async {
    final l = await all();
    l.insert(
      0,
      HifzItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        surah: surah,
        from: from,
        to: to,
        surahName: name,
      ),
    );
    await _save(l);
  }

  static Future<void> markMemorized(String id) async {
    final l = await all();
    final i = l.indexWhere((x) => x.id == id);
    if (i < 0) return;
    l[i] = l[i].copyWith(status: 1, lastReview: DateTime.now(), step: 0);
    await _save(l);
    await HabitService.mark('quran');
  }

  static Future<void> reviewed(String id) async {
    final l = await all();
    final i = l.indexWhere((x) => x.id == id);
    if (i < 0) return;
    l[i] = l[i].copyWith(lastReview: DateTime.now(), step: l[i].step + 1);
    await _save(l);
    await HabitService.mark('quran');
  }

  /// «نسيت جزءًا منه»: نعيد جدول المراجعة من أوله.
  static Future<void> forgot(String id) async {
    final l = await all();
    final i = l.indexWhere((x) => x.id == id);
    if (i < 0) return;
    l[i] = l[i].copyWith(lastReview: DateTime.now(), step: 0);
    await _save(l);
  }

  static Future<void> remove(String id) async {
    final l = await all();
    l.removeWhere((x) => x.id == id);
    await _save(l);
  }
}
