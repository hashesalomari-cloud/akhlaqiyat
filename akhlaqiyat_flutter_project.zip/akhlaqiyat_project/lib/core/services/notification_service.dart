import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import 'prayer_time_service.dart';

/// الإشعارات: تذكير الشعلة اليومي + تنبيه دخول وقت كل صلاة.
///
/// ملاحظة التوقيت: لا نعتمد على tz.local (يبقى UTC ما لم يُضبط). نحوّل
/// كل وقت محلي إلى لحظة مطلقة (UTC) فيصل الإشعار في وقته الصحيح دائمًا.
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static AndroidFlutterLocalNotificationsPlugin? get _android => _plugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> initialize() async {
    if (_ready) return;
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
    _ready = true;
  }

  /// يطلب إذن الإشعارات (أندرويد 13+).
  static Future<void> requestPermission() async {
    await initialize();
    await _android?.requestNotificationsPermission();
  }

  /// هل المنبهات الدقيقة مسموحة؟ (أندرويد 12+ قد يمنعها افتراضيًا)
  static Future<bool> canScheduleExact() async {
    await initialize();
    try {
      return await _android?.canScheduleExactNotifications() ?? false;
    } catch (_) {
      return false;
    }
  }

  /// يفتح شاشة إذن "المنبهات والتذكيرات" ليسمح المستخدم بالتوقيت الدقيق.
  static Future<void> requestExactAlarms() async {
    await initialize();
    try {
      await _android?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  static Future<AndroidScheduleMode> _mode() async =>
      await canScheduleExact()
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle;

  /// أقرب لحظة قادمة للساعة:الدقيقة المحلية، كـ TZDateTime بتوقيت UTC.
  static tz.TZDateTime _nextInstant(int hour, int minute) {
    final now = DateTime.now();
    var local = DateTime(now.year, now.month, now.day, hour, minute);
    if (!local.isAfter(now)) local = local.add(const Duration(days: 1));
    return tz.TZDateTime.from(local, tz.UTC);
  }

  static tz.TZDateTime _nextInstantOf(DateTime t) =>
      _nextInstant(t.hour, t.minute);

  static Future<void> _schedule(
    int id,
    String title,
    String body,
    tz.TZDateTime when,
    NotificationDetails details,
  ) async {
    Future<void> go(AndroidScheduleMode mode) => _plugin.zonedSchedule(
          id,
          title,
          body,
          when,
          details,
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.time, // يتكرر يوميًا
        );
    try {
      await go(await _mode());
    } catch (_) {
      // لو رُفض الوضع الدقيق نرجع للوضع التقريبي بدل أن يفشل الجدولة
      await go(AndroidScheduleMode.inexactAllowWhileIdle);
    }
  }

  /// تذكير يومي متكرر (افتراضيًا 8:00 مساءً بتوقيت الجهاز).
  static Future<void> scheduleDailyReminder({int hour = 20, int minute = 0}) async {
    await initialize();
    await _schedule(
      100,
      'حافظ على شعلتك 🔥',
      'ما زال وقت كافٍ لإنجاز وِردك اليوم قبل أن تنطفئ الشعلة',
      _nextInstant(hour, minute),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_streak_reminder',
          'تذكير الشعلة اليومي',
          importance: Importance.defaultImportance,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  static Future<void> cancelDailyReminder() async {
    await initialize();
    await _plugin.cancel(100);
  }

  static const _prayerIds = {
    'fajr': 201,
    'dhuhr': 202,
    'asr': 203,
    'maghrib': 204,
    'isha': 205,
  };

  static const _prayerLabels = {
    'fajr': 'الفجر',
    'dhuhr': 'الظهر',
    'asr': 'العصر',
    'maghrib': 'المغرب',
    'isha': 'العشاء',
  };

  static const _prayerDetails = NotificationDetails(
    android: AndroidNotificationDetails(
      'prayer_alerts_v2',
      'تنبيه دخول وقت الصلاة',
      channelDescription: 'إشعار قوي عند دخول وقت كل صلاة',
      importance: Importance.max,
      priority: Priority.high,
      category: AndroidNotificationCategory.alarm,
      audioAttributesUsage: AudioAttributesUsage.alarm,
      playSound: true,
      enableVibration: true,
      fullScreenIntent: false,
    ),
    iOS: DarwinNotificationDetails(interruptionLevel: InterruptionLevel.timeSensitive),
  );

  /// يجدول الصلوات الخمس كإشعارات تتكرر يوميًا في نفس الساعة. تُعاد
  /// الجدولة عند كل فتح للتطبيق بالمواقيت المحدّثة (لتعويض فرق الدقائق
  /// بين الأيام وتغيّر التوقيت الصيفي).
  static Future<void> schedulePrayerNotifications(Map<String, DateTime> times) async {
    await initialize();
    for (final entry in times.entries) {
      final id = _prayerIds[entry.key];
      final label = _prayerLabels[entry.key];
      if (id == null || label == null) continue;
      await _plugin.cancel(id);
      await _schedule(
        id,
        'حان الآن وقت صلاة $label 🕌',
        'اترك ما بيدك، وتوضأ، وقم للصلاة — جزاك الله خيرًا',
        _nextInstantOf(entry.value),
        _prayerDetails,
      );
    }
  }

  static Future<void> cancelPrayerNotifications() async {
    await initialize();
    for (final id in _prayerIds.values) {
      await _plugin.cancel(id);
    }
  }

  /// إشعار فوري للتجربة (للتأكد أن الإشعارات والصوت تعمل على الجهاز).
  static Future<void> showTest() async {
    await initialize();
    await requestPermission();
    await _plugin.show(
      299,
      'تجربة تنبيه الصلاة 🕌',
      'إن ظهر هذا الإشعار بصوت فالتنبيهات تعمل على جهازك',
      _prayerDetails,
    );
  }

  /// يحسب المواقيت ويجدول الإشعارات حسب إعدادات المستخدم. يُستدعى عند
  /// بدء التطبيق ومن شاشة الصلاة، فتبقى الإشعارات حاضرة دون فتح الشاشة.
  static Future<PrayerTimesResult?> refreshPrayerSchedule() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!(prefs.getBool(PrayerSettings.kAlerts) ?? true)) return null;
      final r = await PrayerTimeService().loadForCurrentLocation();
      await schedulePrayerNotifications({
        'fajr': r.fajr,
        'dhuhr': r.dhuhr,
        'asr': r.asr,
        'maghrib': r.maghrib,
        'isha': r.isha,
      });
      return r;
    } catch (_) {
      return null;
    }
  }
}
