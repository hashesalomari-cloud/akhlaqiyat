import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import 'hijri.dart';
import 'prayer_time_service.dart';

/// الإشعارات: تذكير الشعلة اليومي + تنبيه دخول وقت كل صلاة.
///
/// ملاحظة التوقيت: لا نعتمد على tz.local (يبقى UTC ما لم يُضبط). نحوّل
/// كل وقت محلي إلى لحظة مطلقة (UTC) فيصل الإشعار في وقته الصحيح دائمًا.
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static AndroidFlutterLocalNotificationsPlugin? get _android => _plugin
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> initialize() async {
    if (_ready) return;
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
    _ready = true;
  }

  /// يطلب إذن الإشعارات (أندرويد 13+).
  static Future<void> requestPermission() async {
    await initialize();
    await _android?.requestNotificationsPermission();
  }

  /// هل المنبهات الدقيقة مسموحة؟ (أندرويد 12+ قد يمنعها افتراضيًا)
  static Future<bool> canScheduleExact() async {
    await initialize();
    try {
      return await _android?.canScheduleExactNotifications() ?? false;
    } catch (_) {
      return false;
    }
  }

  /// يفتح شاشة إذن "المنبهات والتذكيرات" ليسمح المستخدم بالتوقيت الدقيق.
  static Future<void> requestExactAlarms() async {
    await initialize();
    try {
      await _android?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  static Future<AndroidScheduleMode> _mode() async =>
      await canScheduleExact()
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle;

  /// أقرب لحظة قادمة للساعة:الدقيقة المحلية، كـ TZDateTime بتوقيت UTC.
  static tz.TZDateTime _nextInstant(int hour, int minute) {
    final now = DateTime.now();
    var local = DateTime(now.year, now.month, now.day, hour, minute);
    if (!local.isAfter(now)) local = local.add(const Duration(days: 1));
    return tz.TZDateTime.from(local, tz.UTC);
  }

  static tz.TZDateTime _nextInstantOf(DateTime t) =>
      _nextInstant(t.hour, t.minute);

  static Future<void> _schedule(
    int id,
    String title,
    String body,
    tz.TZDateTime when,
    NotificationDetails details, {
    DateTimeComponents? match = DateTimeComponents.time,
  }) async {
    Future<void> go(AndroidScheduleMode mode) => _plugin.zonedSchedule(
          id,
          title,
          body,
          when,
          details,
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: match, // الافتراضي: يتكرر يوميًا
        );
    try {
      await go(await _mode());
    } catch (_) {
      // لو رُفض الوضع الدقيق نرجع للوضع التقريبي بدل أن يفشل الجدولة
      await go(AndroidScheduleMode.inexactAllowWhileIdle);
    }
  }

  /// تذكير يومي متكرر (افتراضيًا 8:00 مساءً بتوقيت الجهاز).
  static Future<void> scheduleDailyReminder({int hour = 20, int minute = 0}) async {
    await initialize();
    await _schedule(
      100,
      'حافظ على شعلتك 🔥',
      'ما زال وقت كافٍ لإنجاز وِردك اليوم قبل أن تنطفئ الشعلة',
      _nextInstant(hour, minute),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_streak_reminder',
          'تذكير الشعلة اليومي',
          importance: Importance.defaultImportance,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  static Future<void> cancelDailyReminder() async {
    await initialize();
    await _plugin.cancel(100);
  }

  static const _prayerIds = {
    'fajr': 201,
    'dhuhr': 202,
    'asr': 203,
    'maghrib': 204,
    'isha': 205,
  };

  static const _prayerLabels = {
    'fajr': 'الفجر',
    'dhuhr': 'الظهر',
    'asr': 'العصر',
    'maghrib': 'المغرب',
    'isha': 'العشاء',
  };

  static const _prayerDetails = NotificationDetails(
    android: AndroidNotificationDetails(
      'prayer_alerts_v2',
      'تنبيه دخول وقت الصلاة',
      channelDescription: 'إشعار قوي عند دخول وقت كل صلاة',
      importance: Importance.max,
      priority: Priority.high,
      category: AndroidNotificationCategory.alarm,
      audioAttributesUsage: AudioAttributesUsage.alarm,
      playSound: true,
      enableVibration: true,
      fullScreenIntent: false,
    ),
    iOS: DarwinNotificationDetails(interruptionLevel: InterruptionLevel.timeSensitive),
  );

  /// يجدول الصلوات الخمس كإشعارات تتكرر يوميًا في نفس الساعة. تُعاد
  /// الجدولة عند كل فتح للتطبيق بالمواقيت المحدّثة (لتعويض فرق الدقائق
  /// بين الأيام وتغيّر التوقيت الصيفي).
  static Future<void> schedulePrayerNotifications(Map<String, DateTime> times) async {
    await initialize();
    for (final entry in times.entries) {
      final id = _prayerIds[entry.key];
      final label = _prayerLabels[entry.key];
      if (id == null || label == null) continue;
      await _plugin.cancel(id);
      await _schedule(
        id,
        'حان الآن وقت صلاة $label 🕌',
        'اترك ما بيدك، وتوضأ، وقم للصلاة — جزاك الله خيرًا',
        _nextInstantOf(entry.value),
        _prayerDetails,
      );
    }
  }

  static Future<void> cancelPrayerNotifications() async {
    await initialize();
    for (final id in _prayerIds.values) {
      await _plugin.cancel(id);
    }
  }

  /// إشعار فوري للتجربة (للتأكد أن الإشعارات والصوت تعمل على الجهاز).
  static Future<void> showTest() async {
    await initialize();
    await requestPermission();
    await _plugin.show(
      299,
      'تجربة تنبيه الصلاة 🕌',
      'إن ظهر هذا الإشعار بصوت فالتنبيهات تعمل على جهازك',
      _prayerDetails,
    );
  }

  /// يحسب المواقيت ويجدول الإشعارات حسب إعدادات المستخدم. يُستدعى عند
  /// بدء التطبيق ومن شاشة الصلاة، فتبقى الإشعارات حاضرة دون فتح الشاشة.
  static Future<PrayerTimesResult?> refreshPrayerSchedule() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!(prefs.getBool(PrayerSettings.kAlerts) ?? true)) return null;
      final r = await PrayerTimeService().loadForCurrentLocation();
      await schedulePrayerNotifications({
        'fajr': r.fajr,
        'dhuhr': r.dhuhr,
        'asr': r.asr,
        'maghrib': r.maghrib,
        'isha': r.isha,
      });
      return r;
    } catch (_) {
      return null;
    }
  }

  // ───────────────────── التذكيرات الذكية ─────────────────────

  static const smartKahf = 'smart_kahf';
  static const smartFasting = 'smart_fasting';
  static const smartWhite = 'smart_white';
  static const smartSleep = 'smart_sleep';

  static const _smartDetails = NotificationDetails(
    android: AndroidNotificationDetails(
      'smart_reminders',
      'تذكيرات ذكية',
      channelDescription: 'سورة الكهف، صيام الاثنين والخميس والأيام البيض، أذكار النوم',
      importance: Importance.high,
      priority: Priority.high,
    ),
    iOS: DarwinNotificationDetails(),
  );

  /// أقرب لحظة قادمة ليوم الأسبوع المحلي [weekday] (1=الاثنين … 7=الأحد)
  static tz.TZDateTime _nextWeekday(int weekday, int hour, int minute) {
    final now = DateTime.now();
    var d = DateTime(now.year, now.month, now.day, hour, minute);
    while (d.weekday != weekday || !d.isAfter(now)) {
      d = DateTime(d.year, d.month, d.day + 1, hour, minute);
    }
    return tz.TZDateTime.from(d, tz.UTC);
  }

  /// يعيد بناء كل التذكيرات الذكية حسب إعدادات المستخدم (يُستدعى عند
  /// بدء التطبيق وعند تغيير أي مفتاح من الإعدادات).
  static Future<void> refreshSmartReminders() async {
    await initialize();
    final prefs = await SharedPreferences.getInstance();
    for (final id in [301, 302, 303, 304]) {
      await _plugin.cancel(id);
    }
    for (var i = 0; i < 45; i++) {
      await _plugin.cancel(400 + i);
    }

    if (prefs.getBool(smartKahf) ?? true) {
      await _schedule(301, 'يوم الجمعة 🌿',
          'لا تنسَ سورة الكهف والإكثار من الصلاة على النبي ﷺ — ورد في فضل قراءتها يوم الجمعة حديث',
          _nextWeekday(DateTime.friday, 9, 0), _smartDetails,
          match: DateTimeComponents.dayOfWeekAndTime);
    }
    if (prefs.getBool(smartFasting) ?? true) {
      await _schedule(302, 'غدًا الاثنين',
          'يُستحب صيام يوم الاثنين — تُعرض الأعمال فيه على الله', _nextWeekday(DateTime.sunday, 20, 0),
          _smartDetails, match: DateTimeComponents.dayOfWeekAndTime);
      await _schedule(303, 'غدًا الخميس',
          'يُستحب صيام يوم الخميس — تُعرض الأعمال فيه على الله', _nextWeekday(DateTime.wednesday, 20, 0),
          _smartDetails, match: DateTimeComponents.dayOfWeekAndTime);
    }
    if (prefs.getBool(smartSleep) ?? true) {
      await _schedule(304, 'أذكار النوم 🌙',
          'اختم يومك بأذكار النوم — آية الكرسي والمعوذات', _nextInstant(22, 30), _smartDetails);
    }
    if (prefs.getBool(smartWhite) ?? true) {
      final now = DateTime.now();
      for (var i = 0; i < 45; i++) {
        final tomorrow = DateTime(now.year, now.month, now.day + i + 1);
        final h = HijriDate.fromGregorian(tomorrow);
        // الأيام البيض 13 و14 و15 (نستثني رمضان وذي الحجة لأحكام خاصة بهما)
        if (h.day < 13 || h.day > 15 || h.month == 9 || h.month == 12) continue;
        final at = DateTime(now.year, now.month, now.day + i, 20, 0);
        if (!at.isAfter(now)) continue;
        await _schedule(
          400 + i,
          'غدًا من الأيام البيض',
          'يُستحب صيام الأيام البيض (13 و14 و15 من الشهر الهجري). التاريخ تقريبي فتأكد من رؤية الهلال.',
          tz.TZDateTime.from(at, tz.UTC),
          _smartDetails,
          match: null,
        );
      }
    }
  }
}
