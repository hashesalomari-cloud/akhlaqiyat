import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// إشعار يومي في وقت ثابت يذكّر المستخدم بإنجاز وِرده قبل أن تنطفئ
/// الشعلة. يحتاج إذن الإشعارات على أندرويد 13 فأعلى (يُطلب تلقائيًا
/// عند أول استدعاء لـ initialize عبر الإعدادات أدناه إن لزم لاحقًا).
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> initialize() async {
    if (_ready) return;
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
    _ready = true;
  }

  /// يطلب إذن الإشعارات صراحة على أندرويد 13+ (POST_NOTIFICATIONS)
  static Future<void> requestPermission() async {
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  /// يجدول تذكيرًا يوميًا متكررًا في الساعة والدقيقة المحددة (افتراضيًا
  /// 8:00 مساءً) — وقت مناسب قبل نهاية اليوم بوقت كافٍ لإنجاز الورد.
  static Future<void> scheduleDailyReminder({int hour = 20, int minute = 0}) async {
    await initialize();
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    await _plugin.zonedSchedule(
      100,
      'حافظ على شعلتك 🔥',
      'ما زال وقت كافٍ لإنجاز وِردك اليوم قبل أن تنطفئ الشعلة',
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_streak_reminder',
          'تذكير الشعلة اليومي',
          importance: Importance.defaultImportance,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time, // يتكرر كل يوم بنفس الوقت
    );
  }

  static Future<void> cancelDailyReminder() => _plugin.cancel(100);

  // معرّفات إشعارات الصلوات الخمس (ثابتة حتى يمكن إلغاؤها/استبدالها
  // بدقة كل يوم دون التأثير على التذكير اليومي رقم 100).
  static const _prayerIds = {
    'fajr': 201,
    'dhuhr': 202,
    'asr': 203,
    'maghrib': 204,
    'isha': 205,
  };

  static const _prayerLabels = {
    'fajr': 'الفجر',
    'dhuhr': 'الظهر',
    'asr': 'العصر',
    'maghrib': 'المغرب',
    'isha': 'العشاء',
  };

  /// يجدول إشعارًا لكل صلاة من صلوات اليوم المتبقية (الصلوات التي
  /// فات وقتها اليوم لا تُجدول). يُستدعى من شاشة الصلاة كل مرة تُحسب
  /// فيها المواقيت، فيبقى محدّثًا يوميًا طالما المستخدم يفتح التطبيق.
  ///
  /// ملاحظة: الصوت المستخدم هو صوت التنبيه الافتراضي القوي للنظام
  /// (أولوية قصوى)، وليس تسجيل أذان فعلي — تسجيلات الأذان بصوت مؤذّن
  /// معروف محمية غالبًا بحقوق نشر، فلا تُضاف دون إذن صريح. يمكن
  /// استبدالها بتسجيل أذان لو توفّر ملف صوتي لديك إذن لاستخدامه.
  static Future<void> schedulePrayerNotifications(Map<String, DateTime> times) async {
    await initialize();
    final now = tz.TZDateTime.now(tz.local);
    for (final entry in times.entries) {
      final id = _prayerIds[entry.key];
      final label = _prayerLabels[entry.key];
      if (id == null || label == null) continue;
      await _plugin.cancel(id);
      final t = entry.value;
      final scheduled = tz.TZDateTime(tz.local, t.year, t.month, t.day, t.hour, t.minute);
      if (scheduled.isBefore(now)) continue; // فات وقتها اليوم، تُجدول غدًا تلقائيًا عند الفتح القادم
      await _plugin.zonedSchedule(
        id,
        'حان الآن وقت صلاة $label 🕌',
        'اترك ما بيدك، وتوضأ، وقم للصلاة — جزاك الله خيرًا',
        scheduled,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_time_alerts',
            'تنبيه دخول وقت الصلاة',
            channelDescription: 'إشعار قوي عند دخول وقت كل صلاة',
            importance: Importance.max,
            priority: Priority.high,
            category: AndroidNotificationCategory.alarm,
            audioAttributesUsage: AudioAttributesUsage.alarm,
            playSound: true,
          ),
          iOS: DarwinNotificationDetails(interruptionLevel: InterruptionLevel.timeSensitive),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      );
    }
  }

  static Future<void> cancelPrayerNotifications() async {
    for (final id in _prayerIds.values) {
      await _plugin.cancel(id);
    }
  }
}
