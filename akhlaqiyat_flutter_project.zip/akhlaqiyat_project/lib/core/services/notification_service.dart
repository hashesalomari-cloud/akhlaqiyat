import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// إشعار يومي في وقت ثابت يذكّر المستخدم بإنجاز وِرده قبل أن تنطفئ
/// الشعلة. يحتاج إذن الإشعارات على أندرويد 13 فأعلى (يُطلب تلقائيًا
/// عند أول استدعاء لـ initialize عبر الإعدادات أدناه إن لزم لاحقًا).
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> initialize() async {
    if (_ready) return;
    tz_data.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings();
    await _plugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
    );
    _ready = true;
  }

  /// يطلب إذن الإشعارات صراحة على أندرويد 13+ (POST_NOTIFICATIONS)
  static Future<void> requestPermission() async {
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  /// يجدول تذكيرًا يوميًا متكررًا في الساعة والدقيقة المحددة (افتراضيًا
  /// 8:00 مساءً) — وقت مناسب قبل نهاية اليوم بوقت كافٍ لإنجاز الورد.
  static Future<void> scheduleDailyReminder({int hour = 20, int minute = 0}) async {
    await initialize();
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    await _plugin.zonedSchedule(
      100,
      'حافظ على شعلتك 🔥',
      'ما زال وقت كافٍ لإنجاز وِردك اليوم قبل أن تنطفئ الشعلة',
      scheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_streak_reminder',
          'تذكير الشعلة اليومي',
          importance: Importance.defaultImportance,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time, // يتكرر كل يوم بنفس الوقت
    );
  }

  static Future<void> cancelDailyReminder() => _plugin.cancel(100);
}
