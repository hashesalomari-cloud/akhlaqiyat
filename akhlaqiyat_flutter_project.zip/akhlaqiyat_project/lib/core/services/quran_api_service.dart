import 'package:dio/dio.dart';
import '../../features/quran/models/surah_model.dart';

// خدمة الاتصال بـ Quran.com API (v4) لضمان دقة النص والتفسير 100%.
// التوثيق الرسمي: https://api-docs.quran.foundation
// ملاحظة: هذا الـ API الجديد يتطلب تسجيل تطبيق والحصول على
// Client ID / Client Secret (OAuth2 client-credentials) — سجّل حسابًا
// على https://api-docs.quran.foundation قبل الإنتاج، وخزّن المفاتيح
// عبر flutter_dotenv أو --dart-define، ولا تكتبها مباشرة في الكود.

class QuranApiService {
  QuranApiService({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              baseUrl: 'https://api.quran.com/api/v4',
              connectTimeout: const Duration(seconds: 10),
              receiveTimeout: const Duration(seconds: 10),
            ));

  final Dio _dio;

  /// يجلب قائمة السور الـ 114 مع بيانات أساسية (اسم، عدد آيات، مكان النزول)
  Future<List<Surah>> getSurahList() async {
    try {
      final response = await _dio.get('/chapters', queryParameters: {
        'language': 'ar',
      });
      final List data = response.data['chapters'] as List;
      return data.map((e) => Surah.fromJson(e as Map<String, dynamic>)).toList();
    } on DioException catch (e) {
      throw QuranApiException('تعذّر تحميل قائمة السور: ${e.message}');
    }
  }

  /// يجلب آيات سورة معينة بالرسم العثماني، مع رابط الصوت لقارئ محدد اختياريًا
  Future<List<Ayah>> getSurahVerses(int surahNumber, {int? reciterId}) async {
    try {
      final response = await _dio.get('/verses/by_chapter/$surahNumber', queryParameters: {
        'language': 'ar',
        'fields': 'text_uthmani',
        if (reciterId != null) 'audio': reciterId,
        'per_page': 300, // أطول سورة (البقرة) 286 آية
      });
      final List data = response.data['verses'] as List;
      return data.map((e) => Ayah.fromJson(e as Map<String, dynamic>)).toList();
    } on DioException catch (e) {
      throw QuranApiException('تعذّر تحميل آيات السورة: ${e.message}');
    }
  }

  /// يجلب تفسير آية معينة من تفسير محدد (افتراضيًا: تفسير السعدي، مناسب ومختصر)
  /// معرّفات التفاسير المتاحة تُسحب من /resources/tafsirs
  Future<Tafsir> getAyahTafsir(String verseKey, {int tafsirResourceId = 91}) async {
    try {
      final response = await _dio.get('/tafsirs/$tafsirResourceId/by_ayah/$verseKey');
      final data = response.data['tafsir'] as Map<String, dynamic>;
      return Tafsir(
        resourceName: data['resource_name'] as String? ?? 'تفسير',
        text: (data['text'] as String).replaceAll(RegExp(r'<[^>]*>'), ''), // إزالة HTML tags
      );
    } on DioException catch (e) {
      throw QuranApiException('تعذّر تحميل التفسير: ${e.message}');
    }
  }

  /// يجلب قائمة القراء المتاحين للتلاوة والترديد
  Future<List<Reciter>> getReciters() async {
    try {
      final response = await _dio.get('/resources/recitations', queryParameters: {
        'language': 'ar',
      });
      final List data = response.data['recitations'] as List;
      return data.map((e) => Reciter.fromJson(e as Map<String, dynamic>)).toList();
    } on DioException catch (e) {
      throw QuranApiException('تعذّر تحميل قائمة القراء: ${e.message}');
    }
  }
}

class QuranApiException implements Exception {
  final String message;
  QuranApiException(this.message);
  @override
  String toString() => message;
}
