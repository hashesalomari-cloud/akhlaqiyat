import 'package:dio/dio.dart';
import '../../features/quran/models/surah_model.dart';

/// خدمة القرآن — تستخدم islamic.app: خدمة مجانية بالكامل وبدون أي
/// تسجيل أو مفتاح API (تحققتُ من هذا في توثيقها الرسمي، سبتمبر 2026).
/// كانت تعتمد سابقًا على api.quran.com الذي أوقفته الشركة المالكة
/// واستبدلته بنظام OAuth2 يتطلب تسجيلاً؛ لذلك بدّلناها لهذا المصدر
/// البديل الذي يعمل فورًا. توثيق islamic.app: https://docs.islamic.app
///
/// تجلب هذه الخدمة نص الآية والتفسير (تفسير السعدي) في طلب واحد فقط،
/// بدل طلب منفصل لكل آية كما كان سابقًا — أسرع وأقل استهلاكًا للبيانات.
class QuranApiService {
  QuranApiService({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              baseUrl: 'https://api.islamic.app/v1',
              connectTimeout: const Duration(seconds: 10),
              receiveTimeout: const Duration(seconds: 15),
            ));

  final Dio _dio;
  static const _reciter = 'ar.alafasy'; // مشاري العفاسي
  static const _tafsirSlug = 'ar-tafseer-al-saddi'; // تفسير السعدي

  /// رابط تلاوة الآية (رابط ثابت من الـ CDN، لا يحتاج طلب إضافي)
  static String audioUrlForGlobalAyah(int globalAyahId) =>
      'https://cdn.islamic.app/quran/audio/$_reciter/$globalAyahId.mp3';

  /// يجلب آيات سورة كاملة، مع نص التفسير مرفقًا مباشرة مع كل آية
  Future<List<Ayah>> getSurahVerses(int surahNumber) async {
    try {
      final response = await _dio.get('/verses/by_chapter/$surahNumber', queryParameters: {
        'fields': 'text_uthmani',
        'tafsirs': _tafsirSlug,
      });
      final body = response.data as Map<String, dynamic>;
      final versesJson = (body['data']?['verses'] ?? body['verses']) as List;
      return versesJson.map((e) => Ayah.fromJson(e as Map<String, dynamic>)).toList();
    } on DioException catch (e) {
      throw QuranApiException('تعذّر تحميل السورة: ${e.message}');
    }
  }
}

class QuranApiException implements Exception {
  final String message;
  QuranApiException(this.message);
  @override
  String toString() => message;
}
