import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;

import '../../features/azkar/models/azkar_model.dart';
import '../../features/hadith/models/hadith_model.dart';
import '../../features/quran/models/surah_model.dart';

/// يقرأ المحتوى الديني المحلي من assets/data/*.json (يعمل بدون إنترنت).
class LocalDataService {
  static Future<dynamic> _json(String name) async =>
      jsonDecode(await rootBundle.loadString('assets/data/$name'));

  static Future<List<Surah>> surahs() async {
    final list = await _json('surahs.json') as List;
    return list
        .map((e) => Surah(
              number: e['n'] as int,
              nameArabic: e['ar'] as String,
              nameEnglish: '',
              revelationPlace: '',
              versesCount: e['v'] as int,
            ))
        .toList();
  }

  static Future<List<HadithCollection>> hadithCollections() async {
    final data = await _json('hadiths.json') as Map<String, dynamic>;
    return (data['collections'] as List).map((c) {
      final hadiths = (c['hadiths'] as List)
          .map((h) => Hadith(
                hadithNumber: h['n'] as int,
                bookName: h['book'] as String,
                arabicText: h['text'] as String,
                meaning: h['meaning'] as String? ?? '',
                narrator: h['narrator'] as String,
                reference: h['ref'] as String,
                grade: h['grade'] == 'sahih'
                    ? HadithGrade.sahih
                    : h['grade'] == 'hasan'
                        ? HadithGrade.hasan
                        : HadithGrade.unknown,
              ))
          .toList();
      return HadithCollection(
        slug: c['slug'] as String,
        nameArabic: c['name'] as String,
        totalHadiths: hadiths.length,
        hadiths: hadiths,
      );
    }).toList();
  }

  static Future<List<Dhikr>> azkarFor(String categoryId) async {
    final data = await _json('azkar.json') as Map<String, dynamic>;
    final list = (data[categoryId] as List?) ?? const [];
    return list
        .map((d) => Dhikr(
              text: d['text'] as String,
              targetCount: d['count'] as int,
              virtue: d['virtue'] as String?,
              source: d['source'] as String,
            ))
        .toList();
  }

  static int _dayIndex() => DateTime.now().difference(DateTime(2026, 1, 1)).inDays;

  /// آية اليوم (تتغير يوميًا)
  static Future<Map<String, dynamic>> dailyAyah() async {
    final data = await _json('ayat.json') as Map<String, dynamic>;
    final list = data['ayat'] as List;
    return Map<String, dynamic>.from(list[_dayIndex().abs() % list.length] as Map);
  }

  /// حديث اليوم (يتغير يوميًا)
  static Future<Hadith> dailyHadith() async {
    final cols = await hadithCollections();
    final all = cols.expand((c) => c.hadiths).toList();
    return all[_dayIndex().abs() % all.length];
  }
}
