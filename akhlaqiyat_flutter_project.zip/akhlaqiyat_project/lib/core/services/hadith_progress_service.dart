import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// يتتبّع "تحدي حفظ حديث اليوم": عدد الأحاديث التي أنهى المستخدم
/// حفظها إجمالًا (عدّاد تراكمي)، وهل أنجز حديث اليوم فعلًا — حتى تُظهر
/// الواجهة الزر بشكل مختلف بعد الإنجاز بدل السماح بتكراره.
class HadithProgressService {
  static const _kTotal = 'hadith_memorized_total';
  static const _kLastDate = 'hadith_memorized_last_date';

  static final ValueNotifier<int> version = ValueNotifier(0);

  static String _today() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  /// (إجمالي ما حُفظ، هل أُنجز حديث اليوم؟)
  static Future<(int, bool)> load() async {
    final prefs = await SharedPreferences.getInstance();
    final total = prefs.getInt(_kTotal) ?? 0;
    final last = prefs.getString(_kLastDate);
    return (total, last == _today());
  }

  static Future<int> markTodayMemorized() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _today();
    final last = prefs.getString(_kLastDate);
    if (last == today) {
      return prefs.getInt(_kTotal) ?? 0; // أُنجز مسبقًا اليوم
    }
    final newTotal = (prefs.getInt(_kTotal) ?? 0) + 1;
    await prefs.setInt(_kTotal, newTotal);
    await prefs.setString(_kLastDate, today);
    version.value++;
    return newTotal;
  }
}
