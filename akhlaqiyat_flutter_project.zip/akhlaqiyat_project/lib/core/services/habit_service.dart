import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'streak_service.dart';

/// متتبع العبادات والأخلاق اليومي. كل عادة منجزة تُحسب نقطة نمو
/// تراكمية لشجرة الأخلاق (لا تنقص عند تغيّر اليوم).
class Habit {
  final String id, title, icon; // icon اسم رمز بسيط تحوّله الواجهة
  const Habit(this.id, this.title, this.icon);
}

class HabitService {
  static const habits = <Habit>[
    Habit('fajr', 'صلاة الفجر', 'prayer'),
    Habit('dhuhr', 'صلاة الظهر', 'prayer'),
    Habit('asr', 'صلاة العصر', 'prayer'),
    Habit('maghrib', 'صلاة المغرب', 'prayer'),
    Habit('isha', 'صلاة العشاء', 'prayer'),
    Habit('azkar_morning', 'أذكار الصباح', 'sun'),
    Habit('azkar_evening', 'أذكار المساء', 'moon'),
    Habit('quran', 'ورد القرآن', 'book'),
    Habit('ethic', 'تحدي الخُلق اليومي', 'heart'),
  ];

  /// يتغيّر عند أي تعديل ليحدّث الشاشات المستمعة
  static final ValueNotifier<int> version = ValueNotifier(0);

  static const _kPoints = 'habit_points_total';

  static String keyFor(DateTime d) =>
      'habits_${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static Future<Set<String>> doneOn(DateTime d) async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(keyFor(d)) ?? const <String>[]).toSet();
  }

  static Future<Set<String>> doneToday() => doneOn(DateTime.now());

  static Future<int> points() async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_kPoints) ?? 0;
  }

  /// يضبط حالة عادة اليوم (إنجاز / إلغاء) ويحدّث النقاط والشعلة.
  static Future<void> set(String id, bool done) async {
    final p = await SharedPreferences.getInstance();
    final key = keyFor(DateTime.now());
    final cur = (p.getStringList(key) ?? const <String>[]).toSet();
    final had = cur.contains(id);
    if (done == had) return;
    if (done) {
      cur.add(id);
    } else {
      cur.remove(id);
    }
    await p.setStringList(key, cur.toList());
    final pts = (p.getInt(_kPoints) ?? 0) + (done ? 1 : -1);
    await p.setInt(_kPoints, pts < 0 ? 0 : pts);
    if (done) await StreakService.checkIn();
    version.value++;
  }

  /// للاستدعاء التلقائي من أماكن أخرى (إتمام أذكار، تحدي الخُلق...)
  static Future<void> mark(String id) => set(id, true);

  /// مراحل الشجرة بحسب النقاط التراكمية: (الحد الأدنى للنقاط، الاسم)
  static const stages = <(int, String)>[
    (0, 'بذرة'),
    (4, 'برعم صغير'),
    (14, 'شتلة'),
    (34, 'شجرة فتيّة'),
    (70, 'شجرة مورقة'),
    (120, 'شجرة مزهرة'),
    (200, 'شجرة مثمرة'),
  ];

  static int stageFor(int points) {
    var s = 0;
    for (var i = 0; i < stages.length; i++) {
      if (points >= stages[i].$1) s = i;
    }
    return s;
  }

  /// إنجازات آخر [days] يومًا (الأحدث أولًا): عدد العادات المنجزة كل يوم
  static Future<List<int>> lastDays(int days) async {
    final p = await SharedPreferences.getInstance();
    final now = DateTime.now();
    return [
      for (var i = 0; i < days; i++)
        (p.getStringList(keyFor(DateTime(now.year, now.month, now.day - i))) ?? const <String>[]).length
    ];
  }
}
