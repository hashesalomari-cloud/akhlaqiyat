import 'dart:convert';
import 'package:dio/dio.dart';

/// مقطع صوتي من تفسير مسجّل بصوت بشري (مكتبة mp3quran.net المجانية).
/// كل مقطع يغطي نطاقًا من آيات سورة معيّنة (أو السورة كاملة).
class TafsirAudioSegment {
  final int surah;
  final int startAyah;
  final int endAyah;
  final String url;
  final String title;
  const TafsirAudioSegment({
    required this.surah,
    required this.startAyah,
    required this.endAyah,
    required this.url,
    required this.title,
  });

  bool covers(int surahNumber, int ayah) =>
      surah == surahNumber && ayah >= startAyah && ayah <= endAyah;
}

/// يجلب فهرس التفسير المسموع من mp3quran.net ويحدّد المقطع الذي يغطي
/// آية معيّنة.
///
/// تنبيه مهم: التسجيل المتاح هنا هو "الخلاصة من تفسير الطبري" وليس
/// تفسير السعدي المعروض نصًّا في التطبيق؛ لذلك تُعرض التسمية بوضوح في
/// الواجهة حتى لا يُظنّ أنه قراءة لنفس النص.
class TafsirAudioService {
  static const _endpoint = 'https://mp3quran.net/api/v3/tafsir?language=ar';
  static const collectionName = 'الخلاصة من تفسير الطبري';

  static List<TafsirAudioSegment>? _cache;

  static final _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 15),
  ));

  // مثال للروابط: .../tabri/001.mp3 (سورة كاملة) و .../tabri/002-1-25.mp3 (آيات 1-25)
  static final _fileRe = RegExp(r'/(\d{3})(?:-(\d+)-(\d+))?\.mp3$');

  static Future<List<TafsirAudioSegment>> _load() async {
    final cached = _cache;
    if (cached != null) return cached;
    final res = await _dio.get(_endpoint);
    final raw = res.data;
    final body = raw is String ? jsonDecode(raw) : raw;
    final soar = (body['tafasir']['soar'] as List);
    final out = <TafsirAudioSegment>[];
    for (final e in soar) {
      final url = (e['url'] ?? '').toString();
      final m = _fileRe.firstMatch(url);
      if (m == null) continue;
      final surah = int.tryParse(m.group(1)!) ?? int.tryParse('${e['sura_id']}');
      if (surah == null) continue;
      final start = m.group(2) != null ? int.parse(m.group(2)!) : 1;
      final end = m.group(3) != null ? int.parse(m.group(3)!) : 9999;
      out.add(TafsirAudioSegment(
        surah: surah,
        startAyah: start,
        endAyah: end,
        url: url,
        title: (e['name'] ?? '').toString(),
      ));
    }
    _cache = out;
    return out;
  }

  /// المقطع الذي يغطي الآية، أو null إن لم يوجد تسجيل لها.
  static Future<TafsirAudioSegment?> segmentFor(int surah, int ayah) async {
    final all = await _load();
    for (final s in all) {
      if (s.covers(surah, ayah)) return s;
    }
    return null;
  }
}
