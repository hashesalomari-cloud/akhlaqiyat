/// تحويل ميلادي ← هجري بالخوارزمية الجدولية (تقريبي ±1 يوم عن الرؤية
/// الفعلية). نستخدمه للتذكير بالأيام البيض فقط، ويُذكر ذلك للمستخدم.
class HijriDate {
  final int year, month, day;
  const HijriDate(this.year, this.month, this.day);

  static HijriDate fromGregorian(DateTime d) {
    // يوم جولياني
    final y = d.year, m = d.month, dd = d.day;
    final a = ((14 - m) / 12).floor();
    final yy = y + 4800 - a;
    final mm = m + 12 * a - 3;
    final jd = dd + ((153 * mm + 2) / 5).floor() + 365 * yy + (yy / 4).floor() - (yy / 100).floor() +
        (yy / 400).floor() - 32045;
    // تحويل الجولياني إلى هجري (جدولي)
    final l = jd - 1948440 + 10632;
    final n = ((l - 1) / 10631).floor();
    final l2 = l - 10631 * n + 354;
    final j = (((10985 - l2) / 5316).floor()) * (((50 * l2) / 17719).floor()) +
        ((l2 / 5670).floor()) * (((43 * l2) / 15238).floor());
    final l3 = l2 - (((30 - j) / 15).floor()) * (((17719 * j) / 50).floor()) -
        ((j / 16).floor()) * (((15238 * j) / 43).floor()) + 29;
    final month = ((24 * l3) / 709).floor();
    final day = l3 - ((709 * month) / 24).floor();
    final year = 30 * n + j - 30;
    return HijriDate(year, month, day);
  }
}
