import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// خدمة الشعلة — تحفظ عدد الأيام المتتالية فعليًا على الجهاز عبر
/// SharedPreferences (يبقى بعد إغلاق التطبيق، بخلاف الحالة المؤقتة
/// اللي كانت مستخدمة سابقًا في الواجهة فقط).
///
/// منطق العدّ: لو آخر إنجاز كان "أمس" يزيد العداد، ولو انقطع يوم أو
/// أكثر يرجع العداد لـ1 عند أول إنجاز جديد. إنجاز واحد فقط باليوم
/// يُحتسب، فتكرار استدعاء checkIn() في نفس اليوم لا يزيد العداد.
class StreakService {
  static const _kCount = 'streak_count';
  static const _kLastDate = 'streak_last_date';

  /// يتغيّر كل مرة يتحدّث فيها العداد، حتى تقدر أي شاشة (مثل الرئيسية)
  /// تستمع له وتحدّث نفسها فورًا حتى لو الإنجاز صار من شاشة أخرى
  /// (الأذكار أو تحدي الخُلق) بدون إعادة فتح التبويب يدويًا.
  static final ValueNotifier<int> version = ValueNotifier(0);

  static String _today() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  static String _yesterday() {
    final n = DateTime.now().subtract(const Duration(days: 1));
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  /// يحمّل الحالة الحالية: (العدد، هل أُنجز اليوم؟)
  static Future<(int, bool)> load() async {
    final prefs = await SharedPreferences.getInstance();
    final count = prefs.getInt(_kCount) ?? 0;
    final last = prefs.getString(_kLastDate);
    return (count, last == _today());
  }

  /// يسجّل إنجاز اليوم. آمن الاستدعاء عدة مرات — لا يزيد العداد إلا
  /// أول مرة في اليوم. يُستخدم من: زر "أنجزت وردي"، إتمام قسم أذكار
  /// كامل، أو تطبيق تحدي الخُلق اليومي — أي واحد منها يكفي لإشعال
  /// الشعلة، فلا داعي لتكرار كل الأنشطة في نفس اليوم.
  static Future<(int, bool)> checkIn() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _today();
    final last = prefs.getString(_kLastDate);
    if (last == today) {
      return (prefs.getInt(_kCount) ?? 1, true); // إنجاز مكرر بنفس اليوم
    }
    final wasYesterday = last == _yesterday();
    final newCount = wasYesterday ? (prefs.getInt(_kCount) ?? 0) + 1 : 1;
    await prefs.setInt(_kCount, newCount);
    await prefs.setString(_kLastDate, today);
    version.value++;
    return (newCount, true);
  }
}
