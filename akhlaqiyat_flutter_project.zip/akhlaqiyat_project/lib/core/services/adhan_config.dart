/// يُضبط تلقائيًا على true أثناء البناء إذا وُجد ملف الأذان في
/// android_res/raw/adhan.mp3 (أو .ogg/.wav) — انظر tool/prepare_android.sh.
const bool kHasAdhanAsset = false;
