import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PrayerTimesResult {
  final DateTime fajr, sunrise, dhuhr, asr, maghrib, isha;
  final double qiblaDegrees;
  final bool isFallbackLocation;
  final String? cityName;
  const PrayerTimesResult({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
    required this.qiblaDegrees,
    required this.isFallbackLocation,
    this.cityName,
  });

  /// فجر الغد (تقريبي: فجر اليوم + يوم) لعرض "الصلاة القادمة" بعد العشاء.
  DateTime get tomorrowFajr => fajr.add(const Duration(days: 1));
}

class PrayerCity {
  final String name;
  final double lat, lng;
  const PrayerCity(this.name, this.lat, this.lng);
}

/// مدن جاهزة للاختيار اليدوي (إن لم يُرد المستخدم استخدام GPS).
const prayerCities = <PrayerCity>[
  PrayerCity('عمّان', 31.9454, 35.9284),
  PrayerCity('القدس', 31.7683, 35.2137),
  PrayerCity('دمشق', 33.5138, 36.2765),
  PrayerCity('بيروت', 33.8938, 35.5018),
  PrayerCity('بغداد', 33.3152, 44.3661),
  PrayerCity('القاهرة', 30.0444, 31.2357),
  PrayerCity('مكة المكرمة', 21.4225, 39.8262),
  PrayerCity('المدينة المنورة', 24.4672, 39.6111),
  PrayerCity('جدة', 21.4858, 39.1925),
  PrayerCity('الرياض', 24.7136, 46.6753),
  PrayerCity('الكويت', 29.3759, 47.9774),
  PrayerCity('الدوحة', 25.2854, 51.5310),
  PrayerCity('دبي', 25.2048, 55.2708),
  PrayerCity('مسقط', 23.5880, 58.3829),
  PrayerCity('صنعاء', 15.3694, 44.1910),
  PrayerCity('الخرطوم', 15.5007, 32.5599),
  PrayerCity('طرابلس (ليبيا)', 32.8872, 13.1913),
  PrayerCity('تونس', 36.8065, 10.1815),
  PrayerCity('الجزائر', 36.7538, 3.0588),
  PrayerCity('الدار البيضاء', 33.5731, -7.5898),
  PrayerCity('إسطنبول', 41.0082, 28.9784),
  PrayerCity('لندن', 51.5072, -0.1276),
  PrayerCity('نيويورك', 40.7128, -74.0060),
];

/// طرق الحساب المتاحة (المعرّف المحفوظ → الاسم المعروض).
const prayerMethods = <String, String>{
  'muslim_world_league': 'رابطة العالم الإسلامي',
  'egyptian': 'الهيئة المصرية العامة للمساحة',
  'umm_al_qura': 'أم القرى (مكة)',
  'karachi': 'جامعة العلوم الإسلامية - كراتشي',
  'north_america': 'أمريكا الشمالية (ISNA)',
};

class PrayerSettings {
  static const kMethod = 'prayer_method';
  static const kMadhab = 'prayer_madhab'; // shafi | hanafi
  static const kCity = 'prayer_city'; // -1 = GPS، وإلا فهرس المدينة
  static const kAlerts = 'prayer_alerts_enabled';
  static const kLastLat = 'prayer_last_lat';
  static const kLastLng = 'prayer_last_lng';
}

/// حساب المواقيت محليًا بمكتبة adhan بدون إنترنت.
class PrayerTimeService {
  static const _meccaLat = 21.4225;
  static const _meccaLng = 39.8262;

  Future<PrayerTimesResult> loadForCurrentLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final cityIdx = prefs.getInt(PrayerSettings.kCity) ?? -1;
    if (cityIdx >= 0 && cityIdx < prayerCities.length) {
      final c = prayerCities[cityIdx];
      return calculate(c.lat, c.lng, false, prefs: prefs, cityName: c.name);
    }

    double? lat, lng;
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (enabled &&
          perm != LocationPermission.denied &&
          perm != LocationPermission.deniedForever) {
        try {
          final pos = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.low,
              timeLimit: Duration(seconds: 12),
            ),
          );
          lat = pos.latitude;
          lng = pos.longitude;
        } catch (_) {
          final last = await Geolocator.getLastKnownPosition();
          if (last != null) {
            lat = last.latitude;
            lng = last.longitude;
          }
        }
      }
    } catch (_) {}

    if (lat != null && lng != null) {
      await prefs.setDouble(PrayerSettings.kLastLat, lat);
      await prefs.setDouble(PrayerSettings.kLastLng, lng);
      return calculate(lat, lng, false, prefs: prefs);
    }
    // آخر موقع ناجح محفوظ (أفضل من مكة لمن لديه GPS متقطع)
    final sl = prefs.getDouble(PrayerSettings.kLastLat);
    final sg = prefs.getDouble(PrayerSettings.kLastLng);
    if (sl != null && sg != null) {
      return calculate(sl, sg, false, prefs: prefs, cityName: 'آخر موقع معروف');
    }
    return calculate(_meccaLat, _meccaLng, true, prefs: prefs);
  }

  static CalculationParameters _params(SharedPreferences prefs) {
    final m = prefs.getString(PrayerSettings.kMethod) ?? 'muslim_world_league';
    final CalculationParameters p;
    switch (m) {
      case 'egyptian':
        p = CalculationMethod.egyptian.getParameters();
        break;
      case 'umm_al_qura':
        p = CalculationMethod.umm_al_qura.getParameters();
        break;
      case 'karachi':
        p = CalculationMethod.karachi.getParameters();
        break;
      case 'north_america':
        p = CalculationMethod.north_america.getParameters();
        break;
      default:
        p = CalculationMethod.muslim_world_league.getParameters();
    }
    p.madhab = (prefs.getString(PrayerSettings.kMadhab) ?? 'shafi') == 'hanafi'
        ? Madhab.hanafi
        : Madhab.shafi;
    return p;
  }

  PrayerTimesResult calculate(double lat, double lng, bool fallback,
      {required SharedPreferences prefs, String? cityName}) {
    final coords = Coordinates(lat, lng);
    final pt = PrayerTimes.today(coords, _params(prefs));
    final fix = _Normalizer(pt.dhuhr, lng);
    return PrayerTimesResult(
      fajr: fix(pt.fajr),
      sunrise: fix(pt.sunrise),
      dhuhr: fix(pt.dhuhr),
      asr: fix(pt.asr),
      maghrib: fix(pt.maghrib),
      isha: fix(pt.isha),
      qiblaDegrees: Qibla(coords).direction,
      isFallbackLocation: fallback,
      cityName: cityName,
    );
  }
}

/// مكتبة adhan قد تُرجع أوقاتًا بتوقيت UTC أو بتوقيت الجهاز حسب الإصدار.
/// نكشف ذلك بمقارنة وقت الظهر مع الظهر الفلكي المتوقع لخط الطول، ثم نحوّل
/// كل الأوقات إلى توقيت الجهاز المحلي الصحيح.
class _Normalizer {
  final bool _componentsAreLocal;
  _Normalizer(DateTime dhuhr, double lng) : _componentsAreLocal = _detect(dhuhr, lng);

  static double _circ(double d) {
    var x = d % 24;
    if (x > 12) x -= 24;
    return x;
  }

  static bool _detect(DateTime dhuhr, double lng) {
    final expectedUtc = 12 - lng / 15; // الظهر الفلكي بالتقريب (±15 دقيقة)
    final offset = DateTime.now().timeZoneOffset.inMinutes / 60.0;
    final u = dhuhr.toUtc();
    final utcH = u.hour + u.minute / 60.0;
    final rawH = dhuhr.hour + dhuhr.minute / 60.0;
    final dA = _circ(utcH - expectedUtc).abs(); // الوقت لحظة حقيقية
    final dB = _circ(rawH - (expectedUtc + offset)).abs(); // مكوّنات محلية
    return dB < dA;
  }

  DateTime call(DateTime t) => _componentsAreLocal
      ? DateTime(t.year, t.month, t.day, t.hour, t.minute)
      : t.toLocal();
}
