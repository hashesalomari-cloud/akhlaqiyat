import 'package:adhan/adhan.dart';
import 'package:geolocator/geolocator.dart';

class PrayerTimesResult {
  final DateTime fajr, sunrise, dhuhr, asr, maghrib, isha;
  final double qiblaDegrees;
  final bool isFallbackLocation;
  const PrayerTimesResult({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
    required this.qiblaDegrees,
    required this.isFallbackLocation,
  });
}

/// حساب المواقيت محليًا بمكتبة adhan (خوارزميات Meeus) — طريقة رابطة العالم الإسلامي.
class PrayerTimeService {
  // مكة المكرمة — تُستخدم إن تعذّر تحديد الموقع
  static const _meccaLat = 21.4225;
  static const _meccaLng = 39.8262;

  Future<PrayerTimesResult> loadForCurrentLocation() async {
    double lat = _meccaLat, lng = _meccaLng;
    var fallback = true;
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (enabled &&
          perm != LocationPermission.denied &&
          perm != LocationPermission.deniedForever) {
        final pos = await Geolocator.getCurrentPosition();
        lat = pos.latitude;
        lng = pos.longitude;
        fallback = false;
      }
    } catch (_) {}
    return calculate(lat, lng, fallback);
  }

  PrayerTimesResult calculate(double lat, double lng, bool fallback) {
    final coords = Coordinates(lat, lng);
    final params = CalculationMethod.muslim_world_league.getParameters();
    final pt = PrayerTimes.today(coords, params);
    return PrayerTimesResult(
      fajr: pt.fajr,
      sunrise: pt.sunrise,
      dhuhr: pt.dhuhr,
      asr: pt.asr,
      maghrib: pt.maghrib,
      isha: pt.isha,
      qiblaDegrees: Qibla(coords).direction,
      isFallbackLocation: fallback,
    );
  }
}
