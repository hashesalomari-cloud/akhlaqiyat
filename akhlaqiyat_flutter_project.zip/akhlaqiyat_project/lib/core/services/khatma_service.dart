import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../features/quran/models/surah_model.dart';
import 'habit_service.dart';

/// موضع في المصحف: سورة + آية.
class QuranPos {
  final int surah, ayah;
  const QuranPos(this.surah, this.ayah);
}

/// خطة ختمة: نقسّم آيات المصحف (٦٢٣٦) على عدد الأيام المختار، ويُحسب ورد
/// اليوم من عدد الآيات (لا من الصفحات، فلا نعتمد على ترقيم مصحف معيّن).
class KhatmaService {
  static const _kStart = 'khatma_start';
  static const _kDays = 'khatma_days';
  static const _kDone = 'khatma_done'; // عدد الآيات المقروءة من بداية المصحف
  static final ValueNotifier<int> version = ValueNotifier(0);

  static List<Surah> _surahs = const [];
  static int total = 0;

  static void init(List<Surah> surahs) {
    _surahs = surahs;
    total = surahs.fold(0, (a, s) => a + s.versesCount);
  }

  /// يحوّل فهرسًا مطلقًا (١..المجموع) إلى سورة وآية.
  static QuranPos posOf(int index) {
    var left = index.clamp(1, total);
    for (final s in _surahs) {
      if (left <= s.versesCount) return QuranPos(s.number, left);
      left -= s.versesCount;
    }
    final last = _surahs.last;
    return QuranPos(last.number, last.versesCount);
  }

  static String nameOf(int surah) =>
      _surahs.firstWhere((s) => s.number == surah).nameArabic;

  static Future<KhatmaPlan?> load() async {
    final p = await SharedPreferences.getInstance();
    final start = p.getString(_kStart);
    final days = p.getInt(_kDays);
    if (start == null || days == null) return null;
    final d = DateTime.tryParse(start);
    if (d == null) return null;
    return KhatmaPlan(d, days, p.getInt(_kDone) ?? 0);
  }

  static Future<void> start(int days) async {
    final p = await SharedPreferences.getInstance();
    final n = DateTime.now();
    await p.setString(_kStart, DateTime(n.year, n.month, n.day).toIso8601String());
    await p.setInt(_kDays, days);
    await p.setInt(_kDone, 0);
    version.value++;
  }

  static Future<void> reset() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kStart);
    await p.remove(_kDays);
    await p.remove(_kDone);
    version.value++;
  }

  /// يسجّل إتمام ورد اليوم (يصل بالتقدم إلى نهاية حصة اليوم).
  static Future<void> completeToday() async {
    final plan = await load();
    if (plan == null) return;
    final p = await SharedPreferences.getInstance();
    final target = plan.todayEnd;
    if (target > plan.done) await p.setInt(_kDone, target);
    await HabitService.mark('quran');
    version.value++;
  }
}

class KhatmaPlan {
  final DateTime start;
  final int days;
  final int done;
  const KhatmaPlan(this.start, this.days, this.done);

  int get total => KhatmaService.total;

  /// رقم اليوم الحالي في الخطة (١ فما فوق، ولا يتجاوز عدد الأيام)
  int get dayNumber {
    final n = DateTime.now();
    final d = DateTime(n.year, n.month, n.day).difference(start).inDays + 1;
    return d.clamp(1, days);
  }

  /// نهاية حصة اليوم (فهرس مطلق): نسبة اليوم من المجموع
  int get todayEnd => (total * dayNumber / days).ceil().clamp(0, total);

  bool get finished => done >= total;
  bool get todayDone => done >= todayEnd;
  double get progress => total == 0 ? 0 : done / total;

  /// الآيات المتبقية من ورد اليوم (تشمل ما فات إن تأخرت)
  int get todayAyat => (todayEnd - done).clamp(0, total);
  int get behindDays {
    if (todayDone) return 0;
    final perDay = total / days;
    return ((todayEnd - done) / perDay).floor();
  }
}
