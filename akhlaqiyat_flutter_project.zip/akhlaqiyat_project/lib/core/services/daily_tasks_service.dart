import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'hadith_progress_service.dart';
import 'streak_service.dart';

/// المهام اليومية الثلاث.
enum DailyTask { ayah, ethic, hadith }

/// آية مقترحة للحفظ: السورة ونطاق الآيات ومعنى مبسّط. نص الآية والتفسير
/// يُجلبان من المصدر وقت العرض.
class MemorizeAyah {
  final int surah;
  final int from;
  final int to;
  final String meaning;
  final String text; // النص المضمّن في التطبيق (يعمل بدون إنترنت)
  const MemorizeAyah({
    required this.surah,
    required this.from,
    required this.to,
    required this.meaning,
    this.text = '',
  });
}

/// حالة مهام اليوم: كل مهمة تُنجَز مرة واحدة باليوم، وإنجاز أي منها
/// يُشعل الشعلة العامة. مهمة الحديث تشترك مع عدّاد حفظ الأحاديث
/// الموجود (زر "حفظته" بالرئيسية وشاشة الحديث) فلا تتكرر.
class DailyTasksService {
  /// يتغيّر عند إنجاز أي مهمة ليحدّث الشاشات المستمعة نفسها.
  static final ValueNotifier<int> version = ValueNotifier(0);

  static String _key(DailyTask t) => 'daily_task_${t.name}_date';

  static String _today() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  static int _dayIndex() => DateTime.now().difference(DateTime(2026, 1, 1)).inDays.abs();

  static Future<Map<DailyTask, bool>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _today();
    final (_, hadithDone) = await HadithProgressService.load();
    return {
      DailyTask.ayah: prefs.getString(_key(DailyTask.ayah)) == today,
      DailyTask.ethic: prefs.getString(_key(DailyTask.ethic)) == today,
      DailyTask.hadith: hadithDone,
    };
  }

  static Future<void> complete(DailyTask task) async {
    if (task == DailyTask.hadith) {
      await HadithProgressService.markTodayMemorized();
    } else {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key(task), _today());
    }
    await StreakService.checkIn();
    version.value++;
  }

  /// آية اليوم للحفظ (تتغير يوميًا).
  static Future<MemorizeAyah> todaysAyah() async {
    final raw = await rootBundle.loadString('assets/data/memorize_ayat.json');
    final list = (jsonDecode(raw) as Map<String, dynamic>)['ayat'] as List;
    final e = list[_dayIndex() % list.length] as Map<String, dynamic>;
    return MemorizeAyah(
      surah: e['s'] as int,
      from: e['f'] as int,
      to: e['t'] as int,
      meaning: e['meaning'] as String,
      text: (e['text'] as String?) ?? '',
    );
  }
}
