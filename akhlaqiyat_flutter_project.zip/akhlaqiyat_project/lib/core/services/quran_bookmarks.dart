import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// علامة مرجعية أو موضع قراءة: سورة + آية (+ اسم السورة للعرض).
class QuranMark {
  final int surah, ayah;
  final String surahName;
  const QuranMark(this.surah, this.ayah, this.surahName);

  Map<String, Object> toJson() => {'s': surah, 'a': ayah, 'n': surahName};
  factory QuranMark.fromJson(Map<String, dynamic> j) =>
      QuranMark(j['s'] as int, j['a'] as int, j['n'] as String);

  String get key => '$surah:$ayah';
}

/// «واصل القراءة» + العلامات المرجعية (محليًا على الجهاز).
class QuranBookmarks {
  static const _kLast = 'quran_last_read';
  static const _kMarks = 'quran_bookmarks';

  static final ValueNotifier<int> version = ValueNotifier(0);

  static Future<QuranMark?> lastRead() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_kLast);
    if (raw == null) return null;
    try {
      return QuranMark.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveLastRead(QuranMark m) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kLast, jsonEncode(m.toJson()));
    version.value++;
  }

  static Future<List<QuranMark>> all() async {
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList(_kMarks) ?? const <String>[];
    final out = <QuranMark>[];
    for (final s in list) {
      try {
        out.add(QuranMark.fromJson(jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {}
    }
    return out;
  }

  /// يضيف العلامة أو يحذفها. يُرجع true إن صارت موجودة.
  static Future<bool> toggle(QuranMark m) async {
    final p = await SharedPreferences.getInstance();
    final cur = await all();
    final i = cur.indexWhere((x) => x.key == m.key);
    var added = false;
    if (i >= 0) {
      cur.removeAt(i);
    } else {
      cur.insert(0, m);
      added = true;
    }
    await p.setStringList(_kMarks, [for (final x in cur) jsonEncode(x.toJson())]);
    version.value++;
    return added;
  }
}
