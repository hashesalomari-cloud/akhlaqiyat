import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'local_data_service.dart';
import 'prayer_time_service.dart';

/// جسر إلى كود أندرويد الأصلي: الكتم التلقائي أثناء الصلاة + ودجت الشاشة.
/// كل الاستدعاءات آمنة: إن لم يكن الكود الأصلي موجودًا (مثلًا في اختبار) تُتجاهل.
class NativeBridge {
  static const _ch = MethodChannel('akhlaqiyat/native');

  static const kSilentEnabled = 'silent_enabled';
  static const kSilentMinutes = 'silent_minutes';

  static Future<T?> _call<T>(String m, [Map<String, dynamic>? args]) async {
    try {
      return await _ch.invokeMethod<T>(m, args);
    } catch (_) {
      return null;
    }
  }

  static Future<bool> hasPolicyAccess() async => (await _call<bool>('policyAccess')) ?? false;
  static Future<void> openPolicySettings() => _call<bool>('openPolicySettings');

  /// يجدّد الكتم التلقائي وبيانات الودجت من مواقيت اليوم (تُكرَّر 7 أيام تقريبيًا).
  static Future<void> sync(PrayerTimesResult r) async {
    final prefs = await SharedPreferences.getInstance();
    final prayers = <(String, DateTime)>[
      ('الفجر', r.fajr),
      ('الظهر', r.dhuhr),
      ('العصر', r.asr),
      ('المغرب', r.maghrib),
      ('العشاء', r.isha),
    ];

    // — الكتم التلقائي —
    if (prefs.getBool(kSilentEnabled) ?? false) {
      final times = <int>[];
      for (var d = 0; d < 7; d++) {
        for (final p in prayers) {
          times.add(p.$2.add(Duration(days: d)).millisecondsSinceEpoch);
        }
      }
      times.sort();
      await _call<bool>('scheduleSilence', {
        'times': times,
        'minutes': prefs.getInt(kSilentMinutes) ?? 20,
      });
    } else {
      await _call<bool>('cancelSilence');
    }

    // — الودجت: الصلوات القادمة (3 أيام) + سطور متجددة كل ساعة —
    final entries = <Map<String, Object>>[];
    for (var d = 0; d < 3; d++) {
      for (final p in prayers) {
        entries.add({'n': p.$1, 't': p.$2.add(Duration(days: d)).millisecondsSinceEpoch});
      }
    }
    entries.sort((a, b) => (a['t'] as int).compareTo(b['t'] as int));
    await _call<bool>('saveWidgetData', {
      'prayers': jsonEncode(entries),
      'lines': jsonEncode(await _widgetLines()),
    });
  }

  /// سطور قصيرة موثّقة: آيات الحفظ المراجَعة + أذكار قصيرة.
  static Future<List<String>> _widgetLines() async {
    final out = <String>[];
    try {
      final surahs = await LocalDataService.surahs();
      final raw = await rootBundle.loadString('assets/data/memorize_ayat.json');
      for (final e in (jsonDecode(raw)['ayat'] as List)) {
        final text = e['text'] as String;
        if (text.length > 130) continue;
        final name = surahs.firstWhere((x) => x.number == e['s']).nameArabic;
        out.add('$text ﴿$name ${e['f']}﴾');
      }
      for (final cat in ['morning', 'free_tasbih', 'after_prayer', 'distress', 'quran_duas']) {
        for (final d in await LocalDataService.azkarFor(cat)) {
          if (d.text.length <= 110) out.add('${d.text}\n${d.source}');
        }
      }
    } catch (_) {}
    return out;
  }
}
