import 'package:share_plus/share_plus.dart';

/// "شارك الخير" — يفتح قائمة المشاركة الأصلية بالجهاز (واتساب، رسائل،
/// إلخ) برسالة جاهزة عن التطبيق.
///
/// ملاحظة: لا يوجد رابط متجر حقيقي بعد لأن التطبيق لم يُنشر رسميًا.
/// بمجرد نشره على Google Play، استبدل storeUrl بالرابط الفعلي حتى
/// يفتح من يستقبل الرسالة صفحة التحميل مباشرة.
class ShareService {
  static const String _storeUrl = ''; // TODO: ضع رابط Google Play هنا بعد النشر

  static Future<void> shareApp() async {
    final link = _storeUrl.isNotEmpty ? '\n$_storeUrl' : '';
    await Share.share(
      'شارك الخير 🌙\n'
      'تطبيق "أخلاقيات" يساعدك تتعلم دينك يوميًا: قرآن، حديث، أذكار، وأخلاق عملية — بطريقة ممتعة وبسيطة.'
      '$link',
      subject: 'تطبيق أخلاقيات',
    );
  }
}
